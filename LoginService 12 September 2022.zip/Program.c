#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "sqlite3.lib")
#include "Database.h"
#include "Structures.h"
#include "List.h"
#include "BlockingQueue.h"
#include "Service.h"

#pragma region variables
extern int maxAttemptId;
extern BlockingQueue attempts, logouts;

SOCKET server;
CRITICAL_SECTION criticalClient;
byte isRunning;
List clients, onlines;
#pragma endregion

#pragma region protos
void initialize();
void acceptClient();
void cleanup();
#pragma endregion

int main() {
	SetActions(initialize, acceptClient, cleanup);
#ifdef _DEBUG
	RunServiceDebug();
#else
	RunServiceRelease();
#endif
	return 0;
}

static ulong handleAttempt(void* p) {
	SOCKET client = p;
	Client* c = getClient(client);
	char header[4];
	int accumulated, read;
	byte isSuccess = 0;

	accumulated = recv(client, header, 4, 0);
	if (accumulated <= 0)  goto onDisconnect;
	while (accumulated < 4) {
		read = recv(client, &header[accumulated], 4 - accumulated, 0);
		if (read <= 0)  goto onDisconnect;
		accumulated += read;
	}
	int packetSize;
	memcpy_s(&packetSize, 4, header, 4);
	char *packet = malloc(packetSize);
	accumulated = read = 0;
	while (accumulated < packetSize) {
		read = recv(client, &packet[accumulated], packetSize - accumulated, 0);
		if (read <= 0) {
			free(packet);
			goto onDisconnect;
		}
		accumulated += read;
	}
	EnterCriticalSection(&criticalClient);
	maxAttemptId++;
	LeaveCriticalSection(&criticalClient);

	char* appName, * user, * pass;
	appName = strtok_s(packet, "", &pass), pass++;
	user = strtok_s(0, "", &pass), pass++;
	/*char* appName = packet;
	char* user = packet + strlen(appName) + 1;
	char* pass = packet + strlen(appName) + strlen(user) + 2;
	*/
	int appId = getAppId(appName);
	int addressId = getAddressId(c->ip4Address);
	Login* login = getLogin(user, pass);

	LoginResult result;
	Attempt* attempt = malloc(ATTEMPT_SIZE);
	attempt->id = maxAttemptId;
	attempt->appId = appId;
	attempt->addressId = addressId;
	attempt->port = c->port;
	attempt->timeIn = getTime();
	attempt->dateIn = getDate();

	Online* online = malloc(ONLINE_SIZE);
	if (login) {
		result.userId = attempt->userId = login->id;
		result.isSuccess = attempt->isSuccess = isSuccess = 1;
		result.role = login->role;

		online->Id = attempt->id;
		online->Login = login;
		mallocate(attempt->dateIn, &online->dateIn);
		mallocate(attempt->timeIn, &online->timeIn);

		EnterCriticalSection(&criticalClient);
		addToList(&onlines, online);
		LeaveCriticalSection(&criticalClient);
	}
	else {
		result.role = result.userId = result.isSuccess =
			attempt->isSuccess = attempt->userId = 0;
		mallocate(user, &attempt->userName);
		mallocate(pass, &attempt->password);
		free(online);
	}
	free(packet);
	sendInt(client, 9);
	sendInt(client, result.role);
	sendInt(client, result.userId);
	sendByte(client, result.isSuccess);

	putInto(&attempts, attempt);
	if (isSuccess) {
		recv(client, header, 1, 0); // wait for disconnection
		online->timeOut = getTime();
		online->dateOut = getDate();
		
		EnterCriticalSection(&criticalClient);
		removeFromList(&onlines, online);
		putInto(&logouts, online);
		LeaveCriticalSection(&criticalClient);
	}

onDisconnect:
	closesocket(client);
	CloseHandle(c->thread);
	EnterCriticalSection(&criticalClient);
	removeFromList(&clients, c);
	LeaveCriticalSection(&criticalClient);
	free(c);
	return 0;
}
static void initialize() {
	const wchar_t* IP = L"127.0.0.1";
	int PORT = 5556;

	WSADATA w;
	WSAStartup(MAKEWORD(2, 2), &w);
	SOCKADDR_IN address = { AF_INET, htons(PORT) };
	InetPton(AF_INET, IP, &address.sin_addr.s_addr);
	server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	bind(server, &address, sizeof(address));
	listen(server, SOMAXCONN);
	isRunning = 1;

	initializeDatabase();

	onlines.count = clients.count = 0;
	onlines.capacity = clients.capacity = 5;
	clients.data = malloc(5 * POINTER_SIZE);
	onlines.data = malloc(5 * POINTER_SIZE);
	
	InitializeCriticalSection(&criticalClient);
}
static void acceptClient() {
	while (isRunning) {
		SOCKADDR_IN from;
		int length = sizeof(from);
		SOCKET client = accept(server, &from, &length);
		char ipv4[INET_ADDRSTRLEN];
		inet_ntop(AF_INET, &(from.sin_addr), ipv4, INET_ADDRSTRLEN);
		BOOL b = TRUE;
		setsockopt(client, IPPROTO_TCP, TCP_NODELAY, &b, sizeof(BOOL));

		EnterCriticalSection(&criticalClient);
		HANDLE attemptThread = CreateThread(NULL, 0, handleAttempt, client, 0, NULL);
		Client* c = malloc(CLIENT_SIZE);
		c->socket = client;
		c->thread = attemptThread;
		mallocate(ipv4, &c->ip4Address);
		c->port = from.sin_port;
		addToList(&clients, c);
		LeaveCriticalSection(&criticalClient);
	}
}
static void cleanup() {
	isRunning = 0;
	closesocket(server);
	WSACleanup();
}
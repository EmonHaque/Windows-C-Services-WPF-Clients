#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include "Structures.h"
#include "List.h"
#include "BlockingQueue.h"
#include "Messenger.h"

extern byte isRunning;
extern List receivers;
extern BlockingQueue publicResponses;
extern pthread_mutex_t criticalReceiver;

static pthread_t broadcastThread;
static List disconnectedReceivers;

static void sendPlot(ResponsePublic* r) {
	int** list = receivers.data;
	Plot* plot = r->data;
	int client;
	for (int i = 0; i < receivers.count; i++) {
		client = *list[i];
		if (sendInt(client, r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			printf("Couldn't send");
			continue;
		}
		sendInt(client, r->function);
		sendInt(client, r->userId);

		sendInt(client, plot->id);
		sendString(client, plot->name);
		sendString(client, plot->description);
	}
}
static void sendSpace(ResponsePublic* r) {
	int** list = receivers.data;
	Space* space = r->data;
	int client;
	for (int i = 0; i < receivers.count; i++) {
		client = *list[i];
		if (sendInt(client, r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(client, r->function);
		sendInt(client, r->userId);

		sendInt(client, space->id);
		sendInt(client, space->plotId);
		sendString(client, space->name);
		sendString(client, space->description);
		sendByte(client, space->isVacant);
	}
}
static void sendEditedSpace(ResponsePublic* r) {
	int** list = receivers.data;
	EditedSpace* ep = r->data;
	int client;
	for (int i = 0; i < receivers.count; i++) {
		client = *list[i];
		if (sendInt(client, r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(client, r->function);
		sendInt(client, r->userId);

		sendInt(client, ep->leaseId);
		sendString(client, ep->vaccatedOn);
		sendInt(client, ep->space->id);
		sendInt(client, ep->space->plotId);
		sendString(client, ep->space->name);
		sendString(client, ep->space->description);
		sendByte(client, ep->space->isVacant);
	}
	free(ep->vaccatedOn);
	free(ep);
}
static void sendTenant(ResponsePublic* r) {
	int** list = receivers.data;
	Tenant* tenant = r->data;
	int client;
	for (int i = 0; i < receivers.count; i++) {
		client = *list[i];
		if (sendInt(client, r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(client, r->function);
		sendInt(client, r->userId);

		sendInt(client, tenant->id);
		sendString(client, tenant->name);
		sendString(client, tenant->father);
		sendString(client, tenant->mother);
		sendString(client, tenant->husband);
		sendString(client, tenant->address);
		sendString(client, tenant->NID);
		sendString(client, tenant->contactNo);
		sendByte(client, tenant->hasLeft);
	}
}
static void sendEditedTenant(ResponsePublic* r) {
	int** list = receivers.data;
	EditedTenant* et = r->data;
	int client;
	for (int i = 0; i < receivers.count; i++) {
		client = *list[i];
		if (sendInt(client, r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(client, r->function);
		sendInt(client, r->userId);

		sendString(client, et->leftOn);
		sendInt(client, et->tenant->id);
		sendString(client, et->tenant->name);
		sendString(client, et->tenant->father);
		sendString(client, et->tenant->mother);
		sendString(client, et->tenant->husband);
		sendString(client, et->tenant->address);
		sendString(client, et->tenant->NID);
		sendString(client, et->tenant->contactNo);
		sendByte(client, et->tenant->hasLeft);
	}
	free(et->leftOn);
	free(et);
}
static void sendHead(ResponsePublic* r) {
	int** list = receivers.data;
	Head* head = r->data;
	int client;
	for (int i = 0; i < receivers.count; i++) {
		client = *list[i];
		if (sendInt(client, r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(client, r->function);
		sendInt(client, r->userId);

		sendInt(client, head->id);
		sendInt(client, head->controlId);
		sendString(client, head->name);
		sendString(client, head->description);
	}
}
static void sendLease(ResponsePublic* r) {
	int** list = receivers.data;
	NewLease* nl = r->data;
	int count = nl->receivables.count;
	Receivable** receivables = nl->receivables.data;
	int client;
	for (int i = 0; i < receivers.count; i++) {
		client = *list[i];
		if (sendInt(client, r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(client, r->function);
		sendInt(client, r->userId);

		sendInt(client, nl->lease->id);
		sendInt(client, nl->lease->plotId);
		sendInt(client, nl->lease->spaceId);
		sendInt(client, nl->lease->tenantId);
		sendString(client, nl->lease->dateStart);
		sendString(client, nl->lease->dateEnd);
		sendString(client, nl->lease->business);
		sendByte(client, nl->lease->isExpired);
		for (int j = 0; j < count; j++) {
			sendInt(client, receivables[j]->leaseId);
			sendInt(client, receivables[j]->headId);
			sendInt(client, receivables[j]->amount);
		}
	}
	free(receivables);
	free(nl);
}
static void sendTransaction(ResponsePublic* r) {
	int** list = receivers.data;
	Transaction* action = r->data;
	int client;
	for (int i = 0; i < receivers.count; i++) {
		client = *list[i];
		if (sendInt(client, r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(client, r->function);
		sendInt(client, r->userId);

		sendInt(client, action->id);
		sendInt(client, action->plotId);
		sendInt(client, action->spaceId);
		sendInt(client, action->tenantId);
		sendInt(client, action->controlId);
		sendInt(client, action->headId);
		sendInt(client, action->amount);
		sendByte(client, action->isCash);
		sendString(client, action->date);
		sendString(client, action->narration);
	}
	free(action->date);
	free(action->narration);
	free(action);
}

static void* BroadcastResponse(void* p) {
	pthread_detach(pthread_self());

	while (isRunning) {
		ResponsePublic* r = takeOutFrom(&publicResponses);
		if(!r) break;

		pthread_mutex_lock(&criticalReceiver);
		switch (r->function) {
			case AddPlot:
			case EditPlot: sendPlot(r); break;
			case AddSpace: sendSpace(r); break;
			case EditSpace: sendEditedSpace(r); break;
			case AddTenant: sendTenant(r); break;
			case EditTenant: sendEditedTenant(r); break;
			case AddLease:
			case EditLease: sendLease(r); break;
			case AddHead:
			case EditHead: sendHead(r); break;
			case EditTransaction:
			case DeleteTransaction: sendTransaction(r); break;
		}
		pthread_mutex_unlock(&criticalReceiver);
		free(r);

		if (isRunning && disconnectedReceivers.count > 0) {
			pthread_mutex_lock(&criticalReceiver);
			int** list = disconnectedReceivers.data;
			for (int i = 0; i < disconnectedReceivers.count; i++) {
				close(*list[i]);
				removeFromList(&receivers, list[i]);
			}
			pthread_mutex_unlock(&criticalReceiver);
			disconnectedReceivers.count = 0;
			if (disconnectedReceivers.capacity > 5) {
				disconnectedReceivers.capacity = 5;
				disconnectedReceivers.data = realloc(disconnectedReceivers.data, 5 * POINTER_SIZE);
			}
		}
	}
	return 0;
}

void InitializeBroadcaster() {
	disconnectedReceivers.count = 0;
	disconnectedReceivers.capacity = 5;
	disconnectedReceivers.data = malloc(5 * POINTER_SIZE);
	pthread_create(&broadcastThread, 0, BroadcastResponse, 0);
}

void ShutdownBroadcaster(){
	
}
﻿public abstract class AppDataBase
{
    int byteCount, read, accumulated, size;
    byte[] header = new byte[4];

    protected bool isConnected;
    protected BlockingCollection<byte[]> messages;
    protected LoadingWindow window;
    protected Dispatcher patch;
    protected ServicePack service;

    protected abstract void initializeCollections();
    protected abstract void populateCollections();
    protected abstract void processMessage();

    public event Action<LoadingWindow> Received;

    public void SetLoadingWindow(LoadingWindow w, ServicePack s) {
        window = w;
        service = s;
        patch = Application.Current.Dispatcher;
        window.Activated += onActivated;
    }
    async void onActivated(object? sender, EventArgs e) {
        window.Text = "initializing";
        await Task.Delay(2000);
        initializeCollections();
        new Thread(getInitialLoad) { IsBackground = true }.Start();
    }
    void getInitialLoad() {
        patch.Invoke(() => { window.Text = "waiting for response"; });
        Thread.Sleep(250);
        populateCollections();

        window.Activated -= onActivated;
        patch.Invoke(() => { window.Text = "launching ..."; });
        Thread.Sleep(1000);
        patch.Invoke(() => Received?.Invoke(window));

        isConnected = true;
        messages = new BlockingCollection<byte[]>();
        new Thread(receiveBroadcast) { IsBackground = true }.Start();
        new Thread(processMessage) { IsBackground = true }.Start();
    }
    protected byte[] getPacket() {
        accumulated = 0;
        do {
            read = service.Sender.Receive(header, accumulated, header.Length - accumulated, SocketFlags.None);
            if (read == 0) { }
            accumulated += read;
        } while (accumulated < 4);

        size = BitConverter.ToInt32(header);
        if (size == 0) return new byte[0];
        var packet = new byte[size];
        accumulated = 0;
        do {
            read = service.Sender.Receive(packet, accumulated, size - accumulated, SocketFlags.None);
            if (read == 0) { }
            accumulated += read;
        } while (accumulated < size);
        byteCount += size;

        patch.Invoke(() => {
            window.Text = $"{byteCount.ToString("N0")} bytes received";
        });
        Thread.Sleep(250);
        return packet;
    }
    void receiveBroadcast() {
        while (isConnected) {
            try {
                accumulated = 0;
                do {
                    read = service.Receiver.Receive(header, accumulated, header.Length - accumulated, SocketFlags.None);
                    if (read == 0) {
                        isConnected = false;
                        break;
                    }
                    accumulated += read;
                } while (accumulated < 4);

                size = BitConverter.ToInt32(header);
                var packet = new byte[size];
                accumulated = 0;
                do {
                    read = service.Receiver.Receive(packet, accumulated, size - accumulated, SocketFlags.None);
                    if (read == 0) {
                        isConnected = false;
                        break;
                    }
                    accumulated += read;
                } while (accumulated < size);
                messages.Add(packet);
            }
            catch {
                isConnected = false;
                //show some message and new up socket and reconnect
            }
        }
    }
}

﻿public abstract class TransitButton : Border
{
    protected SolidColorBrush brush;
    protected ColorAnimation brushAnim;
    protected Color normalColor, highlightColor, selectedColor;

    public bool isActing;
    public int index;
    bool isSelected;
    public bool IsSelected {
        get { return isSelected; }
        set { 
            isSelected = value;
            if (IsSelected) animateBrush(selectedColor);
            else animateBrush(normalColor);
        }
    }
    public Action<int> Command { get; set; }
    protected abstract FrameworkElement element { get; }
    protected abstract void initializeElement();

    public TransitButton(double widthAndHeight) {
        initializeElement();
        Background = Brushes.Transparent;
        element.Width = element.Height = widthAndHeight;
        Child = element;

        brushAnim = new ColorAnimation() {
            Duration = TimeSpan.FromMilliseconds(250),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
    }

    void animateBrush(Color color) {
        brushAnim.To = color;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
    }
    protected override void OnMouseUp(MouseButtonEventArgs e) {
        if (!isActing) Command.Invoke(index);
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        if (IsSelected) return;
        animateBrush(highlightColor);
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        if (IsSelected) return;
        animateBrush(normalColor);
    }
}

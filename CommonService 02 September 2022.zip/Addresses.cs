﻿public class Addresses
{
    public const string InstallAddress = "127.0.0.1";
    public const string LaunchAddress = "127.0.0.1";
    public const string LoginAddress = "127.0.0.1";
    public const string RentManagerAddress = "127.0.0.1";
    public const string CDRMAddress = "127.0.0.1";

    public const int InstallPort = 5554;
    public const int LaunchPort = 5555;
    public const int LoginPort = 5556;
    public const int RentManagerPort = 5557;
    public const int CDRMPort = 5558;
}

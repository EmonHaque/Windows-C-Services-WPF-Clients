﻿public class LaunchArgs
{
    public string App { get; set; }
    public string Version { get; set; }
    public string Path { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        var app = Encoding.ASCII.GetBytes(App + '\0');
        var version = Encoding.ASCII.GetBytes(Version + '\0');
        var size = BitConverter.GetBytes(app.Length + version.Length);
        return new List<ArraySegment<byte>>() { size, app, version };
    }
    public static LaunchArgs FromBytes(byte[] array) {
        int read, start, index;
        read = start = index = 0;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array, start, read - start);
            if (index == segments.Length) break;
            start = ++read;
        }
        return new LaunchArgs() {
            App = segments[0],
            Version = segments[1]
        };
    }
}

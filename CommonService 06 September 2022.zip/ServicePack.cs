﻿public class ServicePack
{
    public Socket Signatory { get; set; } // for connecting to login service
    public Socket Receiver { get; set; } // for receiving broadcast
    public Socket Sender { get; set; } // for request and response
    public IPAddress Address { get; set; }
    public int Port { get; set; }
    public Role Role { get; set; }
    public int UserId { get; set; }

    /* will run on a different thread and you need a lock otherwise multiple threads will mess up the header/packet buffer
     var response = await App.service.GetResponse(request);
     https://devblogs.microsoft.com/pfxteam/the-nature-of-taskcompletionsourcetresult/
     cleanest approach so far. Requests are handled one by one, the only point is to keep the UI responsive */
    public Task<Response> GetResponse(Request request) {
        var source = new TaskCompletionSource<Response>();
        ThreadPool.QueueUserWorkItem(_ => {
            try {
                Monitor.Enter(Sender);
                Sender.Send(request.GetBytes());
                var header = new byte[4];
                int read = Sender.Receive(header);
                while (read < header.Length) {
                    read += Sender.Receive(header, read, header.Length - read, SocketFlags.None);
                }
                var size = BitConverter.ToInt32(header);
                if (size == 0) source.SetResult(new Response(true, new byte[0]));

                var packet = new byte[size];
                read = Sender.Receive(packet);
                while (read < packet.Length) {
                    read += Sender.Receive(packet, read, packet.Length - read, SocketFlags.None);
                }
                source.SetResult(new Response(true, packet));
            }
            catch { source.SetResult(new Response(false, new byte[0])); }
            finally { Monitor.Exit(Sender); }
        });
        return source.Task;
    }

    /* will run on calling/UI thread, block UI and you do not need lock since requests will be handled one by one from the call stack of that Thread
    var response = await App.service.GetResponse(request);

    public Task<Response> GetResponse(Request request) {
        try {
            Sender.Send(request.GetBytes());
            var header = new byte[4];
            int read = Sender.Receive(header);
            while (read < header.Length) {
                read += Sender.Receive(header, read, header.Length - read, SocketFlags.None);
            }
            var size = BitConverter.ToInt32(header);
            if (size == 0) return Task.FromResult(new Response(true, new byte[0]));

            var packet = new byte[size];
            read = Sender.Receive(packet);
            while (read < packet.Length) {
                read += Sender.Receive(packet, read, packet.Length - read, SocketFlags.None);
            }
            return Task.FromResult(new Response(true, packet));
        }
        catch { return Task.FromResult(new Response(false, new byte[0])); }
    } */

    /* will run on a different thread and you need a lock otherwise multiple threads will mess up the header/packet buffer
    var response = await Task.Run(() => App.service.GetResponse(request));

    public Response GetResponse(Request request) {
        try {
            Monitor.Enter(this);
            Sender.Send(request.GetBytes());
            var header = new byte[4];
            int read = Sender.Receive(header);
            while (read < header.Length) {
                read += Sender.Receive(header, read, header.Length - read, SocketFlags.None);
            }
            var size = BitConverter.ToInt32(header);
            if (size == 0) return new Response(true, new byte[0]);

            var packet = new byte[size];
            read = Sender.Receive(packet);
            while (read < packet.Length) {
                read += Sender.Receive(packet, read, packet.Length - read, SocketFlags.None);
            }
            return new Response(true, packet);
        }
        catch { return new Response(false, new byte[0]); }
        finally { Monitor.Exit(this); }
    } */
}

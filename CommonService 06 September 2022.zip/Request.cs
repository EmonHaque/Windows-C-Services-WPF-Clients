﻿public class Request
{
    public int UserId { get; set; }
    public int Method { get; set; }
    public List<ArraySegment<byte>> Bytes { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        int size = 4 + 4 + Bytes.Sum(x => x.Count);
        var bytes = new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(size),
            BitConverter.GetBytes(UserId),
            BitConverter.GetBytes(Method)
        };
        bytes.AddRange(Bytes);
        return bytes;
    }  
}

﻿class EditUnitVM : EditBaseVM<Unit>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.units,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override Unit clone() {
        return new Unit() {
            Id = Selected.Id,
            Name = Selected.Name
        };
    }
    protected override async void update() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.EditUnit,
            Bytes = Edited.ToBytes()
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Unit", LocalConstants.ServiceDown);
        }
    }

}


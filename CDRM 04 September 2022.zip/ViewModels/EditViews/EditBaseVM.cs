﻿abstract class EditBaseVM<T> : Notifiable, IEdit<T> where T : Notifiable, IHaveName, new()
{
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value?.Trim().ToLower();
                Editables.Refresh();
            }
        }
    }
    bool isOnEdit;
    public bool IsOnEdit {
        get { return isOnEdit; }
        set {
            isOnEdit = value;
            if (value) {
                Edited = clone();
                OnPropertyChanged(nameof(Edited));
            }
        }
    }
    public T Selected { get; set; }
    public T Edited { get; set; }
    public ICollectionView Editables { get; set; }
    protected abstract CollectionViewSource cvs { get; }
    protected abstract void update();
    protected abstract T clone();
    public event Action CoordinateRequested;

    public EditBaseVM() {
        Editables = cvs.View;
        Editables.SortDescriptions.Add(new SortDescription(nameof(IHaveName.Name), ListSortDirection.Ascending));
        Editables.Filter = filter;
    }
    
    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((IHaveName)o).Name.ToLower().Contains(Query);
    }
    public void ValidateAndSave() {
        var o = ((IEnumerable<T>)cvs.Source)
            .FirstOrDefault(x => x.Name.Equals(Edited.Name.Trim(), StringComparison.InvariantCultureIgnoreCase));

        bool isValid = false;
        if (o is Site) {
            if (o is null) isValid = true;
            else {
                var site = o as Site;
                var editedSite = Edited as Site;
                isValid = !editedSite.Address.Trim().Equals(site.Address);
            }
            if (isValid) update();
        }
        else if (o is Party) {
            if (o is null) isValid = true;
            else {
                var party = o as Party;
                var editedParty = Edited as Party;
                isValid = !(editedParty.Address.Trim().Equals(party.Address, StringComparison.InvariantCultureIgnoreCase)
                    && editedParty.Phone.Trim().Equals(party.Phone, StringComparison.InvariantCultureIgnoreCase));
            }
            if (isValid) update();
        }
        else {
            isValid = o is null;
            if (isValid) update();
            else if (!isValid && Edited.Name.Trim().Equals(Selected.Name, StringComparison.InvariantCultureIgnoreCase)) return;
            else {
                CoordinateRequested?.Invoke();
                new ErrorDialog(EditBase<T>.Left, EditBase<T>.Top, EditBase<T>.Width, EditBase<T>.Height,
                    new List<ValidationError>() {
                    new ValidationError() {
                        Head = "Name",
                        Error = "already exists"
                    }
                    }).ShowDialog();
            }
        }
    }
}

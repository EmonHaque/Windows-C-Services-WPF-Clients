﻿class AllPartyTransactionVM : AllPurchaseBaseVM
{
    public static event Action<ReportDates, KeyTrippleValueSeries> SelectionChanged;
    protected override string type => "Party";
    protected override bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((KeyTrippleValueSeries)o).Key.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }

    public override void SortPurchase() => sort(nameof(KeyTrippleValueSeries.Value1));
    public void SortPayment() => sort(nameof(KeyTrippleValueSeries.Value2));
    public void SortDue() => sort(nameof(KeyTrippleValueSeries.Value3));

    void sort(string property) {
        if (Data is null) return;
        var direction = ListSortDirection.Descending;
        bool hasBeenSorted = false;
        if (Data.SortDescriptions.Count == 0) {
            Data.SortDescriptions.Add(new SortDescription(property, direction));
            return;
        }
        var first = Data.SortDescriptions.First();
        if (first.PropertyName.Equals(property)) {
            direction = first.Direction;
            hasBeenSorted = true;
        }
        if (hasBeenSorted) {
            if (direction == ListSortDirection.Descending) {
                addSortDescription(property, ListSortDirection.Ascending);
            }
            else addSortDescription(property, ListSortDirection.Descending);
        }
        else addSortDescription(property, ListSortDirection.Descending);
    }
    void addSortDescription(string property, ListSortDirection direction) {
        using (Data.DeferRefresh()) {
            Data.SortDescriptions.Clear();
            Data.SortDescriptions.Add(new SortDescription(property, direction));
        }
    }
    protected override void onSelectedChanged() {
        SelectionChanged?.Invoke(Dates, (KeyTrippleValueSeries)Selected);
    }
}

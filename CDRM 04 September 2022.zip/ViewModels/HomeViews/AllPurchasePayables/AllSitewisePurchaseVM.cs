﻿class AllSitewisePurchaseVM : AllPurchaseBaseVM
{
    public static event Action<ReportDates, KeyValueSeries> SelectionChanged;
    protected override string type => "Site";
    protected override void onSelectedChanged() {
        SelectionChanged?.Invoke(Dates, (KeyValueSeries)Selected);
    }
}

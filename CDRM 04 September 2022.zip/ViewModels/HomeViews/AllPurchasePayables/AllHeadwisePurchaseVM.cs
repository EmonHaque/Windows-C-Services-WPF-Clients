﻿class AllHeadwisePurchaseVM : AllPurchaseBaseVM
{
    public static event Action<ReportDates, KeyValueSeries> SelectionChanged;
    protected override string type => "Head";
    protected override void onSelectedChanged() {
        SelectionChanged?.Invoke(Dates, (KeyValueSeries)Selected);
    }
}

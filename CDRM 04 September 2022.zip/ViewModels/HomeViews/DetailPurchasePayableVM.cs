﻿class DetailPurchasePayableVM : Notifiable
{
    const string site = "Site";
    const string head = "Head";
    const string party = "Party";
    string type, query;
    int id;
    DateTime from, to;

    public ICollectionView Data { get; set; }
    public byte State { get; set; }
    public string[] StateTexts { get; set; }
    public string[] StateIcons { get; set; }
    
    public DetailPurchasePayableVM() {
        type = site;
        StateTexts = new string[] { head, party };
        StateIcons = new string[] { Icons.ControlHead, Icons.Tenant };
        Data = CollectionViewSource.GetDefaultView(new List<KeyValueSeries>());
        AllSitewisePurchaseVM.SelectionChanged += onSiteChanged;
        AllHeadwisePurchaseVM.SelectionChanged += onHeadChanged;
        AllPartyTransactionVM.SelectionChanged += onPartyChanged;
    }
    public void Refresh() {
        //setQuery();
        getEntries();
    }
    public void SortName() => sort(nameof(KeyValueSeries.Key));
    public void SortAmount() => sort(nameof(KeyValueSeries.Value));

    void onPartyChanged(ReportDates d, KeyTrippleValueSeries k) {
        if (k is null) return;
        id = AppData.parties.First(x => x.Name.Equals(k.Key)).Id;
        if (!type.Equals(party)) {
            type = party;
            resetIcons(new string[] { site, head }, new string[] { Icons.Plot, Icons.ControlHead });
        }
        update(d);
    }
    void onHeadChanged(ReportDates d, KeyValueSeries k) {
        if (k is null) return;
        id = AppData.heads.First(x => x.Name.Equals(k.Key)).Id;
        if (!type.Equals(head)) {
            type = head;
            resetIcons(new string[] { site, party }, new string[] { Icons.Plot, Icons.Tenant });
        }
        update(d);
    }
    void onSiteChanged(ReportDates d, KeyValueSeries k) {
        if (k is null) return;
        id = AppData.sites.First(x => x.Name.Equals(k.Key)).Id;
        if (!type.Equals(site)) {
            type = site;
            resetIcons(new string[] { head, party }, new string[] { Icons.ControlHead, Icons.Tenant });
        }
        update(d);
    }
    void update(ReportDates d) {
        from = d.From.Value;
        to = d.To.Value;
        //setQuery();
        getEntries();
    } 
    void resetIcons(string[] texts, string[] icons) {
        StateTexts = texts;
        StateIcons = icons;
        OnPropertyChanged(nameof(StateIcons));
        OnPropertyChanged(nameof(StateTexts));
    }
    void sort(string property) {
        if (Data is null) return;
        var direction = property.Equals(nameof(KeyValueSeries.Key)) ?
            ListSortDirection.Ascending :
            ListSortDirection.Descending;
        bool hasBeenSorted = false;
        if (Data.SortDescriptions.Count == 0) {
            Data.SortDescriptions.Add(new SortDescription(property, direction));
            return;
        }
        var first = Data.SortDescriptions.First();
        if (first.PropertyName.Equals(property)) {
            direction = first.Direction;
            hasBeenSorted = true;
        }
        if (hasBeenSorted) {
            if (direction == ListSortDirection.Descending) {
                addSortDescription(property, ListSortDirection.Ascending);
            }
            else addSortDescription(property, ListSortDirection.Descending);
        }
        else addSortDescription(property, ListSortDirection.Descending);
    }
    void addSortDescription(string property, ListSortDirection direction) {
        using (Data.DeferRefresh()) {
            Data.SortDescriptions.Clear();
            Data.SortDescriptions.Add(new SortDescription(property, direction));
        }
    }

    async void getEntries() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetDetailPurchasePayable,
            Bytes = new List<ArraySegment<byte>>() {
                Encoding.ASCII.GetBytes(type + '\0'),
                Encoding.ASCII.GetBytes(from.ToString("yyyy-MM-dd") + '\0'),
                Encoding.ASCII.GetBytes(to.ToString("yyyy-MM-dd") + '\0'),
                new byte[1]{ State },
                BitConverter.GetBytes(id)
            }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            //message
            return;
        }
        var list = await getKeyValues(response.Packet);
        Data = CollectionViewSource.GetDefaultView(list);
        OnPropertyChanged(nameof(Data));
    }
    Task<List<KeyValueSeries>> getKeyValues(byte[] packet) {
        var list = new List<KeyValueSeries>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        int start = 0;
        while (read < span.Length) {
            while (span[read] != 0) read++;

            list.Add(new KeyValueSeries() {
                Key = Encoding.ASCII.GetString(span.Slice(start, read - start)),
                Value = BitConverter.ToInt32(span.Slice(read + 1, 4))
            });
            read += 5;
            start = read;
        }
        return Task.FromResult(list);
    }
}

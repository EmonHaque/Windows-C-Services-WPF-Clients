﻿class AllSiteVM : Notifiable
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public byte State { get; set; }
    public int Total { get; set; }
    public List<KeyValueSeries> Data { get; set; }

    public AllSiteVM() {
        To = DateTime.Today;
        From = To.Value.AddYears(-1);
        getEntries();
    }

    public void Refresh() {
        getEntries();
    }
    async void getEntries() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetPurchases,
            Bytes = new List<ArraySegment<byte>>() {
                new byte[1]{ State },
                Encoding.ASCII.GetBytes(From.Value.ToString("yyyy-MM-dd") + '\0'),
                Encoding.ASCII.GetBytes(To.Value.ToString("yyyy-MM-dd") + '\0'),
            }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            //message
            return;
        }
        Data = await getKeyValues(response.Packet);
        //string query = "";
        //if (State == 4 /*All*/) query = $@"SELECT Sites.Name, SUM(Amount) FROM Dues
        //                                LEFT JOIN Sites ON Sites.Id = SiteId
        //                                WHERE IsSell = 0 AND Date BETWEEN '{From.Value.ToString("yyyy - MM - dd")}' 
        //                                AND '{To.Value.ToString("yyyy - MM - dd")}'
        //                                GROUP BY Sites.Name";
        //else query = @$"SELECT Sites.Name, SUM(Amount) FROM Dues
        //                LEFT JOIN Sites ON Sites.Id = SiteId
        //                WHERE IsSell = 0 AND IsConstruction = {State} AND 
        //                Date BETWEEN '{From.Value.ToString("yyyy-MM-dd")}' AND '{To.Value.ToString("yyyy-MM-dd")}'
        //                GROUP BY Sites.Name";
        //Data = new List<KeyValueSeries>();
        //Total = 0;
        //lock (SQL.key) {
        //    SQL.command.CommandText = query;
        //    var reader = SQL.command.ExecuteReader();
        //    while (reader.Read()) {
        //        var e = new KeyValueSeries() {
        //            Key = reader.GetString(0),
        //            Value = reader.GetInt32(1)
        //        };
        //        Total += e.Value;
        //        Data.Add(e);
        //    }
        //    reader.Close();
        //    reader.DisposeAsync();
        //}
        OnPropertyChanged(nameof(Total));
        OnPropertyChanged(nameof(Data));
    }
    Task<List<KeyValueSeries>> getKeyValues(byte[] packet) {
        var list = new List<KeyValueSeries>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        int start = 0;
        Total = 0;
        while (read < span.Length) {
            while (span[read] != 0) read++;

            list.Add(new KeyValueSeries() {
                Key = Encoding.ASCII.GetString(span.Slice(start, read - start)),
                Value = BitConverter.ToInt32(span.Slice(read + 1, 4))
            });
            Total += list.Last().Value;
            read += 5;
            start = read;

        }
        return Task.FromResult(list);
    }
}


﻿class AllPaymentVM : Notifiable
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public int Total { get; set; }
    public List<KeyValueSeries> Data { get; set; }

    public AllPaymentVM() {
        To = DateTime.Today;
        From = To.Value.AddYears(-1);
        getEntries();
    }
    public void Refresh() => getEntries();
    async void getEntries() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetPayments,
            Bytes = new List<ArraySegment<byte>>() {
                Encoding.ASCII.GetBytes(From.Value.ToString("yyyy-MM-dd") + '\0'),
                Encoding.ASCII.GetBytes(To.Value.ToString("yyyy-MM-dd") + '\0'),
            }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            //message
            return;
        }
        Data = await getKeyValues(response.Packet);

        OnPropertyChanged(nameof(Total));
        OnPropertyChanged(nameof(Data));
    }
    Task<List<KeyValueSeries>> getKeyValues(byte[] packet) {
        var list = new List<KeyValueSeries>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        int start = 0;
        Total = 0;
        while (read < span.Length) {
            while (span[read] != 0) read++;

            list.Add(new KeyValueSeries() {
                Key = Encoding.ASCII.GetString(span.Slice(start, read - start)),
                Value = BitConverter.ToInt32(span.Slice(read + 1, 4))
            });
            Total += list.Last().Value;
            read += 5;
            start = read;

        }
        return Task.FromResult(list);
    }
}

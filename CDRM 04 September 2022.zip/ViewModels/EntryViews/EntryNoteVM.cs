﻿class EntryNoteVM : Notifiable
{
    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    public EntryNote Entry { get; set; }
    string siteAddress;
    public string SiteAddress {
        get { return siteAddress; }
        set { siteAddress = value; OnPropertyChanged(nameof(SiteAddress)); }
    }
    public event Action CoordinateRequested;

    public EntryNoteVM() {
        Entry = new EntryNote() { Date = DateTime.Today };
    }

    public async void AddEntry() {
        var validator = new NoteValidator(Entry);
        if (!validator.IsValid()) {
            CoordinateRequested?.Invoke();
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
            errorDialog.ShowDialog();
            return;
        }
        if (!validator.DoesExist()) {
            CoordinateRequested?.Invoke();
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            var isSuccess = await validator.Resolve(Left, Top, Width, Height);
            if (!isSuccess) {
                InfoDialog.Activate("Creation", LocalConstants.ServiceDown);
                return;
            }
        }
        var note = new Note() {
            Date = Entry.Date.Value,
            Entry = Entry.Entry,
            NoteTypeId = Entry.NoteTypeId,
            SiteId = Entry.SiteId
        };
        var request = new Request() { 
            UserId = App.service.UserId,
            Method = (int)Function.AddNote,
            Bytes = note.ToBytes()
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Creation", LocalConstants.ServiceDown);
            return;
        }
        Entry = new EntryNote() { Date = DateTime.Today };
        OnPropertyChanged(nameof(Entry));
    }
    public void SetSiteAddress() {
        if (string.IsNullOrWhiteSpace(Entry.Site)) {
            SiteAddress = null;
            return;
        }
        var site = AppData.sites.FirstOrDefault(x => x.Name.Equals(Entry.Site, StringComparison.InvariantCultureIgnoreCase));
        if (site is null) {
            SiteAddress = null;
            return;
        }
        SiteAddress = site.Address;
    }  
}

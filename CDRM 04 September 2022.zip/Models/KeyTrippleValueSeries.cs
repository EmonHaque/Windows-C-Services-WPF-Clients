﻿class KeyTrippleValueSeries
{
    public string Key { get; set; }
    public int Value1 { get; set; }
    public int Value2 { get; set; }
    public int Value3 { get; set; }
}

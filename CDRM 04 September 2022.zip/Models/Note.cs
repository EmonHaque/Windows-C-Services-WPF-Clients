﻿class Note : Notifiable
{
    public int Id { get; set; }
    public int SiteId { get; set; }
    public int NoteTypeId { get; set; }
    public DateTime Date { get; set; }
    public string Entry { get; set; }
}

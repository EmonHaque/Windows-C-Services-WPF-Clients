﻿class RPToolTipEntry
{
    public DateTime Date { get; set; }
    public int Payment { get; set; }
    public int Receipt { get; set; }
    public byte IsCash { get; set; }
    public string Head { get; set; }
}

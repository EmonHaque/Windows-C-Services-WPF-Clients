﻿class SumTransaction
{
    public int PartyId { get; set; }
    public string Head { get; set; }
    public int PurchaseReceipt { get; set; }
    public int SellPayment { get; set; }
}

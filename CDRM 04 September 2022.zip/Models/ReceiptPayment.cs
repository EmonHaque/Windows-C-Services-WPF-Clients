﻿class ReceiptPayment
{
    public DateTime Date { get; set; }
    public string Party { get; set; }
    public string Head { get; set; }
    public string Narration { get; set; }
    public string Month { get; set; }
    public int Payment { get; set; }
    public int Receipt { get; set; }
    public byte IsCash { get; set; }
}

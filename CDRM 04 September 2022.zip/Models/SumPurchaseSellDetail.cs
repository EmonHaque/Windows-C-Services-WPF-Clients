﻿class SumPurchaseSellDetail : IPurchaseSell
{
    public DateTime Date { get; set; }
    public string GroupName { get; set; }
    public string Particulars { get; set; }
    public string Narration { get; set; }
    public int Purchase { get; set; }
    public int Sell { get; set; }
    public int GroupTotalPurchase { get; set; }
    public int GroupTotalSell { get; set; }
}

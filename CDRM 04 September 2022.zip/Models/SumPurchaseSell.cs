﻿class SumPurchaseSell : IPurchaseSell
{
    public string GroupName { get; set; }
    public string Particulars { get; set; }
    public int Purchase { get; set; }
    public int Sell { get; set; }
    public int GroupTotalPurchase { get; set; }
    public int GroupTotalSell { get; set; }
}

﻿class PurchaseSellEditTemplate : DataTemplate
{
    public PurchaseSellEditTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var icon = new FrameworkElementFactory(typeof(PathIcon));
        var partyHeadBlock = new FrameworkElementFactory(typeof(TextBlock));
        var party = new FrameworkElementFactory(typeof(Run));
        var hyphen = new FrameworkElementFactory(typeof(Run));
        var head = new FrameworkElementFactory(typeof(Run));
        var amount = new FrameworkElementFactory(typeof(TextBlock));

        col1.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        icon.SetValue(PathIcon.MarginProperty, new Thickness(0, 0, 5, 0));
        amount.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        partyHeadBlock.SetValue(Grid.ColumnProperty, 1);
        amount.SetValue(Grid.ColumnProperty, 2);
        hyphen.SetValue(Run.TextProperty, " - ");

        icon.SetBinding(PathIcon.IconProperty, new Binding(nameof(EntryPurchaseSell.IsConstruction)) {
            Converter = Converters.isContruction2Icon
        });
        party.SetBinding(Run.TextProperty, new Binding(nameof(EntryPurchaseSell.Party)));
        head.SetBinding(Run.TextProperty, new Binding(nameof(EntryPurchaseSell.Head)));
        amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryPurchaseSell.Amount)));

        partyHeadBlock.AppendChild(party);
        partyHeadBlock.AppendChild(hyphen);
        partyHeadBlock.AppendChild(head);
        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(icon);
        grid.AppendChild(partyHeadBlock);
        grid.AppendChild(amount);

        VisualTree = grid;
    }
}

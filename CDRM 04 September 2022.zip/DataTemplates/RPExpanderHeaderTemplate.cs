﻿class RPExpanderHeaderTemplate : DataTemplate
{
    public RPExpanderHeaderTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid" };
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var header = new FrameworkElementFactory(typeof(Run));
        var openParen = new FrameworkElementFactory(typeof(Run));
        var primaryCount = new FrameworkElementFactory(typeof(Run));
        var closeParen = new FrameworkElementFactory(typeof(Run));
        var hyphen = new FrameworkElementFactory(typeof(Run));
        var secondaryCount = new FrameworkElementFactory(typeof(Run));
        var headerBlock = new FrameworkElementFactory(typeof(TextBlock)) { Name = "header" };
        var totals = new FrameworkElementFactory(typeof(ContentControl)) { Name = "totals" };

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(2 * Constants.AmountColumnWidth));
        totals.SetValue(Grid.ColumnProperty, 1);
        totals.SetValue(ContentControl.ContentTemplateProperty, new SummaryTotalTemplate());

        headerBlock.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        header.SetValue(Run.FontWeightProperty, FontWeights.Bold);
        openParen.SetValue(Run.TextProperty, " (");
        closeParen.SetValue(Run.TextProperty, ")");
        hyphen.SetValue(Run.TextProperty, " - ");

        var source = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1);

        header.SetBinding(Run.TextProperty, new Binding("DataContext." + nameof(GroupItem.Name)) {
            Mode = BindingMode.OneWay,
            RelativeSource = source
        }); ;
        primaryCount.SetBinding(Run.TextProperty, new Binding("DataContext." + nameof(CollectionViewGroup.ItemCount)) {
            Mode = BindingMode.OneWay,
            RelativeSource = source
        });
        secondaryCount.SetBinding(Run.TextProperty, new Binding("DataContext." + nameof(CollectionViewGroup.Items)) {
            RelativeSource = source,
            Converter = Converters.rpSecondarySum,
            Mode = BindingMode.OneWay
        });
        totals.SetBinding(ContentControl.ContentProperty, new Binding("DataContext." + nameof(CollectionViewGroup.Items)) {
            RelativeSource = source,
            Converter = Converters.rpSummary,
            Mode = BindingMode.OneWay
        });

        headerBlock.AppendChild(header);
        headerBlock.AppendChild(openParen);
        headerBlock.AppendChild(primaryCount);
        headerBlock.AppendChild(hyphen);
        headerBlock.AppendChild(secondaryCount);
        headerBlock.AppendChild(closeParen);

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(headerBlock);
        grid.AppendChild(totals);

        VisualTree = grid;

        Triggers.Add(new Trigger() {
            Property = UIElement.IsMouseOverProperty,
            Value = true,
            Setters = {
                new Setter(Grid.BackgroundProperty, Constants.BackgroundDark, "grid")
            }
        });
    }
}

﻿class SummaryTotalTemplate : DataTemplate
{
    public SummaryTotalTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));

        var purchase = new FrameworkElementFactory(typeof(TextBlock));
        var sell = new FrameworkElementFactory(typeof(TextBlock));

        col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));

        sell.SetValue(Grid.ColumnProperty, 1);
        purchase.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
        purchase.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        purchase.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);

        sell.SetValue(Grid.ColumnProperty, 2);
        sell.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
        sell.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        sell.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);

        purchase.SetBinding(TextBlock.TextProperty, new Binding("Item1") { StringFormat = Constants.NumberFormat });
        sell.SetBinding(TextBlock.TextProperty, new Binding("Item2") { StringFormat = Constants.NumberFormat });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(purchase);
        grid.AppendChild(sell);
        VisualTree = grid;
    }
}

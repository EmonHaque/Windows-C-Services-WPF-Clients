﻿class RPSumEntryTemplate : DataTemplate
{
    public RPSumEntryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var particulars = new FrameworkElementFactory(typeof(HiBlock));
        var purchase = new FrameworkElementFactory(typeof(TextBlock));
        var sell = new FrameworkElementFactory(typeof(TextBlock));
        var party = new FrameworkElementFactory(typeof(Run));
        var openParen = new FrameworkElementFactory(typeof(Run));
        var count = new FrameworkElementFactory(typeof(Run));
        var closeParen = new FrameworkElementFactory(typeof(Run));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));

        particulars.SetValue(HiBlock.TextWrappingProperty, TextWrapping.Wrap);
        openParen.SetValue(Run.TextProperty, " (");
        closeParen.SetValue(Run.TextProperty, ")");
        purchase.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        sell.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        purchase.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        sell.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        purchase.SetValue(Grid.ColumnProperty, 1);
        sell.SetValue(Grid.ColumnProperty, 2);

        particulars.SetBinding(HiBlock.QueryProperty, new Binding("DataContext." + nameof(SummaryReceiptPaymentVM.Query)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ListBox), 1),
        });
        party.SetBinding(Run.TextProperty, new Binding(nameof(SumReceiptPayment.SecondaryGroup)));
        count.SetBinding(Run.TextProperty, new Binding(nameof(SumReceiptPayment.Count)));
        purchase.SetBinding(TextBlock.TextProperty, new Binding(nameof(SumReceiptPayment.Payment)) { StringFormat = Constants.NumberFormat });
        sell.SetBinding(TextBlock.TextProperty, new Binding(nameof(SumReceiptPayment.Receipt)) { StringFormat = Constants.NumberFormat });
        grid.SetValue(Grid.ToolTipProperty, new RPToolTip());

        particulars.AppendChild(party);
        particulars.AppendChild(openParen);
        particulars.AppendChild(count);
        particulars.AppendChild(closeParen);

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(particulars);
        grid.AppendChild(purchase);
        grid.AppendChild(sell);
        VisualTree = grid;
    }
}

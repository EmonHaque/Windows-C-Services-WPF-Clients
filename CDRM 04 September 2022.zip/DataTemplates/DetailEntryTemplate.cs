﻿class DetailEntryTemplate : DataTemplate
{
    public DetailEntryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var date = new FrameworkElementFactory(typeof(TextBlock));
        var particulars = new FrameworkElementFactory(typeof(TextBlock));
        var purchase = new FrameworkElementFactory(typeof(TextBlock));
        var sell = new FrameworkElementFactory(typeof(TextBlock));

        col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.DateColumnWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));

        particulars.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        purchase.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        sell.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        purchase.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        sell.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);

        particulars.SetValue(Grid.ColumnProperty, 1);
        purchase.SetValue(Grid.ColumnProperty, 2);
        sell.SetValue(Grid.ColumnProperty, 3);

        date.SetBinding(TextBlock.TextProperty, new Binding(nameof(SumPurchaseSellDetail.Date)) { StringFormat = "dd MMM yyy" });
        particulars.SetBinding(TextBlock.TextProperty, new Binding(nameof(SumPurchaseSellDetail.Particulars)));
        purchase.SetBinding(TextBlock.TextProperty, new Binding(nameof(SumPurchaseSellDetail.Purchase)) { StringFormat = Constants.NumberFormat });
        sell.SetBinding(TextBlock.TextProperty, new Binding(nameof(SumPurchaseSellDetail.Sell)) { StringFormat = Constants.NumberFormat });
        grid.SetBinding(Grid.ToolTipProperty, new Binding(nameof(SumPurchaseSellDetail.Narration)));

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(date);
        grid.AppendChild(particulars);
        grid.AppendChild(purchase);
        grid.AppendChild(sell);
        VisualTree = grid;
    }
}

﻿class EditEntrySelector : DataTemplateSelector
{
    public override DataTemplate SelectTemplate(object item, DependencyObject container) {
        if (item is EntryPurchaseSell) return new PurchaseSellEditTemplate();
        else return new ReceiptPaymentEditTemplate();
    }
}

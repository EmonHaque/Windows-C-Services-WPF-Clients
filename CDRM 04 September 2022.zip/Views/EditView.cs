﻿class EditView : ViewContainer
{
    override public string Icon => Icons.Edit;
    public EditView() {
        Children.Add(new EditSite());
        Children.Add(new EditParty());
        Children.Add(new EditHead());
        Children.Add(new EditSubHead());
        Children.Add(new EditUnit());
        Children.Add(new EditEntry());
    }
}

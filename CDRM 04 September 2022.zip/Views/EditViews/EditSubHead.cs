﻿class EditSubHead : EditBase<SubHead>
{
    public override string Header => "Subhead";
    public override string Icon => Icons.Head;

    EditSubHeadVM vm;
    EditNameControl name;
    protected override IEdit<SubHead> viewModel => vm;
    protected override EditNameControl editElement => name;
    protected override void initialize() {
        vm = new EditSubHeadVM();
        name = new EditNameControl();
    }
}

﻿class EditParty : EditBase<Party>
{
    public override string Header => "Party";
    public override string Icon => Icons.Tenant;

    EditPartyVM vm;
    EditPartyControl party;
    protected override IEdit<Party> viewModel => vm;
    protected override EditNameControl editElement => party;
    protected override void initialize() {
        vm = new EditPartyVM();
        party = new EditPartyControl();
    }
}

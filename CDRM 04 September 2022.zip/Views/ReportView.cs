﻿class ReportView : ViewContainer
{
    override public string Icon => Icons.Ledger;

    public ReportView() {
        Children.Add(new SummaryViews());
        Children.Add(new ReportParty());
    }
}

class SummaryViews : View
{
    override public string Icon => Icons.Sigma;
    public override FrameworkElement container => grid;
    Grid grid;
    public SummaryViews() : base() {
        var purchaseSellNotes = new ViewContainer(NavPosition.BottomRightVertical, NavOverlap.Right) {
            IconSize = 12,
            IconGap = 5,
            Children = {
                new SummaryPurchaseSell(),
                new Notes()
            }
        };
        var transactions = new ViewContainer(NavPosition.TopLeftVertical, NavOverlap.Left) {
            IconSize = 12,
            IconGap = 5,
            Children = {
                new SummaryReceiptPayment(),
                new SummaryDue()
            }
        };

        Grid.SetColumn(transactions, 1);
        grid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(){Width = new GridLength(2, GridUnitType.Star)},
                    new ColumnDefinition(),
                },
            Children = { purchaseSellNotes, transactions }
        };
        AddVisualChild(grid);
    }
}

﻿class AllSite : CardView
{
    public override string Icon => Icons.Construction;

    TextBlock totalBlock;
    Run total;
    MultiState state;
    DayPicker from, to;
    ActionButton refresh;
    PieChart chart;
    AllSiteVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new AllSiteVM();
        DataContext = vm;
        initializeUI();
        bind();
    }
    void initializeUI() {
        var label = new TextBlock() {
            Text = "Purchase / Payable",
            FontSize = 14,
            VerticalAlignment = VerticalAlignment.Bottom,
            LayoutTransform = new RotateTransform(-90),
            IsHitTestVisible = false
        };
        #region first Row
        from = new DayPicker() {
            DateFormat = "dd/MM/yyyy",
            Hint = "from"
        };
        to = new DayPicker() {
            DateFormat = "dd/MM/yyyy",
            Hint = "to"
        };
        refresh = new ActionButton() {
            Margin = new Thickness(5, 0, 0, 0),
            Icon = Icons.Refresh,
            Command = vm.Refresh,
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetColumn(to, 1);
        Grid.SetColumn(refresh, 2);
        var firstRow = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto }
            },
            Children = { from, to, refresh }
        };
        #endregion
        state = new MultiState() {
            Icons = new string[] { Icons.Construction, Icons.Development, Icons.Repair, Icons.Maintenance, Icons.All },
            Texts = new string[] { "Construction", "Development", "Repair", "Maintenance", "All" },
            IsIconInfront = true,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Top
        };
        chart = new PieChart() /*{ IsSelectable = true }*/;

        #region bottom Row
        total = new Run();
        totalBlock = new TextBlock() {
            Inlines = { "Total ", total },
            HorizontalAlignment = HorizontalAlignment.Right
        };
      
        #endregion
        Grid.SetRowSpan(label, 3);
        Grid.SetRow(state, 1);
        Grid.SetRow(chart, 1);
        Grid.SetRow(totalBlock, 2);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { label, firstRow, state, chart, totalBlock }
        };
        setContent(grid);
    }
    void bind() {
        total.SetBinding(Run.TextProperty, new Binding(nameof(vm.Total)) { StringFormat = Constants.NumberFormat });
        state.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.State)));
        from.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.From)));
        to.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.To)));
        chart.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(vm.Data)));
    }
}

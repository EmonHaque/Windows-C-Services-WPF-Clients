﻿class ConfirmCreationDialog : Window
{
    List<ValidationError> error;
    ActionButton okButton, cancelButton;
    ListBox box;
    TextBlock confirmBlock;

    public ConfirmCreationDialog(double left, double top, double width, double height, List<ValidationError> e) {
        error = e;
        Left = left;
        Top = top;
        Width = width;
        Height = height;
        Owner = App.Current.MainWindow;
        ShowInTaskbar = false;
        AllowsTransparency = true;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        Background = new SolidColorBrush(Color.FromArgb(127, 0, 0, 0));
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            GlassFrameThickness = new Thickness(0),
            CornerRadius = new CornerRadius(7),
            ResizeBorderThickness = new Thickness(0),
            CaptionHeight = 0
        });
        initializeContent();
    }

    void initializeContent() {
        string thisOrThese = error.Count > 1 ? "these" : "this";
        confirmBlock = new TextBlock() {
            Margin = new Thickness(10, 0, 0, 0),
            Text = $"Do you wan to create {thisOrThese}?",
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            FontWeight = FontWeights.Bold
        };
        okButton = new ActionButton() {
            Margin = new Thickness(10, 0, 0, 0),
            Width = 16,
            Height = 16,
            Icon = Icons.Checked,
            HorizontalAlignment = HorizontalAlignment.Left,
            ToolTip = "Yes",
            Command = () => {
                DialogResult = true;
                Close();
            }
        };
        cancelButton = new ActionButton() {
            Margin = new Thickness(5, 0, 6, 0),
            Width = 16,
            Height = 16,
            HorizontalAlignment = HorizontalAlignment.Right,
            Icon = Icons.CloseCircle,
            ToolTip = "No",
            Command = () => {
                DialogResult = false;
                Close();
            }
        };
        var buttonPanel = new Grid() {
            Margin = new Thickness(0, 5, 5, 5),
            Children = { okButton, confirmBlock, cancelButton }
        };
        box = new ListBox() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Center,
            BorderThickness = new Thickness(0),
            Margin = new Thickness(15, 0, 15, 0),
            ItemTemplate = new ValidationErrorTemplate(),
            ItemsSource = error
        };
        box.SetValue(Grid.IsSharedSizeScopeProperty, true);
        box.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto);
        box.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        Grid.SetRow(buttonPanel, 1);
        //Grid.SetRow(confirmBlock, 1);

        Content = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto }
            },
            Children = { box, buttonPanel }
        };
    }
}

﻿class HorizontalBarChart : FrameworkElement
{
    int numSteps = 5;
    ItemsControl items;
    CountBlock itemsCount;
    TextBlock total;
    StackPanel countTotal;
    VisualCollection visuals;
    HorizontalBar selected;

    public HorizontalBarChart() {
        visuals = new VisualCollection(this);
        addSideLabel();
        addTicks();
        addLines();
        items = new ItemsControl() {
            ItemTemplate = new HorizontalBarTemplate(),
            ItemsPanel = new ItemsPanelTemplate(new FrameworkElementFactory(typeof(VirtualizingStackPanel))),
            Template = new EnumerableBoxTemplate(),
            Resources = {
                {
                    typeof(ScrollViewer),
                    new Style(typeof(ScrollViewer)) {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                        }
                    }
                }
            }
        };
        itemsCount = new CountBlock() { 
            //Padding = new Thickness(5),
            Margin = new Thickness(0,0,10,0)
        };
        total = new TextBlock() { VerticalAlignment = VerticalAlignment.Center };
        countTotal = new StackPanel() {
            Orientation = Orientation.Horizontal,
            Children = {itemsCount, total }
        };
        visuals.Add(items);
        visuals.Add(countTotal);
        items.SetBinding(ItemsControl.ItemsSourceProperty, new Binding(nameof(ItemsSource)) { Source = this });
        itemsCount.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Source = items });
    }

    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        if (selected is null) return;
        var view = (ICollectionView)sender;
        //update totals
        foreach (KeyValueSeries item in view) {
            if (selected.Content.Key.Equals(item.Key)) {
                Dispatcher.InvokeAsync(() => {
                    var container = items.ItemContainerGenerator.ContainerFromItem(item);
                    var bar = Helper.FindVisualChild<HorizontalBar>(container);
                    bar.IsSelected = true;
                    selected = bar;
                }, DispatcherPriority.Background);
                break;
            }
        }
    }
    void addLines() {
        for (int i = 0; i < numSteps; i++) {
            var line = new Line() {
                StrokeThickness = 0.25,
                Stroke = Brushes.CornflowerBlue,
                StrokeDashCap = PenLineCap.Flat,
                StrokeDashArray = new DoubleCollection(new List<double> { 10, 5 }),
                IsHitTestVisible = false
            };
            visuals.Add(line);
        }
    }
    void addTicks() {
        for (int i = 0; i < numSteps; i++) {
            var tick = new TextBlock() {
                Tag = "Tick",
                Margin = new Thickness(1,0,0,0),
                RenderTransform = new RotateTransform(90),
                IsHitTestVisible = false
            };
            visuals.Add(tick);
        }
    }
    void addSideLabel() {
        var label = new TextBlock() {
            Text = "Purchase / Payable",
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Tag = "X1Label",
            Margin = new Thickness(0, 0, 0, 5),
            IsHitTestVisible = false
        };
        visuals.Add(label);
    }
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
        if (e.OriginalSource is HorizontalBar) {
            var clicked = (HorizontalBar)e.OriginalSource;
            if (selected is not null) {
                if (selected.Equals(clicked)) {
                    selected = null;
                    Selected = null;
                    return;
                }
                selected.IsSelected = false;
            }
            selected = clicked;
            Selected = selected.Content;
        }
        else base.OnMouseLeftButtonUp(e);
    }
    protected override Size ArrangeOverride(Size finalSize) {
        double tickHeight = 0; 
        double sideLabelHeight = 0;
        double keyWidth = Constants.HorizontalBarKeyWidth;
        double lineX = keyWidth;
        double blockX = keyWidth;
        double lineStep = (finalSize.Width - keyWidth - Constants.ScrollBarThickness - Constants.ScrollPresenterMargin) / (numSteps - 1);

        foreach (UIElement item in visuals) {
            if (item is TextBlock block) {
                if (block.Tag.Equals("Tick")) {
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(blockX + block.DesiredSize.Height, sideLabelHeight), item.DesiredSize));
                    blockX += lineStep;
                    if (tickHeight < block.DesiredSize.Width) {
                        tickHeight = block.DesiredSize.Width;
                    }
                }
                else if (block.Tag.Equals("X1Label")) {
                    block.Measure(finalSize);
                    sideLabelHeight = block.DesiredSize.Height;
                    var x = keyWidth + (finalSize.Width - keyWidth) / 2 - block.DesiredSize.Width / 2;
                    block.Arrange(new Rect(new Point(x, 0), block.DesiredSize));
                }
            }
            else if(item is Line line) {
                line.Y1 = sideLabelHeight;
                line.Y2 = finalSize.Height;
                line.X1 = line.X2 = lineX;
                line.Measure(finalSize);
                line.Arrange(new Rect(line.DesiredSize));
                lineX += lineStep;
            }
            else if (item is ItemsControl control) {
                double marginTop = sideLabelHeight + tickHeight + 10;
                control.Width = finalSize.Width;
                control.Height = finalSize.Height - marginTop;
                control.Measure(finalSize);
                control.Arrange(new Rect(new Point(0, marginTop), control.DesiredSize));
            }
            else if (item is StackPanel count) {
                count.Measure(finalSize);
                double marginTop = sideLabelHeight + tickHeight + 10;
                var y = marginTop / 2 - count.DesiredSize.Height / 2;
                count.Arrange(new Rect(new Point(0, y), count.DesiredSize));
            }
        }
        return finalSize;
    }
    protected override int VisualChildrenCount => visuals.Count;
    protected override Visual GetVisualChild(int index) => visuals[index];

    #region DependencyProperties
    public static readonly DependencyProperty MaxValueProperty;
    public static readonly DependencyProperty ItemsSourceProperty;


    public object Selected {
        get { return (object)GetValue(SelectedProperty); }
        set { SetValue(SelectedProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Selected.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty SelectedProperty =
        DependencyProperty.Register("Selected", typeof(object), typeof(HorizontalBarChart));


    static HorizontalBarChart() {
        MaxValueProperty = DependencyProperty.Register("MaxValue", typeof(int), typeof(HorizontalBarChart));
        ItemsSourceProperty = DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(HorizontalBarChart), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onSourceChanged
        });
    }

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (HorizontalBarChart)d;
        if(e.OldValue is not null) {
            ((ICollectionView)e.OldValue).CollectionChanged -= o.onCollectionChanged;
        }
        if (e.NewValue is not null) {
            var items = (ICollectionView)e.NewValue;
            int max = 0;
            int total = 0;
            foreach (KeyValueSeries item in items) {
                if (max < item.Value) max = item.Value;
                total += item.Value;
            }
            var step = (double)max / (o.numSteps - 1);
            double current = 0;
            foreach (var item in o.visuals) {
                if (item is TextBlock block) {
                    if (!block.Tag.Equals("Tick")) continue;
                    block.Text = Math.Ceiling(current).ToString("N0");
                    current += step;
                }
            }
            o.MaxValue = max;
            o.total.Text = total.ToString("N0");
            items.CollectionChanged += o.onCollectionChanged;
        }
    }

    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public int MaxValue {
        get { return (int)GetValue(MaxValueProperty); }
        set { SetValue(MaxValueProperty, value); }
    }
    #endregion
}

﻿class HorizontalBarTemplate : DataTemplate
{
    public HorizontalBarTemplate() {
        var bar = new FrameworkElementFactory(typeof(HorizontalBar));
        bar.SetBinding(HorizontalBar.MaxProperty, new Binding(nameof(HorizontalBarChart.MaxValue)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(HorizontalBarChart), 1)
        });
        VisualTree = bar;
    }
}

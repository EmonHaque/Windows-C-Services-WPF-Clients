﻿class EnumerableBoxTemplate : ControlTemplate
{
    public EnumerableBoxTemplate() {
        TargetType = typeof(ItemsControl);
        var scrollViewer = new FrameworkElementFactory(typeof(ScrollViewer));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));
        scrollViewer.AppendChild(items);
        VisualTree = scrollViewer;
    }
}
﻿class EditSiteControl : EditNameControl
{
    protected TextBlock address;
    protected TextBox editAddress;

    protected override void addNormalControls() {
        base.addNormalControls();
        address = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            TextAlignment = TextAlignment.Center,
            TextWrapping = TextWrapping.Wrap
        };
        normalControls.Children.Add(address);
    }
    protected override void addEditableControls() {
        base.addEditableControls();
        editAddress = new TextBox();
        editableControls.Children.Add(editAddress);
    }
    protected override void bind() {
        base.bind();
        address.SetBinding(TextBlock.TextProperty, new Binding(nameof(IHaveAddress.Address)));
        editAddress.SetBinding(TextBox.TextProperty, new Binding(nameof(IHaveAddress.Address)) {
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
    }
    protected override void addErrors() {
        base.addErrors();
        var address = objectType.GetProperty(nameof(IHaveAddress.Address)).GetValue(Edited, null).ToString();
        if (string.IsNullOrWhiteSpace(address)) {
            errors.Add(new ValidationError() {
                Head = nameof(IHaveAddress.Address),
                Error = "cannot be empty"
            });
        }
    }
}

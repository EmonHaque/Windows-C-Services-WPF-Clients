﻿class EditPartyControl : EditSiteControl
{
    TextBlock phone;
    TextBox editPhone;

    protected override void addNormalControls() {
        base.addNormalControls();
        phone = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            TextAlignment = TextAlignment.Center,
            TextWrapping = TextWrapping.Wrap
        };
        normalControls.Children.Add(phone);
    }
    protected override void addEditableControls() {
        base.addEditableControls();
        editPhone = new TextBox();
        editableControls.Children.Add(editPhone);
    }
    protected override void bind() {
        base.bind();
        phone.SetBinding(TextBlock.TextProperty, new Binding(nameof(Party.Phone)));
        editPhone.SetBinding(TextBox.TextProperty, new Binding(nameof(Party.Phone)) {
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
    }
}

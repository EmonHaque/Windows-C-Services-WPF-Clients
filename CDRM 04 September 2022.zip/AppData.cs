﻿class AppData : AppDataBase
{
    static Site theSite;
    static Party theParty;
    static Head theHead;
    static SubHead theSubHead;
    static Unit theUnit;
    static NoteType theNoteType;

    public static ObservableCollection<Site> sites;
    public static ObservableCollection<Party> parties;
    public static ObservableCollection<Head> heads;
    public static ObservableCollection<SubHead> subHeads;
    public static ObservableCollection<Unit> units;
    public static ObservableCollection<NoteType> noteTypes;

    public event Action<Note> NoteAdded, NoteEdited;
    public event Action<int> NoteDeleted, EntryDeleted;

    protected override void initializeCollections() {
        sites = new ObservableCollection<Site>();
        parties = new ObservableCollection<Party>();
        heads = new ObservableCollection<Head>();
        subHeads = new ObservableCollection<SubHead>();
        units = new ObservableCollection<Unit>();
        noteTypes = new ObservableCollection<NoteType>();
    }
    protected override void populateCollections() {
        ReadOnlySpan<byte> siteSpan, partySpan, headSpan, subHeadSpan, unitSpan, noteTypeSpan;
        try {
            siteSpan = new ReadOnlySpan<byte>(getPacket());
            partySpan = new ReadOnlySpan<byte>(getPacket());
            headSpan = new ReadOnlySpan<byte>(getPacket());
            subHeadSpan = new ReadOnlySpan<byte>(getPacket());
            unitSpan = new ReadOnlySpan<byte>(getPacket());
            noteTypeSpan = new ReadOnlySpan<byte>(getPacket());
        }
        catch {
            patch.Invoke(() => { window.Text = "service down"; });
            Thread.Sleep(2000);
            patch.Invoke(() => { window.Text = "quitting"; });
            Thread.Sleep(2000);
            patch.Invoke(() => {
                window.Close();
                App.Current.Shutdown();
            });
            return;
        }
        patch.Invoke(() => { window.Text = "here"; });
        int read, start;
        read = start = 0;

        patch.Invoke(() => { window.Text = "listing sites"; });
        Thread.Sleep(250);
        #region Site
        while (read < siteSpan.Length) {
            var id = BitConverter.ToInt32(siteSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (siteSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(siteSpan.Slice(start, read - start));

            start = ++read;
            while (siteSpan[read] != 0) read++;
            var address = Encoding.ASCII.GetString(siteSpan.Slice(start, read - start));

            patch.Invoke(() => {
                sites.Add(new Site() {
                    Id = id,
                    Name = name,
                    Address = address
                });
            });
            start = ++read;
        }
        #endregion

        read = start = 0;
        patch.Invoke(() => { window.Text = "listing parties"; });
        Thread.Sleep(250);
        #region Party
        while (read < partySpan.Length) {
            var id = BitConverter.ToInt32(partySpan.Slice(start, 4));
            read += 4;
            start = read;
            while (partySpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(partySpan.Slice(start, read - start));

            start = ++read;
            while (partySpan[read] != 0) read++;
            var address = Encoding.ASCII.GetString(partySpan.Slice(start, read - start));

            start = ++read;
            while (partySpan[read] != 0) read++;
            var phone = Encoding.ASCII.GetString(partySpan.Slice(start, read - start));

            patch.Invoke(() => {
                parties.Add(new Party() {
                    Id = id,
                    Name = name,
                    Address = address,
                    Phone = phone
                });
            });
            start = ++read;
        }
        #endregion

        read = start = 0;
        patch.Invoke(() => { window.Text = "listing heads"; });
        Thread.Sleep(250);
        #region Head
        while (read < headSpan.Length) {
            var id = BitConverter.ToInt32(headSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (headSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(headSpan.Slice(start, read - start));

            patch.Invoke(() => {
                heads.Add(new Head() {
                    Id = id,
                    Name = name
                });
            });
            start = ++read;
        }
        #endregion

        read = start = 0;
        patch.Invoke(() => { window.Text = "listing subheads"; });
        Thread.Sleep(250);
        #region SubHead
        while (read < subHeadSpan.Length) {
            var id = BitConverter.ToInt32(subHeadSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (subHeadSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(subHeadSpan.Slice(start, read - start));

            patch.Invoke(() => {
                subHeads.Add(new SubHead() {
                    Id = id,
                    Name = name
                });
            });
            start = ++read;
        }
        #endregion

        read = start = 0;
        patch.Invoke(() => { window.Text = "listing units"; });
        Thread.Sleep(250);
        #region Unit
        while (read < unitSpan.Length) {
            var id = BitConverter.ToInt32(unitSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (unitSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(unitSpan.Slice(start, read - start));

            patch.Invoke(() => {
                units.Add(new Unit() {
                    Id = id,
                    Name = name
                });
            });
            start = ++read;
        }
        #endregion

        read = start = 0;
        patch.Invoke(() => { window.Text = "listing note types"; });
        Thread.Sleep(250);
        #region NoteType
        while (read < noteTypeSpan.Length) {
            var id = BitConverter.ToInt32(noteTypeSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (noteTypeSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(noteTypeSpan.Slice(start, read - start));

            patch.Invoke(() => {
                noteTypes.Add(new NoteType() {
                    Id = id,
                    Name = name
                });
            });
            start = ++read;
        }
        #endregion
    }
    protected override void processMessage() {
        while (isConnected) {
            var packet = new ReadOnlySpan<byte>(messages.Take());
            var message = (Function)BitConverter.ToInt32(packet.Slice(0, 4));
            var slice = packet.Slice(4);
            switch (message) {
                case Function.AddSite: addSite(slice); break;
                case Function.AddParty: addParty(slice); break;
                case Function.AddHead: addHead(slice); break;
                case Function.AddSubHead: addSubHead(slice); break;
                case Function.AddUnit: addUnit(slice); break;
                case Function.AddNoteType: addNoteType(slice); break;
                case Function.AddNote: addNote(slice); break;

                case Function.EditSite: editSite(slice); break;
                case Function.EditParty: editParty(slice); break;
                case Function.EditHead: editHead(slice); break;
                case Function.EditSubHead: editSubHead(slice); break;
                case Function.EditUnit: editUnit(slice); break;
                case Function.EditNote: editNote(slice); break;

                case Function.DeleteNote: deleteNote(slice); break;
                case Function.DeletePurchaseSell: deletePurchaseSell(slice); break;
                case Function.DeleteReceiptPayment: deleteReceiptPayment(slice); break;
            }
        }
    }

    void addSite(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var site = array.Slice(4).ToSite();
        patch.Invoke(() => sites.Add(site));
    }
    void addParty(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var party = array.Slice(4).ToParty();
        patch.Invoke(() => parties.Add(party));
    }
    void addHead(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var head = array.Slice(4).ToHead();
        patch.Invoke(() => heads.Add(head));
    }
    void addSubHead(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var subHead = array.Slice(4).ToSubhead();
        patch.Invoke(() => subHeads.Add(subHead));
    }
    void addUnit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var unit = array.Slice(4).ToUnit();
        patch.Invoke(() => units.Add(unit));
    }
    void addNoteType(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var type = array.Slice(4).ToNoteType();
        patch.Invoke(() => noteTypes.Add(type));
    }
    void addNote(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var note = array.Slice(4).ToNote();
        patch.Invoke(() => NoteAdded?.Invoke(note));
    }

    void editSite(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var edited = array.Slice(4).ToSite();
        var original = sites.First(x => x.Id == edited.Id);

        original.Name = edited.Name;
        original.Address = edited.Address;
        original.OnPropertyChanged(null);
    }
    void editParty(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var edited = array.Slice(4).ToParty();
        var original = parties.First(x => x.Id == edited.Id);

        original.Name = edited.Name;
        original.Address = edited.Address;
        original.Phone = edited.Phone;
        original.OnPropertyChanged(null);
    }
    void editHead(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var edited = array.Slice(4).ToHead();
        var original = heads.First(x => x.Id == edited.Id);

        original.Name = edited.Name;
        original.OnPropertyChanged(nameof(IHaveName.Name));
    }
    void editSubHead(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var edited = array.Slice(4).ToSubhead();
        var original = subHeads.First(x => x.Id == edited.Id);

        original.Name = edited.Name;
        original.OnPropertyChanged(nameof(IHaveName.Name));
    }
    void editUnit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var edited = array.Slice(4).ToUnit();
        var original = units.First(x => x.Id == edited.Id);

        original.Name = edited.Name;
        original.OnPropertyChanged(nameof(IHaveName.Name));
    }
    void editNote(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var note = array.Slice(4).ToNote();
        patch.Invoke(() => NoteEdited?.Invoke(note));
    }
    
    void deleteNote(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var noteId = BitConverter.ToInt32(array.Slice(4));
        patch.Invoke(() => NoteDeleted?.Invoke(noteId));
    }
    void deletePurchaseSell(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var id = BitConverter.ToInt32(array.Slice(4));
        patch.Invoke(() => EntryDeleted?.Invoke(id));
    }
    void deleteReceiptPayment(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var id = BitConverter.ToInt32(array.Slice(4));
        patch.Invoke(() => EntryDeleted?.Invoke(id));
    }

    public static bool HasSite(string name) {
        theSite = sites.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theSite is not null;
    }
    public static bool HasParty(string name) {
        theParty = parties.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theParty is not null;
    }
    public static bool HasHead(string name) {
        theHead = heads.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theHead is not null;
    }
    public static bool HasSubHead(string name) {
        theSubHead = subHeads.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theSubHead is not null;
    }
    public static bool HasUnit(string name) {
        theUnit = units.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theUnit is not null;
    }
    public static bool HasNoteTye(string name) {
        theNoteType = noteTypes.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theNoteType is not null;
    }

    public static Site GetSite() => theSite;
    public static Party GetParty() => theParty;
    public static Head GetHead() => theHead;
    public static SubHead GetSubHead() => theSubHead;
    public static Unit GetUnit() => theUnit;
    public static NoteType GetNoteType() => theNoteType;
}

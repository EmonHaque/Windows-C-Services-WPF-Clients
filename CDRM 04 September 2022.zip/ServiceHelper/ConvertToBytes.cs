﻿static class ConvertToBytes
{
    public static List<ArraySegment<byte>> ToBytes(this Due due) {
        return new List<ArraySegment<byte>>() {
            new byte[1]{ due.IsSell },
            new byte[1]{ due.IsConstruction },
            BitConverter.GetBytes(due.Purchase),
            BitConverter.GetBytes(due.Sell),
            BitConverter.GetBytes(due.Quantity),
            Encoding.ASCII.GetBytes(due.Date.ToString("yyyy-MM-dd") + '\0'),
            Encoding.ASCII.GetBytes(due.Site + '\0'),
            Encoding.ASCII.GetBytes(due.Party + '\0'),
            Encoding.ASCII.GetBytes(due.Head + '\0'),
            Encoding.ASCII.GetBytes(due.SubHead + '\0'),
            Encoding.ASCII.GetBytes(due.Unit + '\0'),
            Encoding.ASCII.GetBytes(due.Narration + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this ReportDates dates) {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(dates.From.Value.ToString("yyyy-MM-dd") + '\0'),
            Encoding.ASCII.GetBytes(dates.Start.ToString("yyyy-MM-dd") + '\0'),
            Encoding.ASCII.GetBytes(dates.To.Value.ToString("yyyy-MM-dd") + '\0'),
            Encoding.ASCII.GetBytes(dates.End.ToString("yyyy-MM-dd") + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this EntryInsert entry) {
        var narration = string.IsNullOrWhiteSpace(entry.Narration) ? "" : entry.Narration;
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(entry.IsTopLevel),
            new byte[1]{ entry.IsCash },
            new byte[1]{ entry.IsSell },
            new byte[1]{ entry.IsConstruction },
            new byte[1]{ entry.IsReceipt },
            BitConverter.GetBytes(entry.Amount),
            BitConverter.GetBytes(entry.SiteId),
            BitConverter.GetBytes(entry.PartyId),
            BitConverter.GetBytes(entry.HeadId),
            BitConverter.GetBytes(entry.SubHeadId),
            BitConverter.GetBytes(entry.UnitId),
            BitConverter.GetBytes(entry.Quantity),
            Encoding.ASCII.GetBytes(entry.Date + '\0'),
            Encoding.ASCII.GetBytes(narration + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this List<EntryInsert> entries) {
        var bytes = new List<ArraySegment<byte>>();
        foreach (var e in entries) bytes.AddRange(e.ToBytes());
        return bytes;
    }
    public static List<ArraySegment<byte>> ToBytes(this Note note) {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(note.Id),
            BitConverter.GetBytes(note.SiteId),
            BitConverter.GetBytes(note.NoteTypeId),
            Encoding.ASCII.GetBytes(note.Date.ToString("yyyy-MM-dd") + '\0'),
            Encoding.ASCII.GetBytes(note.Entry + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this Site site) {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(site.Id),
            Encoding.ASCII.GetBytes(site.Name + '\0'),
            Encoding.ASCII.GetBytes(site.Address + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this Party party) {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(party.Id),
            Encoding.ASCII.GetBytes(party.Name + '\0'),
            Encoding.ASCII.GetBytes(party.Address + '\0'),
            Encoding.ASCII.GetBytes(party.Phone + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this Head head) {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(head.Id),
            Encoding.ASCII.GetBytes(head.Name + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this SubHead subHead) {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(subHead.Id),
            Encoding.ASCII.GetBytes(subHead.Name + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this Unit unit) {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(unit.Id),
            Encoding.ASCII.GetBytes(unit.Name + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this NoteType type) {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(type.Id),
            Encoding.ASCII.GetBytes(type.Name + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this EntryPurchaseSell entry) {
        double quantity = 0;
        if (!string.IsNullOrWhiteSpace(entry.Quantity)) {
            quantity = double.Parse(entry.Quantity);
        }
        return new List<ArraySegment<byte>>() {
            new byte[1]{ entry.IsSell },
            new byte[1]{ entry.IsConstruction },
            BitConverter.GetBytes(entry.Id),
            BitConverter.GetBytes(entry.SiteId),
            BitConverter.GetBytes(entry.PartyId),
            BitConverter.GetBytes(entry.HeadId),
            BitConverter.GetBytes(entry.SubHeadId),
            BitConverter.GetBytes(entry.UnitId),
            BitConverter.GetBytes(int.Parse(entry.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat)),
            BitConverter.GetBytes(quantity),
            Encoding.ASCII.GetBytes(entry.Date.Value.ToString("yyyy-MM-dd") + '\0'),
            Encoding.ASCII.GetBytes(entry.Narration + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this EntryReceiptPayment entry) {
        return new List<ArraySegment<byte>>() {
            new byte[1]{ entry.IsReceipt },
            new byte[1]{ entry.IsCash },
            BitConverter.GetBytes(entry.Id),
            BitConverter.GetBytes(entry.PartyId),
            BitConverter.GetBytes(entry.HeadId),
            BitConverter.GetBytes(int.Parse(entry.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat)),
            Encoding.ASCII.GetBytes(entry.Date.Value.ToString("yyyy-MM-dd") + '\0'),
            Encoding.ASCII.GetBytes(entry.Narration + '\0')
        };
    }
}

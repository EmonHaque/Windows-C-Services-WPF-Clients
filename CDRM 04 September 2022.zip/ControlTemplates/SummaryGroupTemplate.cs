﻿class SummaryGroupTemplate : ControlTemplate
{
    DependencyPropertyDescriptor groupDescriptor;
    Dictionary<string, bool> expandStates = new();

    public SummaryGroupTemplate(MultiState primaryGroup) {
        TargetType = typeof(GroupItem);
        var expander = new FrameworkElementFactory(typeof(Expander)) { Name = "exp" };
        var border = new FrameworkElementFactory(typeof(Border));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));

        expander.SetValue(Expander.MarginProperty, new Thickness(5, 0, 0, 0));
        expander.SetValue(Expander.TemplateProperty, new ExpanderTemplate());
        expander.SetValue(Expander.HeaderTemplateProperty, new SummaryExpanderHeaderTemplate());
        border.SetValue(Border.BorderBrushProperty, Brushes.LightGray);
        border.SetValue(Border.BorderThicknessProperty, new Thickness(0, Constants.BottomLineThickness, 0, 0));
        expander.SetBinding(Expander.IsExpandedProperty, new Binding(nameof(Expander.Tag)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(GroupItem), 1),
            TargetNullValue = false,
            //FallbackValue = false
        });

        border.AppendChild(items);
        expander.AppendChild(border);
        VisualTree = expander;

        groupDescriptor = DependencyPropertyDescriptor.FromProperty(MultiState.StateProperty, typeof(MultiState));
        groupDescriptor.AddValueChanged(primaryGroup, onGroupChanged);
        expander.AddHandler(Expander.LoadedEvent, new RoutedEventHandler(onExpanderLoaded));
        expander.AddHandler(Expander.ExpandedEvent, new RoutedEventHandler(onIsExpandChanged));
        expander.AddHandler(Expander.CollapsedEvent, new RoutedEventHandler(onIsExpandChanged));
        // do you have to unsubscribe?
        expander.AddHandler(Expander.UnloadedEvent, new RoutedEventHandler(onExpanderUnloaded));
    }


    void onGroupChanged(object? sender, EventArgs e) {
        expandStates.Clear();
    }
    void onExpanderLoaded(object sender, RoutedEventArgs e) {
        var expander = (Expander)sender;
        var context = (CollectionViewGroup)expander.DataContext;

        var group = context.Name.ToString();
        if (expandStates.ContainsKey(group)) {
            expander.IsExpanded = expandStates[group];
        }
        else expandStates.Add(group, expander.IsExpanded);
    }
    void onIsExpandChanged(object sender, RoutedEventArgs e) {
        var expander = (Expander)sender;
        var context = (CollectionViewGroup)expander.DataContext;
        var group = context.Name.ToString();
        expandStates[group] = expander.IsExpanded;
    }
    void onExpanderUnloaded(object sender, RoutedEventArgs e) {
        var expander = (Expander)sender;
        expander.RemoveHandler(Expander.LoadedEvent, (RoutedEventHandler)onExpanderLoaded);
        expander.RemoveHandler(Expander.ExpandedEvent, (RoutedEventHandler)onIsExpandChanged);
        expander.RemoveHandler(Expander.CollapsedEvent, (RoutedEventHandler)onIsExpandChanged);
        expander.RemoveHandler(Expander.UnloadedEvent, (RoutedEventHandler)onExpanderUnloaded);
    }
}

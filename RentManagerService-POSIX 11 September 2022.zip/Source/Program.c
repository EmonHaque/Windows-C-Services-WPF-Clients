#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
//#include <sys/resource.h>
#include <pthread.h>
#include <unistd.h>
#include "Structures.h"
#include "List.h"
#include "BlockingQueue.h"

pthread_mutex_t criticalReceiver;
byte isRunning;
List receivers;
BlockingQueue requests, newClients;
pthread_t newClientProcessThread;

static int server;
static pthread_mutex_t criticalSender;
static List senders;
static socklen_t addressLength;

extern void InitializeDatabase();
extern void InitializeDispatcher();
extern void InitializeBroadcaster();

static void initialize();
static void acceptClient();
static void cleanup();
static void* processNewClient(void*);

int main() {
	// const rlim_t kStackSize = 50 * 1024 * 1024;   // min stack size = 50 MB
    // struct rlimit rl;
    // getrlimit(RLIMIT_STACK, &rl);
	initialize();
	acceptClient();
	return 0;
}

static void initialize() {
	const char* IP = "192.168.0.108";
	const int PORT = 5557;

	struct sockaddr_in address;;
	addressLength = sizeof address;

	address.sin_family = AF_INET;
	address.sin_port = htons(PORT);
	address.sin_addr.s_addr = inet_addr(IP);

	server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	bind(server, &address, addressLength);
	listen(server, SOMAXCONN);
	isRunning = 1;

	pthread_create(&newClientProcessThread, 0, processNewClient, 0);

	receivers.capacity = senders.capacity = 5;
	receivers.count = senders.count = 0;
	receivers.data = malloc(receivers.capacity * SENDER_SIZE);
	senders.data = malloc(senders.capacity * SENDER_SIZE);

	requests.count = 0;
	requests.capacity = 5;
	requests.data = malloc(requests.capacity * POINTER_SIZE);
	pthread_mutex_init(&requests.lock, 0);
	pthread_cond_init(&requests.condition, 0);

	newClients.count = 0;
	newClients.capacity = 10;
	newClients.data = malloc(newClients.capacity * sizeof(NewClient));
	pthread_mutex_init(&newClients.lock, 0);
	pthread_cond_init(&newClients.condition, 0);

	pthread_mutex_init(&criticalSender, 0);
	pthread_mutex_init(&criticalReceiver, 0);

	InitializeDatabase();
	InitializeDispatcher();
	InitializeBroadcaster();
}
static void* enqueueRequest(void* p) {
	int *clientAddress = p;
	int client = *clientAddress;
	char header[4];
	int packetSize, accumulated, read;
	while (1) {
		accumulated = read = 0;
		do {
			read = recv(client, &header[accumulated], 4 - accumulated, 0);
			if (read <= 0) goto onDisconnected;
			accumulated += read;
		} while (accumulated < 4);

		memcpy(&packetSize, header, 4);
		Request* r = malloc(REQUEST_SIZE);
		r->packet = malloc(packetSize);

		accumulated = read = 0;
		do {
			read = recv(client, r->packet, packetSize - accumulated, 0);
			if (read <= 0) {
				free(r->packet);
				free(r);
				goto onDisconnected;
			}
			accumulated += read;
		} while (accumulated < packetSize);

		r->sender = client;
		r->length = packetSize;
		memcpy(&r->userId, &r->packet[0], 4);
		memcpy(&r->function, &r->packet[4], 4);
		putInto(&requests, r);
	}

onDisconnected:
	close(client);
	pthread_mutex_lock(&criticalSender);
	Sender** list = senders.data;
	Sender* s = 0;
	for (size_t i = 0; i < senders.count; i++) {
		if (list[i]->socket == client) {
			s = list[i];
			break;
		}
	}
	removeFromList(&senders, s);
	pthread_mutex_unlock(&criticalSender);

	free(s);
	return 0;
}

static void* processNewClient(void* p) {
	while (isRunning) {
		NewClient* client = takeOutFrom(&newClients);
		byte isReceiver;
		int read = recv(client->socket, &isReceiver, 1, 0);
		if (isReceiver) {
			pthread_mutex_lock(&criticalReceiver);
			addToList(&receivers, &client->socket);
			pthread_mutex_unlock(&criticalReceiver);
		}
		else {
			pthread_mutex_lock(&criticalSender);
			pthread_t requestThread;
			pthread_create(&requestThread, 0, enqueueRequest, &client->socket);
			Sender* s = malloc(SENDER_SIZE);
			s->socket = client->socket;
			s->thread = requestThread;
			addToList(&senders, s);

			pthread_mutex_unlock(&criticalSender);
		}
		free(client);
	}
	return 0;
}

static void acceptClient() {
	socklen_t flag = 1;
	while (isRunning) {
		NewClient* client = malloc(sizeof(NewClient));
		client->socket = accept(server, &client->from, &addressLength);
		setsockopt(client->socket, IPPROTO_TCP, TCP_NODELAY, &flag, addressLength);
		//char* ipv4 = inet_ntoa(client->from.sin_addr);
		putInto(&newClients, client);
	}
}

static void cleanup() {
	isRunning = 0;
	close(server);
}
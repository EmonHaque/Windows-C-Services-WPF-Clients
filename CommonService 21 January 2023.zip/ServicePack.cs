﻿public class ServicePack
{
    int read, accumulated, size;
    byte[] header = new byte[4];

    public Socket Signatory { get; set; } // for connecting to login service
    public Socket Receiver { get; set; } // for receiving broadcast
    public Socket Sender { get; set; } // for request and response
    public IPAddress Address { get; set; }
    public int Port { get; set; }
    public Role Role { get; set; }
    public int UserId { get; set; }

    public Task<Response> GetResponse(Request request) {
        var source = new TaskCompletionSource<Response>();
        ThreadPool.QueueUserWorkItem(_ => {
            try {
                Monitor.Enter(Sender);
                accumulated = 0;
                Sender.Send(request.GetBytes());
                do {
                    read = Sender.Receive(header, accumulated, header.Length - accumulated, SocketFlags.None);
                    if(read == 0) {
                        source.SetResult(new Response(false, new byte[0]));
                        return;
                    }
                    accumulated += read;
                } while (accumulated < 4);

                size = BitConverter.ToInt32(header);
                if (size == 0) {
                    source.SetResult(new Response(true, new byte[0]));
                    return;
                }
                var packet = new byte[size];
                accumulated = 0;
                do {
                    read = Sender.Receive(packet, accumulated, size - accumulated, SocketFlags.None);
                    if (read == 0) {
                        source.SetResult(new Response(false, new byte[0]));
                        return;
                    }
                    accumulated += read;
                } while (accumulated < size);
                source.SetResult(new Response(true, packet));
            }
            catch { source.SetResult(new Response(false, new byte[0])); }
            finally { Monitor.Exit(Sender); }
        });
        return source.Task;
    }
}

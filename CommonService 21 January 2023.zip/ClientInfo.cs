﻿public class ClientInfo
{
    public byte IssReceiver { get; set; }
    public int UserId { get; set; }

    public List<ArraySegment<byte>> getBytes() {
        var segments = new List<ArraySegment<byte>>();
        
        return new List<ArraySegment<byte>>() {
            new byte[1]{ IssReceiver },
            BitConverter.GetBytes(UserId)
        };
    }
}

﻿class EntryNoteView : CardView
{
    public override string Header => "Note";
    public override string Icon => Icons.NoteBookPlus;

    SuggestBox noteType, site;
    TextBlock siteAddressBlock;
    Run siteAddress;
    EditText entry;
    CommandButton add;
    EntryNoteVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new EntryNoteVM();
        DataContext = vm;
        initializeUI();
        bind();
        vm.CoordinateRequested += onCoordinateRequest;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        vm.CoordinateRequested -= onCoordinateRequest;
        Unloaded -= onUnloaded;
    }
    void onCoordinateRequest() => updatePosition();
    void initializeUI() {
        noteType = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.NoteType,
            Hint = "Note type",
            Source = AppData.noteTypes
        };
        site = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.Plot,
            Hint = "Site",
            Source = AppData.sites,
            LostFocusAction = vm.SetSiteAddress
        };
        siteAddress = new Run();
        siteAddressBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 10),
            Inlines = { "Address: ", siteAddress },
            Foreground = Brushes.DarkGray,
            TextWrapping = TextWrapping.Wrap
        };
        entry = new EditText() {
            Margin = new Thickness(5, 15, 5, 0),
            IsMultiline = true,
            Icon = Icons.Description,
            Hint = "Entry"
        };
        add = new CommandButton() {
            Icon = Icons.Plus,
            Margin = new Thickness(0, 5, 5, 0),
            Width = 16,
            Height = 16,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = vm.AddEntry
        };
        Grid.SetRow(site, 1);
        Grid.SetRow(siteAddressBlock, 2);
        Grid.SetRow(entry, 3);
        Grid.SetRow(add, 4);
        var grid = new Grid() {
            Margin = new Thickness(0,5,0,0),
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(),
                new RowDefinition(){ Height = GridLength.Auto }
            },
            Children = { noteType, site, siteAddressBlock, entry, add }
        };
        setContent(grid);
    }
    void bind() {
        noteType.SetBinding(SuggestBox.TextProperty, new Binding($"{nameof(vm.Entry)}.{nameof(EntryNote.NoteType)}"));
        site.SetBinding(SuggestBox.TextProperty, new Binding($"{nameof(vm.Entry)}.{nameof(EntryNote.Site)}"));
        siteAddress.SetBinding(Run.TextProperty, new Binding(nameof(vm.SiteAddress)));
        entry.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.Entry)}.{nameof(EntryNote.Entry)}"));
    }

    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var position = PointToScreen(new Point(0, 0));
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin;
        position.Y += Constants.CardMargin;
        var width = ActualWidth - Constants.CardMargin - Constants.CardMargin;
        var height = ActualHeight - Constants.CardMargin - Constants.CardMargin;
        vm.Top = position.Y;
        vm.Left = position.X;
        vm.Width = width;
        vm.Height = height;
    }
}

﻿class EntryView : View
{
    override public string Icon => Icons.Add;
    public override FrameworkElement container => grid;
    Grid grid;
    public EntryView() {
        var entries = new ViewContainer(NavPosition.TopRightVertical) {
            IconSize = 12,
            IconGap = 5,
            IsMarginLess = true,
            Children = {
                new InputEntry(),
                new EntryNoteView()
            }
        };
        var list = new ListEntries();
        Grid.SetColumn(list, 1);
        grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            Children = { entries, list }
        };
        AddVisualChild(grid);
    }
}

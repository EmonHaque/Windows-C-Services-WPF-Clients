﻿class SummaryPurchaseSell : CardView
{
    public override string Header => "Purchase / Sell";
    public override string Icon => Icons.HandShake;

    public static double TopOfLeftGrid { get; set; }
    public static double LeftOfLeftGrid { get; set; }
    public static double WidthOfLeftGrid { get; set; }
    public static double HeightOfLeftGrid { get; set; }

    public static double TopOfRightBorder { get; set; }
    public static double LeftOfRightBorder { get; set; }
    public static double WidthOfRightBorder { get; set; }
    public static double HeightOfRightBorder { get; set; }

    DependencyPropertyDescriptor multiStateDescriptor, expandStateDescriptor, listBoxDescriptor;
    Grid leftGrid;
    Border rightBorder;
    MultiState isConstruction, groupByPrimary, groupBySecondary;
    EditText query;
    ActionButton refresh;
    ExpanderState leftGridExpandState, rightBorderExpandState;
    DayPicker from, to;
    ListBox summaryEntries, detailEntries;
    Run totalSummaryEntries, totalDetailEntries, totalSummaryGroups, groupName, totalDetailGroups;
    TextBlock totalPurchase, totalSell, totalDetailPurchase, totalDetailSell;
    SummaryPurchaseSellVM vm;
    
    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new SummaryPurchaseSellVM();
        DataContext = vm;
        initializeUI();
        bind();

        multiStateDescriptor = DependencyPropertyDescriptor.FromProperty(MultiState.StateProperty, typeof(MultiState));
        expandStateDescriptor = DependencyPropertyDescriptor.FromProperty(ExpanderState.IsTrueProperty, typeof(ExpanderState));
        listBoxDescriptor = DependencyPropertyDescriptor.FromProperty(ListBox.SelectedItemProperty, typeof(ListBox));

        multiStateDescriptor.AddValueChanged(groupByPrimary, onPrimaryGroupChanged);
        expandStateDescriptor.AddValueChanged(leftGridExpandState, onLeftGridIsExpandedChanged);
        expandStateDescriptor.AddValueChanged(rightBorderExpandState, onMiddleBorderIsExpandedChanged);
        listBoxDescriptor.AddValueChanged(summaryEntries, onMiddleBorderIsExpandedChanged);
        vm.CoordinateRequested += onCoordinateRequest;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        vm.CoordinateRequested -= onCoordinateRequest;
        Unloaded -= onUnloaded;
        multiStateDescriptor.RemoveValueChanged(groupByPrimary, onPrimaryGroupChanged);
        expandStateDescriptor.RemoveValueChanged(leftGridExpandState, onLeftGridIsExpandedChanged);
        expandStateDescriptor.RemoveValueChanged(rightBorderExpandState, onMiddleBorderIsExpandedChanged);
        listBoxDescriptor.RemoveValueChanged(detailEntries, onMiddleBorderIsExpandedChanged);
    }
    void onCoordinateRequest() => updatePosition();
    void onPrimaryGroupChanged(object? sender, EventArgs e) {
        switch (groupByPrimary.State) {
            case 0:
                groupBySecondary.Icons = new string[] { Icons.Tenant, Icons.Head };
                groupBySecondary.Texts = new string[] { "Party", "Head" };
                break;
            case 1:
                groupBySecondary.Icons = new string[] { Icons.Plot, Icons.Head };
                groupBySecondary.Texts = new string[] { "Site", "Head" };
                break;
            default:
                groupBySecondary.Icons = new string[] { Icons.Tenant, Icons.Plot };
                groupBySecondary.Texts = new string[] { "Party", "Site" };
                break;
        }
    }
    void onLeftGridIsExpandedChanged(object? sender, EventArgs e) {
        var items = Helper.FindVisualChildren<GroupItem>(summaryEntries);
        if (leftGridExpandState.IsTrue) {
            foreach (GroupItem item in items) item.Tag = true;
            leftGridExpandState.ToolTip = "Collapse";
        }
        else {
            foreach (GroupItem item in items) item.Tag = false;
            leftGridExpandState.ToolTip = "Expand";
        }
    }
    void onMiddleBorderIsExpandedChanged(object? sender, EventArgs e) {
        var items = Helper.FindVisualChildren<GroupItem>(detailEntries);
        if (rightBorderExpandState.IsTrue) {
            foreach (GroupItem item in items) item.Tag = true;
            rightBorderExpandState.ToolTip = "Collapse";
        }
        else {
            foreach (GroupItem item in items) item.Tag = false;
            rightBorderExpandState.ToolTip = "Expand";
        }
    }
    void onRefresh() {
        vm.Refresh();
        groupName.Text = groupByPrimary.Texts[groupByPrimary.State].ToLower();
        onLeftGridIsExpandedChanged(null, null);
        onMiddleBorderIsExpandedChanged(null, null);
    }
    void initializeLeftGrid() {
        #region 1st Row
        isConstruction = new MultiState() {
            Icons = new string[] { Icons.Construction, Icons.Development, Icons.Repair, Icons.Maintenance, Icons.All },
            Texts = new string[] { "Construction", "Development", "Repair", "Maintenance", "All" },
            IsIconInfront = true,
            Margin = new Thickness(0, 0, 10, 0),
            VerticalAlignment = VerticalAlignment.Bottom
        };
        groupByPrimary = new MultiState() {
            Icons = new string[] { Icons.Plot, Icons.Tenant, Icons.Head },
            Texts = new string[] { "Site", "Party", "Head" },
            IsIconInfront = true,
            VerticalAlignment = VerticalAlignment.Bottom
        };
        groupBySecondary = new MultiState() {
            Icons = new string[] { Icons.Tenant, Icons.Head },
            Texts = new string[] { "Party", "Head" },
            IsIconInfront = true,
            //Margin = new Thickness(0, 0, 5, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        var leftStates = new StackPanel() {
            Margin = new Thickness(5,0,0,0),
            Orientation = Orientation.Horizontal,
            Children = { isConstruction, groupByPrimary }
        };
        #endregion

        #region 2nd Row
        from = new DayPicker() {
            IsRequired = true,
            Hint = "from",
            DateFormat = "dd/MM/yyyy"
        };
        to = new DayPicker() {
            IsRequired = true,
            Hint = "to",
            DateFormat = "dd/MM/yyyy"
        };
        refresh = new ActionButton() {
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 0, 0, 0),
            Icon = Icons.Refresh,
            ToolTip = "Refresh",
            Command = onRefresh
        };
        Grid.SetColumn(to, 1);
        Grid.SetColumn(refresh, 2);

        var secondRow = new Grid() {
            Margin = new Thickness(0, 10, 0, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { from, to, refresh }
        };
        #endregion

        #region 3rd Row
        query = new EditText() {
            Margin = new Thickness(5, 10, 5, 5),
            Icon = Icons.Search,
            Hint = "Search"
        };
        leftGridExpandState = new ExpanderState() {
            Margin = new Thickness(5, 10, 0, 0),
            VerticalAlignment = VerticalAlignment.Center,
            ToolTip = "Expand"
        };

        Grid.SetColumn(leftGridExpandState, 1);

        var thirdRow = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            Children = {query, leftGridExpandState }
        };
        #endregion

        #region header
        var summaryParticulars = new SortToggle() {
            Text = "Particulars",
            Icon = Icons.SortSwap,
            Command = vm.SortReportablesParticulars
        };
        var summaryPurchase = new SortToggle() {
            Text = "Purchase",
            Icon = Icons.SortSwap,
            IsRightAligned = true,
            Command = vm.SortReportablesPurchase
        };
        var summarySell = new SortToggle() {
            Text = "Sell",
            Icon = Icons.SortSwap,
            IsRightAligned = true,
            Command = vm.SortReportablesSell
        };
        Grid.SetColumn(summaryPurchase, 1);
        Grid.SetColumn(summarySell, 2);
        var headerGrid = new Grid() {
            Margin = new Thickness(0, 0, Constants.LeadgerRightMargin, 1),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) },
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) }
            },
            Children = { summaryParticulars, summaryPurchase, summarySell }
        };
        var header = new Border() {
            Margin = new Thickness(5,0,0,5),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        #endregion

        summaryEntries = new ListBox() {
            ItemTemplate = new SummaryEntryTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new SummaryGroupTemplate(groupByPrimary))
                        }
                    }
                }
            },
            Resources = {
                {
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false))
                        }
                    }
                }
            }
        };

        #region footer
        totalSummaryEntries = new Run();
        totalSummaryGroups = new Run();
        groupName = new Run() { Text = "site" };
        var entryBlock = new TextBlock() { Inlines = { "Total of ", totalSummaryEntries, " entries in ", totalSummaryGroups, " ", groupName } };
        totalPurchase = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalSell = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalPurchase, 1);
        Grid.SetColumn(totalSell, 2);
        var footerGrid = new Grid() {
            Margin = new Thickness(0, 0, Constants.LeadgerRightMargin, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) },
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) }
            },
            Children = { entryBlock, totalPurchase, totalSell }
        };
        var footer = new Border() {
            Margin = new Thickness(5,5,0,0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        #endregion

        Grid.SetRow(secondRow, 1);
        Grid.SetRow(thirdRow, 2);
        Grid.SetRow(header, 3);
        Grid.SetRow(summaryEntries, 4);
        Grid.SetRow(footer, 5);

        leftGrid = new Grid() {
            Margin = new Thickness(0,5,5,0),
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { leftStates, groupBySecondary, secondRow, thirdRow, header, summaryEntries, footer }
        };
    }
    void initializeMiddleBorder() {
        rightBorderExpandState = new ExpanderState() {
            Margin = new Thickness(10, 2, 0, 5),
            HorizontalAlignment = HorizontalAlignment.Left,
            ToolTip = "Expand"
        };

        #region header
        var subSummaryParticulars = new SortToggle() {
            Text = "Particulars",
            Icon = Icons.SortSwap,
            Command = vm.SortDetailParticulars
        };
        var subSummaryPurchase = new SortToggle() {
            Text = "Purchase",
            Icon = Icons.SortSwap,
            IsRightAligned = true,
            Command = vm.SortDetailPurchase
        };
        var subSummarySell = new SortToggle() {
            Text = "Sell",
            Icon = Icons.SortSwap,
            IsRightAligned = true,
            Command = vm.SortDetailSell
        };
        Grid.SetColumn(subSummaryPurchase, 1);
        Grid.SetColumn(subSummarySell, 2);
        
        var headerGrid = new Grid() {
            Margin = new Thickness(0, 0, Constants.LeadgerRightMargin, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) },
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) }
            },
            Children = { subSummaryParticulars, subSummaryPurchase, subSummarySell }
        };
        var header = new Border() {
            Margin = new Thickness(5, 0, 0, 5),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        #endregion

        detailEntries = new ListBox() {
            ItemTemplate = new DetailEntryTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new SubSummaryGroupTemplate(summaryEntries))
                        }
                    }
                }
            },
            Resources = {
                {
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false))
                        }
                    }
                }
            }
        };

        #region footer
        totalDetailEntries = new Run();
        totalDetailGroups = new Run();
        var entryBlock = new TextBlock() { Inlines = { "Total of ", totalDetailEntries , " entries in ", totalDetailGroups, " group"} };
        totalDetailPurchase = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalDetailSell = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalDetailPurchase, 1);
        Grid.SetColumn(totalDetailSell, 2);
        var footerGrid = new Grid() {
            Margin = new Thickness(0, 0, Constants.LeadgerRightMargin, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) },
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) }
            },
            Children = { entryBlock, totalDetailPurchase, totalDetailSell }
        };
        var footer = new Border() {
            Margin = new Thickness(5, 5, 0, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        #endregion

        Grid.SetRow(header, 1);
        Grid.SetRow(detailEntries, 2);
        Grid.SetRow(footer, 3);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { rightBorderExpandState, header, detailEntries, footer }
        };
        rightBorder = new Border() {
            Child = grid,
            BorderThickness = new Thickness(Constants.BottomLineThickness, 0, 0, 0),
            BorderBrush = Brushes.LightGray
        };
    }
    void initializeUI() {
        initializeLeftGrid();
        initializeMiddleBorder();
        Grid.SetColumn(rightBorder, 1);
        var grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            Children = { leftGrid, rightBorder }
        };
        setContent(grid);
    }
    void bind() {
        isConstruction.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.IsContruction)) { Mode = BindingMode.OneWayToSource });
        groupByPrimary.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.PrimaryGroup)) { Mode = BindingMode.OneWayToSource });
        groupBySecondary.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.SecondaryGroup)) { Mode = BindingMode.OneWayToSource });
        from.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.From)}"));
        from.SetBinding(DayPicker.StartDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.Start)}"));
        from.SetBinding(DayPicker.EndDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.End)}"));
        to.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.To)}"));
        to.SetBinding(DayPicker.StartDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.Start)}"));
        to.SetBinding(DayPicker.EndDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.End)}"));
        query.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) { Mode = BindingMode.OneWayToSource });
        
        summaryEntries.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Reportables)));
        summaryEntries.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)) { Mode = BindingMode.OneWayToSource });

        totalSummaryEntries.SetBinding(Run.TextProperty, new Binding("Items.Count") { Source = summaryEntries, Mode = BindingMode.OneWay });
        totalSummaryGroups.SetBinding(Run.TextProperty, new Binding(nameof(vm.NoOfSummaryGroup)) { Mode = BindingMode.OneWay });
        totalPurchase.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalPurchase)) { StringFormat = Constants.NumberFormat});
        totalSell.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalSell)) { StringFormat = Constants.NumberFormat });

        detailEntries.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Detail)));
        totalDetailEntries.SetBinding(Run.TextProperty, new Binding("Items.Count") { Source = detailEntries, Mode = BindingMode.OneWay });
        totalDetailGroups.SetBinding(Run.TextProperty, new Binding(nameof(vm.NoOfDetailGroup)) { Mode = BindingMode.OneWay });

        totalDetailPurchase.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalDetailPurchase)) { StringFormat = Constants.NumberFormat });
        totalDetailSell.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalDetailSell)) { StringFormat = Constants.NumberFormat });
    }
    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var topLeftOfLeftGrid = leftGrid.TransformToAncestor(this).Transform(new Point(0, 0));
        var topLeftOfMiddleBorder = rightBorder.TransformToAncestor(this).Transform(new Point(0, 0));
        var positionOfLeftGrid = PointToScreen(topLeftOfLeftGrid);
        var positionOfMiddleBorder = PointToScreen(topLeftOfMiddleBorder);

        positionOfLeftGrid.X /= dpi.DpiScaleX;
        positionOfLeftGrid.Y /= dpi.DpiScaleY;

        positionOfMiddleBorder.X /= dpi.DpiScaleX;
        positionOfMiddleBorder.Y /= dpi.DpiScaleY;

        TopOfLeftGrid = positionOfLeftGrid.Y - 10;
        LeftOfLeftGrid = positionOfLeftGrid.X - 5;
        WidthOfLeftGrid = leftGrid.ActualWidth + 10;
        HeightOfLeftGrid = leftGrid.ActualHeight + 15;

        TopOfRightBorder = positionOfMiddleBorder.Y - 5;
        LeftOfRightBorder = positionOfMiddleBorder.X;
        WidthOfRightBorder = rightBorder.ActualWidth + 5;
        HeightOfRightBorder = rightBorder.ActualHeight + 10;
    }
}

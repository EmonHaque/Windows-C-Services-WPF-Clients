﻿class DetailPurchasePayable : CardView
{
    DetailPurchasePayableVM vm;
    MultiState state;
    ActionButton refresh, sortName, sortAmount;
    HorizontalBarChart chart;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new DetailPurchasePayableVM();
        DataContext = vm;
        initializeUI();
        bind();
    }
    void initializeUI() {
        state = new MultiState() {
            IsIconInfront = true,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        sortName = new ActionButton() {
            Icon = Icons.SortSwap,
            ToolTip = "Name",
            Command = vm.SortName
        };
        sortAmount = new ActionButton() {
            Margin = new Thickness(5, 0, 5, 0),
            Icon = Icons.SortSwap,
            ToolTip = "Amount",
            Command = vm.SortAmount
        };
        refresh = new ActionButton() {
            Icon = Icons.Refresh,
            ToolTip = "Refresh",
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = vm.Refresh
        };
        Grid.SetColumn(sortName, 1);
        Grid.SetColumn(sortAmount, 2);
        Grid.SetColumn(refresh, 3);
        var topRow = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto },
                new ColumnDefinition() { Width = GridLength.Auto },
                new ColumnDefinition() { Width = GridLength.Auto }
            },
            Children = { state, sortName, sortAmount, refresh }
        };

        chart = new HorizontalBarChart();
        Grid.SetRow(chart, 1);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { topRow, chart }
        };
        
        setContent(grid);
    }
    void bind() {
        chart.SetBinding(HorizontalBarChart.ItemsSourceProperty, new Binding(nameof(vm.Data)));
        state.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.State)));
        state.SetBinding(MultiState.TextsProperty, new Binding(nameof(vm.StateTexts)));
        state.SetBinding(MultiState.IconsProperty, new Binding(nameof(vm.StateIcons)));
    }
}

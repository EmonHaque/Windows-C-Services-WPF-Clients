﻿class ReceiptPaymentTemplate : DataTemplate
{
    public ReceiptPaymentTemplate(Binding command) {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var head = new FrameworkElementFactory(typeof(TextBlock));
        var amount = new FrameworkElementFactory(typeof(TextBlock));
        var path = new FrameworkElementFactory(typeof(PathIcon));
        var button = new FrameworkElementFactory(typeof(DependencyButton<EntryReceiptPayment>));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        col4.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        amount.SetValue(Grid.ColumnProperty, 1);
        path.SetValue(Grid.ColumnProperty, 2);
        button.SetValue(Grid.ColumnProperty, 3);

        amount.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        path.SetValue(PathIcon.MarginProperty, new Thickness(5, 0, 5, 0));
        button.SetValue(DependencyButton<EntryReceiptPayment>.WidthProperty, 12d);
        button.SetValue(DependencyButton<EntryReceiptPayment>.HeightProperty, 12d);
        button.SetValue(DependencyButton<EntryReceiptPayment>.MarginProperty, new Thickness(0, 2, 0, 2));
        button.SetValue(DependencyButton<EntryReceiptPayment>.IconProperty, Icons.Minus);
        button.SetBinding(DependencyButton<EntryReceiptPayment>.CommandProperty, command);
        button.SetBinding(DependencyButton<EntryReceiptPayment>.ParameterProperty, new Binding("."));

        head.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryReceiptPayment.Head)));
        amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryReceiptPayment.Amount)) { StringFormat = Constants.NumberFormat });
        path.SetBinding(PathIcon.IconProperty, new Binding(nameof(EntryReceiptPayment.IsCash)) { Converter = Converters.isCash2Icon });
        path.SetBinding(PathIcon.FillProperty, new Binding(nameof(EntryInsert.IsCash)) { Converter = Converters.isCash2Fill });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(head);
        grid.AppendChild(amount);
        grid.AppendChild(path);
        grid.AppendChild(button);
        VisualTree = grid;
    }
}

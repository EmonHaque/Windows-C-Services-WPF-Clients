﻿class LedgerTemplate : DataTemplate
{
    public LedgerTemplate(double fixedColumnsWidth = 80, double margin = 5) {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var date = new FrameworkElementFactory(typeof(TextBlock));
        var particulars = new FrameworkElementFactory(typeof(HiBlock));
        var receipt = new FrameworkElementFactory(typeof(TextBlock));
        var payment = new FrameworkElementFactory(typeof(TextBlock));
        var balance = new FrameworkElementFactory(typeof(TextBlock));

        grid.SetValue(Grid.MarginProperty, new Thickness(0, 0, margin, 0));
        col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));
        col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));

        receipt.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        payment.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        balance.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        receipt.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        payment.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        balance.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);

        particulars.SetValue(Grid.ColumnProperty, 1);
        receipt.SetValue(Grid.ColumnProperty, 2);
        payment.SetValue(Grid.ColumnProperty, 3);
        balance.SetValue(Grid.ColumnProperty, 4);

        particulars.SetValue(HiBlock.TextWrappingProperty, TextWrapping.Wrap);

        if (margin == 0) {
            date.SetValue(TextBlock.ForegroundProperty, Brushes.Black);
            particulars.SetValue(HiBlock.ForegroundProperty, Brushes.Black);
            receipt.SetValue(TextBlock.ForegroundProperty, Brushes.Black);
            payment.SetValue(TextBlock.ForegroundProperty, Brushes.Black);
            balance.SetValue(TextBlock.ForegroundProperty, Brushes.Black);
        }

        date.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Date)) { StringFormat = "dd MMM yyy" });
        particulars.SetBinding(HiBlock.TextProperty, new Binding(nameof(ReportEntry.Particulars)));
        particulars.SetBinding(HiBlock.QueryProperty, new Binding("DataContext." + nameof(ReportPartyVM.ReportQuery)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ListBox), 1)
        });
        receipt.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.ReceivablePayment)) { StringFormat = Constants.NumberFormat });
        payment.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.PayableReceipt)) { StringFormat = Constants.NumberFormat });
        balance.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.NetPayable)) { StringFormat = Constants.NumberFormat });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);
        grid.AppendChild(date);
        grid.AppendChild(particulars);
        grid.AppendChild(receipt);
        grid.AppendChild(payment);
        grid.AppendChild(balance);
        VisualTree = grid;
    }
}

﻿class SummaryExpanderHeaderTemplate : DataTemplate
{
    public SummaryExpanderHeaderTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid" };
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var header = new FrameworkElementFactory(typeof(Run));
        var openParen = new FrameworkElementFactory(typeof(Run));
        var count = new FrameworkElementFactory(typeof(Run));
        var closeParen = new FrameworkElementFactory(typeof(Run));
        var headerBlock = new FrameworkElementFactory(typeof(TextBlock)) { Name = "header"};
        var totals = new FrameworkElementFactory(typeof(ContentControl)) { Name = "totals"};

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(2 * Constants.AmountColumnWidth));
        totals.SetValue(Grid.ColumnProperty, 1);
        totals.SetValue(ContentControl.ContentTemplateProperty, new SummaryTotalTemplate());

        headerBlock.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        header.SetValue(Run.FontWeightProperty, FontWeights.Bold);
        openParen.SetValue(Run.TextProperty, " (");
        closeParen.SetValue(Run.TextProperty, ")");

        var source = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1);
        
        header.SetBinding(Run.TextProperty, new Binding("DataContext." + nameof(GroupItem.Name)) {
            Mode = BindingMode.OneWay,
            RelativeSource = source
        });;
        count.SetBinding(Run.TextProperty, new Binding("DataContext." + nameof(CollectionViewGroup.ItemCount)) {
            Mode = BindingMode.OneWay,
            RelativeSource = source
        });
        totals.SetBinding(ContentControl.ContentProperty, new Binding("DataContext." + nameof(CollectionViewGroup.Items)) {
            RelativeSource = source,
            Converter = Converters.groupSummary,
            Mode = BindingMode.OneWay
        });

        headerBlock.AppendChild(header);
        headerBlock.AppendChild(openParen);
        headerBlock.AppendChild(count);
        headerBlock.AppendChild(closeParen);

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(headerBlock);
        grid.AppendChild(totals);

        VisualTree = grid;

        Triggers.Add(new Trigger() {
            Property = UIElement.IsMouseOverProperty,
            Value = true,
            Setters = {
                new Setter(Grid.BackgroundProperty, Constants.BackgroundDark, "grid")
            }
        });
    }
}

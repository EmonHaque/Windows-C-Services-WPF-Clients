﻿class App : ClientApp
{
    public AppData appData = new();
    protected override string appTitle => "CDRM";
    protected override IPAddress address => IPAddress.Parse(Addresses.CDRMAddress);
    protected override int port => Addresses.CDRMPort;
    protected override Request initRequest => new Request() {
        UserId = service.UserId,
        Method = (int)Function.GetInitialData,
        Bytes = new List<ArraySegment<byte>>()
    };
    protected override ImageSource appIcon {
        get {
            var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("CDRM.Resources.AppIcon.png");
            var source = BitmapFrame.Create(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
            stream.Close();
            stream.Dispose();
            return source;
        }
    }
    protected override AppDataBase baseData => appData;

    const string appExeName = "CDRM";
    const string appVersion = "1.0";

    [STAThread]
    static void Main(string[] args) {
#if DEBUG 
        new App().Run();
#else
        if (args.Length == 0) {
            launch(new LaunchArgs() {
                App = appExeName,
                Version = appVersion,
                Path = AppDomain.CurrentDomain.BaseDirectory
            });
        }
        else new App().Run();
#endif        
    }
    
    protected override Window SetResourceAndWindow() {
        new Converters();
        return new RootWindow() {
            Content = new RootPanel() {
                Children = {
                    new HomeView(),
                    new EntryView(),
                    new EditView(),
                    new ReportView(),
                    new NotificationView()
                }
            }
        };
    }
}


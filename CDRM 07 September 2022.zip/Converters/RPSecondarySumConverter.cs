﻿class RPSecondarySumConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {        
        var items = (ReadOnlyObservableCollection<object>)value;
        int count = 0;
        foreach (SumReceiptPayment item in items) {
            count += item.Count;
        }
        return count;
    }
    public object ConvertBack(object value, Type targetTypes, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}

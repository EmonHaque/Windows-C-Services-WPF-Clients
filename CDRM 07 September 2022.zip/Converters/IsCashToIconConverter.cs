﻿class IsCashToIconConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var id = (byte)value;
        switch (id) {
            case 0: return Icons.Cash;
            case 1: return Icons.Phone;
            default: return Icons.Noncash;
        }
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}

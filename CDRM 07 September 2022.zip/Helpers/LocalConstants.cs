﻿class LocalConstants
{
    public const string ServiceDown = "Service down, try restrating Application";
}

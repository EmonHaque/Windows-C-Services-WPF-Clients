﻿class NotesVM : Notifiable
{
    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    ObservableCollection<EntryNote> reportables;
    string query;
    public string Query {
        get { return query; }
        set { query = value; Reportables.Refresh(); }
    }
    EntryNote selected;
    public EntryNote Selected {
        get { return selected; }
        set {
            selected = value;
            if (IsOnEdit) {
                IsOnEdit = false;
                OnPropertyChanged(nameof(IsOnEdit));
            }
        }
    }
    public EntryNote Edited { get; set; }
    public bool IsOnEdit { get; set; }
    public ICollectionView Reportables { get; set; }
    public event Action CoordinateRequested;

    public NotesVM() {
        reportables = new ObservableCollection<EntryNote>();
        Reportables = new CollectionViewSource() {
            Source = reportables,
            IsLiveGroupingRequested = true,
            LiveGroupingProperties = { nameof(EntryNote.Site), nameof(EntryNote.NoteType) },
            GroupDescriptions = {
                new PropertyGroupDescription(nameof(EntryNote.Site)),
                new PropertyGroupDescription(nameof(EntryNote.NoteType))
            }
        }.View;
        Reportables.Filter = filter;
        getNotes();

        ((App)Application.Current).appData.NoteAdded += onNoteAdded;
        ((App)Application.Current).appData.NoteEdited += onNoteEdited;
        ((App)Application.Current).appData.NoteDeleted += onNoteDeleted;
    }

    void onNoteAdded(Note n) {
        reportables.Add(new EntryNote() {
            Id = n.Id,
            Date = n.Date,
            Entry = n.Entry,
            NoteType = AppData.noteTypes.First(x => x.Id == n.NoteTypeId).Name,
            Site = AppData.sites.First(x => x.Id == n.SiteId).Name
        });
    }
    void onNoteEdited(Note n) {
        var note = reportables.FirstOrDefault(x => x.Id == n.Id);
        if (note is not null) { // will it ever be null?
            note.Date = n.Date;
            note.Entry = n.Entry;
            note.NoteType = AppData.noteTypes.First(x => x.Id == n.NoteTypeId).Name;
            note.Site = AppData.sites.First(x => x.Id == n.SiteId).Name;
            note.OnPropertyChanged(null);
        }
    }
    void onNoteDeleted(int id) {
        var note = reportables.FirstOrDefault(x => x.Id == id);
        if (note is not null) { // will it ever be null?
            reportables.Remove(note);
        }
    }

    public void Refresh() => getNotes();
    public async void Delete() {
        if (Selected is null) return;
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.DeleteNote,
            Bytes = new List<ArraySegment<byte>>() { BitConverter.GetBytes(Selected.Id) }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Note", LocalConstants.ServiceDown);
        }
    }
    public void Edit() {
        if (Selected is null) return;
        Edited = new EntryNote() {
            Id = Selected.Id,
            Date = Selected.Date,
            NoteType = Selected.NoteType,
            Site = Selected.Site,
            Entry = Selected.Entry
        };
        IsOnEdit = true;
        OnPropertyChanged(nameof(IsOnEdit));
        OnPropertyChanged(nameof(Edited));
    }
    public void Cancel() {
        IsOnEdit = false;
        OnPropertyChanged(nameof(IsOnEdit));
    }
    public async void Save() {
        if (Selected is null) return;
        var validator = new NoteValidator(Edited);
        if (!validator.IsValid()) {
            CoordinateRequested?.Invoke();
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
            errorDialog.ShowDialog();
            return;
        }
        if (validator.IsEqual(Selected)) return;

        if (!validator.DoesExist()) {
            CoordinateRequested?.Invoke();
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            var isSuccess = await validator.Resolve(Left, Top, Width, Height);
            if (!isSuccess) {
                InfoDialog.Activate("Note", LocalConstants.ServiceDown);
                return;
            }
        }
        var note = new Note() {
            Id = Edited.Id,
            Date = Edited.Date.Value,
            Entry = Edited.Entry,
            NoteTypeId = Edited.NoteTypeId,
            SiteId = Edited.SiteId
        };
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.EditNote,
            Bytes = note.ToBytes()
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Note", LocalConstants.ServiceDown);
        }
        IsOnEdit = false;
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((EntryNote)o).Entry.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
    Task addNotes(byte[] packet) {
        reportables.Clear();
        var bytes = new ReadOnlySpan<byte>(packet);
        int read, start, index;
        start = read = index = 0;
        var segments = new string[4];
        while (read < bytes.Length) {
            int id = BitConverter.ToInt32(bytes.Slice(start, 4));
            read += 4;
            start = read;
            while (read < bytes.Length) {
                if (bytes[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            reportables.Add(new EntryNote() {
                Id = id,
                Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                NoteType = segments[1],
                Site = segments[2],
                Entry = segments[3]
            });
            index = 0;
        }
        return Task.CompletedTask;
    }
    async void getNotes() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetNotes,
            Bytes = new List<ArraySegment<byte>>()
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Note", LocalConstants.ServiceDown);
        }
        else await addNotes(response.Packet);
    }
}

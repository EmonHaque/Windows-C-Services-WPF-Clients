﻿class EditSiteVM : EditBaseVM<Site>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.sites,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override Site clone() {
        return new Site() {
            Id = Selected.Id,
            Name = Selected.Name,
            Address = Selected.Address
        };
    }
    protected override async void update() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.EditSite,
            Bytes = Edited.ToBytes()
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Site", LocalConstants.ServiceDown);
        }
    }
}

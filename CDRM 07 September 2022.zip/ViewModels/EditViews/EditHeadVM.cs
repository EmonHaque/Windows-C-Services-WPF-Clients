﻿class EditHeadVM : EditBaseVM<Head>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.heads,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override Head clone() {
        return new Head() {
            Id = Selected.Id,
            Name = Selected.Name
        };
    }
    protected override async void update() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.EditHead,
            Bytes = Edited.ToBytes()
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Head", LocalConstants.ServiceDown);
        }
    }
}

﻿class EditEntryVM : Notifiable
{
    DateTime? date;
    public DateTime? Date {
        get { return date; }
        set {
            date = value;
            GetEntries();
            IsRefreshValid = value is not null;
            OnPropertyChanged(nameof(IsRefreshValid));
        }
    }
    string query;
    public string Query {
        get { return query; }
        set { query = value?.Trim(); Entries.Refresh(); }
    }
    bool isOnEdit;
    public bool IsOnEdit {
        get { return isOnEdit; }
        set { isOnEdit = value; if (value) clone(); }
    }

    public IHaveTitle Selected { get; set; }
    public IHaveTitle Edited { get; set; }
    ObservableCollection<IHaveTitle> entries;
    CollectionViewSource entrieSource;
    public ICollectionView Entries { get; set; }
    public bool IsRefreshValid { get; set; }
    public static event Action CoordinateRequested;

    public EditEntryVM() {
        entries = new ObservableCollection<IHaveTitle>();
        entrieSource = new CollectionViewSource() {
            Source = entries,
            GroupDescriptions = {
                new PropertyGroupDescription(nameof(IHaveTitle.Title))
            },
            IsLiveFilteringRequested = true,
            IsLiveGroupingRequested = true,
            LiveFilteringProperties = { nameof(IHaveTitle.Date) },
            LiveGroupingProperties = { nameof(IHaveTitle.Title) }
        };
        Entries = entrieSource.View;
        Entries.Filter = filter;
        ((App)Application.Current).appData.EntryDeleted += onEntryDeleted;
    }

    void onEntryDeleted(int id) {
        for (int i = 0; i < entries.Count; i++) {
            if (entries[i].Id != id) continue;
            entries.Remove(entries[i]);
            break;
        }
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return ((IHaveTitle)o).Date == Date;
        var e = (IHaveTitle)o;
        return e.Date == Date &&
            e.Party.Contains(Query, StringComparison.CurrentCultureIgnoreCase);
    }
    void clone() {
        if (Selected is EntryPurchaseSell) {
            var e = (EntryPurchaseSell)Selected;
            Edited = new EntryPurchaseSell() {
                Title = e.Title,
                Id = e.Id,
                Date = e.Date,
                IsSell = e.IsSell,
                IsConstruction = e.IsConstruction,
                Party = e.Party,
                Site = e.Site,
                Amount = e.Amount,
                Head = e.Head,
                SubHead = e.SubHead,
                Quantity = e.Quantity,
                Unit = e.Unit,
                Narration = e.Narration
            };
        }
        else {
            var e = (EntryReceiptPayment)Selected;
            Edited = new EntryReceiptPayment() {
                Title = e.Title,
                Id = e.Id,
                Date = e.Date,
                IsCash = e.IsCash,
                IsReceipt = e.IsReceipt,
                Party = e.Party,
                Head = e.Head,
                Amount = e.Amount,
                Narration = e.Narration
            };
        }
        OnPropertyChanged(nameof(Edited));
    }
    void updateSelectedPurchaseSell(EntryPurchaseSell e) {
        var s = (EntryPurchaseSell)Selected;
        s.Id = e.Id;
        s.Date = e.Date;
        s.Amount = e.Amount;
        s.IsSell = e.IsSell;
        s.IsConstruction = e.IsConstruction;
        s.Site = e.Site;
        s.Party = e.Party;
        s.Head = e.Head;
        s.SubHead = e.SubHead;
        s.Unit = e.Unit;
        s.Quantity = e.Quantity;
        s.Narration = e.Narration;
        s.Title = e.Title;
        s.OnPropertyChanged(null);
    }
    void updateSelectedReceiptPayment(EntryReceiptPayment e) {
        var s = (EntryReceiptPayment)Selected;
        s.Id = e.Id;
        s.Head = e.Head;
        s.Party = e.Party;
        s.Amount = e.Amount;
        s.IsReceipt = e.IsReceipt;
        s.IsCash = e.IsCash;
        s.Date = e.Date;
        s.Narration = e.Narration;
        s.Title = e.Title;
        s.OnPropertyChanged(null);
    }
    public async void Update() {
        if (Edited is null) return;
        CoordinateRequested?.Invoke();
        BusyWindow.Activate(EditEntryControl.Left, EditEntryControl.Top, EditEntryControl.Width, EditEntryControl.Height, "Updating");
        var request = new Request() { UserId = App.service.UserId };
        Response response = null;
        
        if (Edited is EntryPurchaseSell) {
            var e = (EntryPurchaseSell)Edited;
            request.Method = (int)Function.EditPurchaseSell;
            request.Bytes = e.ToBytes();
            response = await App.service.GetResponse(request);
            if (response.IsSuccess) {
                updateSelectedPurchaseSell(e);
            }
            else {
                BusyWindow.Terminate();
                InfoDialog.Activate("Edit", LocalConstants.ServiceDown);
            }
        }
        else {
            var e = (EntryReceiptPayment)Edited;
            request.Method = (int)Function.EditReceiptPayment;
            request.Bytes = e.ToBytes();
            response = await App.service.GetResponse(request);
            if (response.IsSuccess) {
                updateSelectedReceiptPayment(e);
            }
            else {
                BusyWindow.Terminate();
                InfoDialog.Activate("Edit", LocalConstants.ServiceDown);
            }
        }
        if (BusyWindow.IsOpened) BusyWindow.Terminate();
    }
    public async void Delete() {
        if (Selected is null) return;
        CoordinateRequested?.Invoke();
        BusyWindow.Activate(EditEntryControl.Left, EditEntryControl.Top, EditEntryControl.Width, EditEntryControl.Height, "Deleting");

        var request = new Request() {
            UserId = App.service.UserId,
            Method = Selected is EntryPurchaseSell ? (int)Function.DeletePurchaseSell : (int)Function.DeleteReceiptPayment,
            Bytes = new List<ArraySegment<byte>>() { BitConverter.GetBytes(Selected.Id) }
        };

        var response = await App.service.GetResponse(request).ConfigureAwait(false);
        if (response.IsSuccess) {
            
        }
        else {
            BusyWindow.Terminate();
            InfoDialog.Activate("Edit", LocalConstants.ServiceDown);
        }
        if (BusyWindow.IsOpened) BusyWindow.Terminate();
    }
    public async void GetEntries() {
        if (Date is null) return;
        CoordinateRequested?.Invoke();

        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetPurchaseSellByDate,
            Bytes = new List<ArraySegment<byte>>() { Encoding.ASCII.GetBytes(Date.Value.ToString("yyyy-MM-dd") + '\0') }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Edit", LocalConstants.ServiceDown);
            return;
        }
        var psPacket = response.Packet;

        request.Method = (int)Function.GetReceiptPaymentByDate;
        var response2 = await App.service.GetResponse(request);

        var rpPacket = response2.Packet;

        entries.Clear();
        await addPurchaseSell(psPacket);
        await addReceiptPayment(rpPacket);
    }

    Task addPurchaseSell(byte[] packet) {
        var span = new ReadOnlySpan<byte>(packet);
        int start, read, index;
        start = read = index = 0;
        var segments = new string[9];
        while (read < span.Length) {
            int id = BitConverter.ToInt32(span.Slice(start, 4));
            byte isSell = span.Slice(start + 4, 1)[0];
            byte isConstruction = span.Slice(start + 5, 1)[0];
            start += 6;
            read += 6;
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                if (index == segments.Length) break;
                start = ++read;
            }
            var e = new EntryPurchaseSell() {
                Id = id,
                IsSell = isSell,
                IsConstruction = isConstruction,
                Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                Site = segments[1],
                Party = segments[2],
                Head = segments[3],
                SubHead = segments[4],
                Unit = segments[5],
                Amount = segments[6],
                Quantity = segments[7],
                Narration = segments[8]
            };
            e.Title = e.IsSell == 0 ? "Purchase" : "Sell";
            entries.Add(e);
            start = ++read;
            index = 0;
        }
        return Task.CompletedTask;
    }
    Task addReceiptPayment(byte[] packet) {
        var span = new ReadOnlySpan<byte>(packet);
        int start, read, index;
        start = read = index = 0;
        var segments = new string[5];

        while (read < span.Length) {
            int id = BitConverter.ToInt32(span.Slice(start, 4));
            byte isCash = span.Slice(start + 4, 1)[0];
            byte isReceipt = span.Slice(start + 5, 1)[0];

            start += 6;
            read += 6;
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                if (index == segments.Length) break;
                start = ++read;
            }
            var e = new EntryReceiptPayment() {
                Id = id,
                IsCash = isCash,
                IsReceipt = isReceipt,
                Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                Amount = segments[1],
                Party = segments[2],
                Head = segments[3],
                Narration = segments[4]
            };
            e.Title = e.IsReceipt == 0 ? "Payment" : "Receipt";
            entries.Add(e);
            start = ++read;
            index = 0;
        }
        return Task.CompletedTask;
    }
}

﻿class EditSubHeadVM : EditBaseVM<SubHead>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.subHeads,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override SubHead clone() {
        return new SubHead() {
            Id = Selected.Id,
            Name = Selected.Name
        };
    }
    protected override async void update() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.EditSubHead,
            Bytes = Edited.ToBytes()
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Subhead", LocalConstants.ServiceDown);
        }
    }
}

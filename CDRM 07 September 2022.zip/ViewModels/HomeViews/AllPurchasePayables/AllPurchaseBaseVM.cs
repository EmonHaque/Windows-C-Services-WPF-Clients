﻿abstract class AllPurchaseBaseVM : Notifiable
{
    string query;
    public string Query {
        get { return query; }
        set { query = value; Data?.Refresh(); }
    }
    object selected;
    public object Selected {
        get { return selected; }
        set { selected = value; onSelectedChanged(); }
    }

    public ReportDates Dates { get; set; }
    public ICollectionView Data { get; set; }
    protected abstract string type { get; }

    public AllPurchaseBaseVM() {
        Dates = new ReportDates() {
            From = DateTime.Today.AddYears(-1),
            To = DateTime.Today
        };
        getEntries();
    }

    public void Refresh() => getEntries();
    protected abstract void onSelectedChanged();
    public virtual void SortPurchase() {
        if (Data is null) return;
        if (Data.SortDescriptions.Count > 0) {
            var direction = Data.SortDescriptions.First().Direction;
            if (direction == ListSortDirection.Descending) {
                using (Data.DeferRefresh()) {
                    Data.SortDescriptions.Clear();
                    Data.SortDescriptions.Add(new SortDescription(nameof(KeyValueSeries.Value), ListSortDirection.Ascending));
                }
            }
            else {
                using (Data.DeferRefresh()) {
                    Data.SortDescriptions.Clear();
                    Data.SortDescriptions.Add(new SortDescription(nameof(KeyValueSeries.Value), ListSortDirection.Descending));
                }
            }
        }
        else {
            Data.SortDescriptions.Add(new SortDescription(nameof(KeyValueSeries.Value), ListSortDirection.Descending));
        }
    }
    protected virtual bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((KeyValueSeries)o).Key.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }

    protected virtual async void getEntries() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = type.Equals("Party") ? (int)Function.GetAllPartyTransactions : (int)Function.GetAllHeadOrSitewisePurchase,
            Bytes = new List<ArraySegment<byte>>() {
                Encoding.ASCII.GetBytes(type + '\0'),
                Encoding.ASCII.GetBytes(Dates.From.Value.ToString("yyyy-MM-dd") + '\0'),
                Encoding.ASCII.GetBytes(Dates.To.Value.ToString("yyyy-MM-dd") + '\0'),
            }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            //message
            return;
        }
        object data = type.Equals("Party") ?
            await getKeyTrippleValues(response.Packet) :
            await getKeyValues(response.Packet);

        Data = CollectionViewSource.GetDefaultView(data);
        Data.Filter = filter;
        OnPropertyChanged(nameof(Data));
    }

    Task<List<KeyValueSeries>> getKeyValues(byte[] packet) {
        var list = new List<KeyValueSeries>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        int start = 0;
        while (read < span.Length) {
            while (span[read] != 0) read++;

            list.Add(new KeyValueSeries() {
                Key = Encoding.ASCII.GetString(span.Slice(start, read - start)),
                Value = BitConverter.ToInt32(span.Slice(read + 1, 4))
            });
            read += 5;
            start = read;
        }
        return Task.FromResult(list);
    }
    Task<List<KeyTrippleValueSeries>> getKeyTrippleValues(byte[] packet) {
        var list = new List<KeyTrippleValueSeries>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        int start = 0;
        while (read < span.Length) {
            while (span[read] != 0) read++;
            list.Add(new KeyTrippleValueSeries() {
                Key = Encoding.ASCII.GetString(span.Slice(start, read - start)),
                Value1 = BitConverter.ToInt32(span.Slice(read + 1, 4)),
                Value2 = BitConverter.ToInt32(span.Slice(read + 5, 4)),
                Value3 = BitConverter.ToInt32(span.Slice(read + 9, 4)),
            });
            read += 13;
            start = read;
        }
        return Task.FromResult(list);
    }
}

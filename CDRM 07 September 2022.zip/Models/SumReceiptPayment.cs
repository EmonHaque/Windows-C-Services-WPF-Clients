﻿class SumReceiptPayment
{
    public string PrimaryGroup { get; set; }
    public string SecondaryGroup { get; set; }
    public int Payment { get; set; }
    public int Receipt { get; set; }
    public int TotalPayment { get; set; }
    public int TotalReceipt { get; set; }
    public sbyte Count { get; set; }
    public List<RPToolTipEntry> Entries { get; set; }
}

﻿class SumPartyTransaction
{
    public int PartyId { get; set; }
    public string Party { get; set; }
    public int Paid { get; set; }
    public int Balance { get; set; }
    public bool IsSettled { get; set; }
    public List<SumTransaction> Transactions { get; set; }
}

﻿class EntryPurchaseSell : Notifiable, IHaveTitle
{
    public int Id { get; set; }
    public DateTime? Date { get; set; }
    public string Amount { get; set; }
    public byte IsSell { get; set; }
    public byte IsConstruction { get; set; }
    public string Site { get; set; }
    public string Party { get; set; }
    public string Head { get; set; }
    public string SubHead { get; set; }
    public string Unit { get; set; }
    public string Quantity { get; set; }
    public string Narration { get; set; }
    public string Title { get; set; }

    public int SiteId { get; set; }
    public int PartyId { get; set; }
    public int HeadId { get; set; }
    public int SubHeadId { get; set; }
    public int UnitId { get; set; }
}

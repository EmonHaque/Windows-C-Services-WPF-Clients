﻿static class ConvertFromBytes
{
    public static Site ToSite(this ReadOnlySpan<byte> array) {
        int read, start, index;
        index = 0;
        read = start = 4;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new Site() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = segments[0],
            Address = segments[1]
        };
    }
    public static Party ToParty(this ReadOnlySpan<byte> array) {
        int read, start, index;
        index = 0;
        read = start = 4;
        var segments = new string[3];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new Party() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = segments[0],
            Address = segments[1],
            Phone = segments[2]
        };
    }
    public static Head ToHead(this ReadOnlySpan<byte> array) {
        return new Head() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = Encoding.ASCII.GetString(array.Slice(4, array.Length - 5))
        };
    }
    public static SubHead ToSubhead(this ReadOnlySpan<byte> array) {
        return new SubHead() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = Encoding.ASCII.GetString(array.Slice(4, array.Length - 5))
        };
    }
    public static Unit ToUnit(this ReadOnlySpan<byte> array) {
        return new Unit() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = Encoding.ASCII.GetString(array.Slice(4, array.Length - 5))
        };
    }
    public static NoteType ToNoteType(this ReadOnlySpan<byte> array) {
        return new NoteType() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = Encoding.ASCII.GetString(array.Slice(4, array.Length - 5))
        };
    }
    public static Note ToNote(this ReadOnlySpan<byte> array) {
        int start, read, index;
        start = read = 12;
        index = 0;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new Note() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            SiteId = BitConverter.ToInt32(array.Slice(4, 4)),
            NoteTypeId = BitConverter.ToInt32(array.Slice(8, 4)),
            Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
            Entry = segments[1]
        };
    }
}

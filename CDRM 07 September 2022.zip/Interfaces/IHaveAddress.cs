﻿interface IHaveAddress
{
    string Address { get; set; }
}

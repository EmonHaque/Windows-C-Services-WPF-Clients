﻿interface IHaveTitle
{
    int Id { get; set; }
    DateTime? Date { get; set; }
    string Title { get; set; }
    string Party { get; set; }
}

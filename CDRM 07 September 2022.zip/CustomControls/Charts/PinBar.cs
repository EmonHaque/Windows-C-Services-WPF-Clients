﻿class PinBar : FrameworkElement
{
    Line line;
    Border bar;
    EllipseGeometry circleGeo;
    Path circle;
    DoubleAnimation onLoadAnim, thicknessAnim;
    ColorAnimation lineColorAnim, circleColorAnim;
    SolidColorBrush lineBrush, circleBrush;
    VisualCollection children;
    Size available;
    Color lineNormal, circleNormal, lineHighlight, circleHighlight;
    double radius = 3.0;
    public double pinUpperBound, barUpperBound;
    KeyTrippleValueSeries entry;

    public PinBar(KeyTrippleValueSeries entry) {
        this.entry = entry;
        ToolTip = new TextBlock() {
            Foreground = Brushes.LightGray,
            Text = $"Value: {entry.Value1.ToString("N2")}",
            TextAlignment = TextAlignment.Center
        };
        lineNormal = Colors.Gray;
        circleNormal = Colors.CornflowerBlue;
        lineHighlight = Colors.LightGray;
        circleHighlight = Colors.Coral;
        lineBrush = new SolidColorBrush(lineNormal);
        circleBrush = new SolidColorBrush(circleNormal);
        line = new Line() {
            Stroke = lineBrush,
            StrokeThickness = 1.5,
            RenderTransform = new ScaleTransform(1, 0)
        };
        circleGeo = new EllipseGeometry() { RadiusX = radius, RadiusY = radius };
        circle = new Path() {
            Fill = circleBrush,
            Data = circleGeo,
            RenderTransform = new TransformGroup() {
                Children = {
                    new TranslateTransform(),
                    new ScaleTransform(0.25,0.25)
                }
            }
        };
        bar = new Border() {
            Background = new SolidColorBrush(Color.FromArgb(75, 0,0,0)),
            CornerRadius = new CornerRadius(0, 0, 5, 5),
            Margin = new Thickness(2,0,2,0)
        };
        children = new VisualCollection(this) { bar, line, circle };
        initializaAnimations();
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        ((TranslateTransform)((TransformGroup)circle.RenderTransform).Children[0]).Y = available.Height - line.Y2;
        ((ScaleTransform)((TransformGroup)circle.RenderTransform).Children[1]).CenterY = available.Height;
        ((ScaleTransform)((TransformGroup)circle.RenderTransform).Children[1]).CenterX = available.Width / 2;
        line.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, onLoadAnim);
        ((TransformGroup)circle.RenderTransform).Children[0].BeginAnimation(TranslateTransform.YProperty, onLoadAnim);
        ((TransformGroup)circle.RenderTransform).Children[1].BeginAnimation(ScaleTransform.ScaleXProperty, onLoadAnim);
        ((TransformGroup)circle.RenderTransform).Children[1].BeginAnimation(ScaleTransform.ScaleYProperty, onLoadAnim);
    }
    void initializaAnimations() {
        var ease = new CubicEase() { EasingMode = EasingMode.EaseIn };
        var duration = TimeSpan.FromSeconds(0.5);
        onLoadAnim = new DoubleAnimation() {
            To = 1,
            Duration = TimeSpan.FromSeconds(1),
            EasingFunction = ease
        };
        lineColorAnim = new ColorAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
        circleColorAnim = new ColorAnimation() {
            Duration = duration,
            EasingFunction = ease
        };

        thicknessAnim = new DoubleAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
    }
    void animate() {
        line.BeginAnimation(Line.StrokeThicknessProperty, thicknessAnim);
        lineBrush.BeginAnimation(SolidColorBrush.ColorProperty, lineColorAnim);
        circleBrush.BeginAnimation(SolidColorBrush.ColorProperty, circleColorAnim);
    }
    protected override Size MeasureOverride(Size availableSize) {
        available = availableSize;
        var newPinBound = pinUpperBound / available.Height * radius + pinUpperBound;
        //var newBarBound = barUpperBound / available.Height * radius + pinUpperBound;
        line.Y2 = entry.Value2 / newPinBound * available.Height;
        line.X1 = line.X2 = available.Width / 2;
        circleGeo.Center = new Point(line.X1, line.Y2);
        bar.Height = entry.Value3 / barUpperBound * available.Height;
        bar.Width = available.Width - bar.Margin.Left - bar.Margin.Right;
        foreach (UIElement child in children)
            child.Measure(availableSize);
        return availableSize;
    }
    protected override Size ArrangeOverride(Size finalSize) {
        foreach (UIElement child in children)
            child.Arrange(new Rect(child.DesiredSize));
        return finalSize;
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        circleColorAnim.To = circleHighlight;
        lineColorAnim.To = lineHighlight;
        thicknessAnim.To = 2;
        animate();
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        circleColorAnim.To = circleNormal;
        lineColorAnim.To = lineNormal;
        thicknessAnim.To = 1.5;
        animate();
    }
    protected override Visual GetVisualChild(int index) => children[index];
    protected override int VisualChildrenCount => children.Count;
}

﻿class HorizontalPinLineBarTemplate : DataTemplate
{
    public HorizontalPinLineBarTemplate() {
        var bar = new FrameworkElementFactory(typeof(HorizontalPinLineBar));
        bar.SetBinding(HorizontalPinLineBar.X1MaxProperty, new Binding(nameof(HorizontalPinLineBarChart.X1Max)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(HorizontalPinLineBarChart), 1)
        });
        bar.SetBinding(HorizontalPinLineBar.X2MaxProperty, new Binding(nameof(HorizontalPinLineBarChart.X2Max)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(HorizontalPinLineBarChart), 1)
        });
        //this probably has issue when VirtualizingStackPanel virtualizes
        bar.SetBinding(HorizontalPinLineBar.PreviousProperty, new Binding() {
            RelativeSource = new RelativeSource(RelativeSourceMode.PreviousData)
        });
        VisualTree = bar;
    }
}

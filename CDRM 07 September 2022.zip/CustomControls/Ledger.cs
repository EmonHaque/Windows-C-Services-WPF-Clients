﻿class Ledger : Grid
{
    TextBlock totalReceipt, totalPayment;
    Border header, footer;
    ListBox entries;
    Thickness padding;
    double fixedColumnWidth = 80;

    public Ledger() {
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

        padding = new Thickness(5, 0, 5, 0);
        initializeHeader();
        initializeEntries();
        initializeFooter();

        SetRow(entries, 1);
        SetRow(footer, 2);

        Children.Add(header);
        Children.Add(entries);
        Children.Add(footer);
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        totalReceipt.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(Summary)}.Item1") { StringFormat = Constants.NumberFormat });
        totalPayment.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(Summary)}.Item2") { StringFormat = Constants.NumberFormat });
    }

    void initializeHeader() {
        var date = new TextBlock() { Text = "Date" };
        var particulars = new TextBlock() { Text = "Particulars" };
        var receipt = new TextBlock() {
            Inlines = { "Payment/", new LineBreak(), "Receivable" },
            TextAlignment = TextAlignment.Right,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        var payment = new TextBlock() {
            Inlines = { "Receipt/", new LineBreak(), "Payable" },
            TextAlignment = TextAlignment.Right,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        var balance = new TextBlock() {
            Inlines = { "Net", new LineBreak(), "Payable" },
            TextAlignment = TextAlignment.Right,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        SetColumn(particulars, 1);
        SetColumn(receipt, 2);
        SetColumn(payment, 3);
        SetColumn(balance, 4);
        var grid = new Grid() {
            Margin = new Thickness(0, 0, Constants.LeadgerRightMargin, 0),
            Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center),
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                            }
                        }
                    }
                },
            ColumnDefinitions = {
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(),
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) }
                },
            Children = { date, particulars, receipt, payment, balance }
        };
        header = new Border() {
            Padding = padding,
            BorderThickness = new Thickness(0, 0.5, 0, 0.5),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
    }
    void initializeEntries() {
        entries = new ListBox() {
            Margin = new Thickness(0,3,0,3),
            ItemTemplate = new LedgerTemplate(),
            Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                            }
                        }
                    }
                }
        };
    }
    void initializeFooter() {
        var totalText = new TextBlock() { Text = "Total" };
        totalReceipt = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalPayment = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        SetColumn(totalReceipt, 2);
        SetColumn(totalPayment, 3);
        var grid = new Grid() {
            Margin = new Thickness(0, 0, Constants.LeadgerRightMargin, 0),
            Resources = {
                    {
                        typeof(TextBlock),
                        new Style(){
                        Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)}
                        }
                    }
                },
            ColumnDefinitions = {
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(),
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) }
                },
            Children = { totalText, totalReceipt, totalPayment }
        };

        footer = new Border() {
            Padding = padding,
            BorderThickness = new Thickness(0, 0.5, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
    }

    #region DependencyProperties
    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public Tuple<int, int> Summary {
        get { return (Tuple<int, int>)GetValue(SummaryProperty); }
        set { SetValue(SummaryProperty, value); }
    }

    public static readonly DependencyProperty SummaryProperty =
        DependencyProperty.Register("Summary", typeof(Tuple<int, int>), typeof(Ledger), new PropertyMetadata(null));

    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(Ledger), new PropertyMetadata(null, onSourceChanged));

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as Ledger;
        o.entries.ItemsSource = (IEnumerable)e.NewValue;
    }
    #endregion
}

﻿class App : ClientApp
{
    public AppData appData = new();
    protected override IPAddress address => IPAddress.Parse(Addresses.RentManagerAddress);
    protected override int port => Addresses.RentManagerPort;
    protected override Request initRequest => new Request() {
        UserId = service.UserId,
        Method = (int)Function.GetInitialData,
        Bytes = new List<ArraySegment<byte>>()
    };
    protected override ImageSource appIcon {
        get {
            var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("RentManager.Resources.AppIcon.png");
            var source = BitmapFrame.Create(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
            stream.Close();
            stream.Dispose();
            return source;
        }
    }
    protected override AppDataBase baseData => appData;
    protected override string appTitle => "Rent Manager";
    const string appExeName = "RentManager";
    const string appVersion = "1.0";

    [STAThread]
    static void Main(string[] args)  {
#if DEBUG
        new App().Run();
#else
        if (args.Length == 0) {
            launch(new LaunchArgs() {
                App = appExeName,
                Version = appVersion,
                Path = AppDomain.CurrentDomain.BaseDirectory
            });
        }
        else new App().Run();
#endif
    }
    
    protected override Window SetResourceAndWindow() {
        new Converters();
        return new RootWindow() {
            Content = new RootPanel() {
                Children = {
                    new HomeView(),
                    new AddView(),
                    new EditView(),
                    new TransactionView(),
                    new ReportView()
                }
            }
        };
    }
}

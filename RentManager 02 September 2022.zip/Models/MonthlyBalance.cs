﻿class MonthlyBalance
{
    public string Plot { get; set; }
    public string Tenant { get; set; }
    public int Due { get; set; }
    public int LastMonthDue { get; set; }
    public int Payment { get; set; }
    public int ShortOrLong { get; set; }
    public string Date { get; set; }
}

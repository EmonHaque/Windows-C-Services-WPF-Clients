﻿using System.Collections.ObjectModel;
using static System.Reflection.Metadata.BlobBuilder;

static class FromBytes
{
    public static Plot GetPlot(this ReadOnlySpan<byte> array) {
        int start = 0;
        int read = 0;
        int id = BitConverter.ToInt32(array.Slice(start, 4));
        read += 4;
        start = read;

        while (array[read] != 0) read++;
        var name = Encoding.ASCII.GetString(array.Slice(start, read - start));

        start = ++read;
        while (array[read] != 0) read++;
        var description = Encoding.ASCII.GetString(array.Slice(start, read - start));

        return new Plot() {
            Id = id,
            Name = name,
            Description = description
        };
    }
    public static Space GetSpace(this ReadOnlySpan<byte> array) {
        int read = 8;
        int start = 8;
        int index = 0;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new Space() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            PlotId = BitConverter.ToInt32(array.Slice(4, 4)),
            Name = segments[0],
            Description = segments[1],
            IsVacant = BitConverter.ToBoolean(array.Slice(read, 1))
        };
    }
    public static Tenant GetTenant(this ReadOnlySpan<byte> array) {
        int read = 4;
        int start = 4;
        int index = 0;
        var segments = new string[7];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new Tenant() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = segments[0],
            Father = segments[1],
            Mother = segments[2],
            Husband = segments[3],
            Address = segments[4],
            NID = segments[5],
            ContactNo = segments[6],
            HasLeft = BitConverter.ToBoolean(array.Slice(read, 1))
        };
    }
    public static Head GetHead(this ReadOnlySpan<byte> array) {
        int read = 0;
        int start = 0;
        int id = BitConverter.ToInt32(array.Slice(start, 4));
        int controlId = BitConverter.ToInt32(array.Slice(start + 4, 4));
        read += 8;
        start = read;
        while (array[read] != 0) read++;
        var name = Encoding.ASCII.GetString(array.Slice(start, read - start));

        start = ++read;
        while (array[read] != 0) read++;
        var description = Encoding.ASCII.GetString(array.Slice(start, read - start));

        return new Head() {
            Id = id,
            ControlId = controlId,
            Name = name,
            Description = description
        };
    }
    public static Receivable GetReceivable(this ReadOnlySpan<byte> array) {
        return new Receivable() {
            LeaseId = BitConverter.ToInt32(array.Slice(0, 4)),
            HeadId = BitConverter.ToInt32(array.Slice(4, 4)),
            Amount = BitConverter.ToInt32(array.Slice(8, 4)),
        };
    }
    public static Lease GetLease(this ReadOnlySpan<byte> array) {
        var lease = new Lease() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            PlotId = BitConverter.ToInt32(array.Slice(4, 4)),
            SpaceId = BitConverter.ToInt32(array.Slice(8, 4)),
            TenantId = BitConverter.ToInt32(array.Slice(12, 4)),
        };
        int index = 0;
        int read = 16;
        int start = 16;
        var segments = new string[3];

        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        lease.DateStart = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);
        lease.DateEnd = string.IsNullOrWhiteSpace(segments[1]) ? null : DateTime.ParseExact(segments[1], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);
        lease.Business = segments[2];
        lease.IsExpired = BitConverter.ToBoolean(array.Slice(read, 1));
        read++;

        var balance = array.Length - read;
        var numReceivable = balance / 12;

        ObservableCollection<Receivable> receivables = null;
        App.Current.Dispatcher.Invoke(() => {
            receivables = new();
            BindingOperations.EnableCollectionSynchronization(receivables, receivables);
        });
        for (int i = 0; i < numReceivable; i++) {
            receivables.Add(array.Slice(read, 12).GetReceivable());
            //receivables.Add(Receivable.FromBytes(array.Slice(read, 12)));
            read += 12;
        }
        lease.FixedReceivables = receivables;
        return lease;
    }
    public static Transaction GetTransaction(this ReadOnlySpan<byte> array) {
        var transaction = new Transaction() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            PlotId = BitConverter.ToInt32(array.Slice(4, 4)),
            SpaceId = BitConverter.ToInt32(array.Slice(8, 4)),
            TenantId = BitConverter.ToInt32(array.Slice(12, 4)),
            ControlId = BitConverter.ToInt32(array.Slice(16, 4)),
            HeadId = BitConverter.ToInt32(array.Slice(20, 4)),
            Amount = BitConverter.ToInt32(array.Slice(24, 4)),
            IsCash = array.Slice(28, 1)[0],
        };
        int read = 29;
        int start = 29;
        while (array[read] != 0) read++;
        var date = Encoding.ASCII.GetString(array.Slice(start, read - start));
        transaction.Date = DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);

        start = ++read;
        while (array[read] != 0) read++;
        transaction.Narration = Encoding.ASCII.GetString(array.Slice(start, read - start));
        return transaction;
    }
}

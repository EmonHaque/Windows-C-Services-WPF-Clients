﻿class PlotRentVM : Notifiable
{
    int? currentId;
    bool state;
    public bool State {
        get { return state; }
        set {
            if (state != value) {
                state = value;
                if (state) getData();
                else if (currentId != null) getData(currentId);
                else {
                    Data = null;
                    OnPropertyChanged(nameof(Data));
                }
            }
        }
    }
    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }
    public List<PlotwiseRent> Data { get; set; }
    public Action Refresh { get; set; }

    public PlotRentVM() {
        Refresh = refresh;
        RentVM.SelectionChanged += onSelectionChanged;
    }
    
    void refresh() {
        if (State) getData();
        else getData(currentId);
    }
    void onSelectionChanged(int? id, List<DepositDueRent> list) {
        if (currentId == id) return;
        currentId = id;
        if (!State) getData(currentId);
        else {
            State = false;
            OnPropertyChanged(nameof(State));
        }
    }
    async void getData() {
        var date = DateTime.Today.AddYears(-2);
        date = new DateTime(date.Year, date.Month, 1);
        Status = "requesting data";
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetPlotwiseRent,
            Bytes = new List<ArraySegment<byte>>() {
                BitConverter.GetBytes(0),
                Encoding.ASCII.GetBytes(date.ToString("yyyy-MM-dd") + '\0')
            }
        };
        var response = await App.service.GetResponse(request);
        Status = "received " + response.Packet.Length.ToString("N0") + " bytes";
        await Task.Delay(250);
        if (!response.IsSuccess) {
            Status = LocalConstants.DownMessage;
            return;
        }
        Data = await getEntries(response.Packet);
        OnPropertyChanged(nameof(Data));
    }
    async void getData(int? id) {
        if (id == null) {
            Data = null;
            OnPropertyChanged(nameof(Data));
            return;
        }
        var date = DateTime.Today.AddYears(-2);
        date = new DateTime(date.Year, date.Month, 1);
        Status = "requesting data";
        await Task.Delay(250);
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetPlotwiseRent,
            Bytes = new List<ArraySegment<byte>>() {
                BitConverter.GetBytes(id.Value),
                Encoding.ASCII.GetBytes(date.ToString("yyyy-MM-dd") + '\0')
            }
        };
        var response = await App.service.GetResponse(request);
        Status = "received " + response.Packet.Length.ToString("N0") + " bytes";
        await Task.Delay(250);
        if (!response.IsSuccess) {
            Status = LocalConstants.DownMessage;
            return;
        }
        Data = await getEntries(response.Packet);
        OnPropertyChanged(nameof(Data));
    }
    Task<List<PlotwiseRent>> getEntries(byte[] packet) {
        var list = new List<PlotwiseRent>();
        var span = new ReadOnlySpan<byte>(packet);
        int read, start, index;;
        read = index = start = 0;

        while (read < span.Length) {
            var segments = new string[3];
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            list.Add(new PlotwiseRent() {
                Plot = segments[0],
                Tenant = segments[1],
                Month = segments[2],
                Rent = BitConverter.ToInt32(span.Slice(start, 4)),
                Cash = BitConverter.ToInt32(span.Slice(start + 4, 4)),
                Mobile = BitConverter.ToInt32(span.Slice(start + 8, 4)),
                Kind = BitConverter.ToInt32(span.Slice(start + 12, 4)),
                Total = BitConverter.ToInt32(span.Slice(start + 16, 4)),
                PlotId = BitConverter.ToInt32(span.Slice(start + 20, 4)),
            });
            read += 24;
            start = read;
            index = 0;
        }
        return Task.FromResult(list);
    }
}

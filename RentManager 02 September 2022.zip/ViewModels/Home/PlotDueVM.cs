﻿class PlotDueVM : Notifiable
{
    int? currentId;
    bool state;
    public bool State {
        get { return state; }
        set {
            if (state != value) {
                state = value;
                if (state) {
                    getData();
                }
                else if (currentId != null) {
                    getData(currentId);
                }
                else {
                    Data = null;
                    OnPropertyChanged(nameof(Data));
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
    }
    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }
    public Action Refresh { get; set; }
    public List<PlotWiseDue> Data { get; set; }
    public string Name { get; set; }

    public PlotDueVM() {
        Refresh = refresh;
        RentVM.SelectionChanged += onSelectionChanged;
    }
    
    void refresh() {
        if (State) getData();
        else getData(currentId);
    }
    void onSelectionChanged(int? id, List<DepositDueRent> arg2) {
        if (currentId == id) return;
        currentId = id;
        if (!State) getData(currentId);
        else {
            State = false;
            OnPropertyChanged(nameof(State));
        }
    }
    async void getData() {
        var date = DateTime.Today.AddYears(-2);
        date = new DateTime(date.Year, date.Month, 1);
        Status = "requesting data";
        await Task.Delay(250);
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetPlotDueChart,
            Bytes = new List<ArraySegment<byte>>() {
                BitConverter.GetBytes(0),
                Encoding.ASCII.GetBytes(date.ToString("yyyy-MM-dd") +'\0')
            }
        };
        var response = await App.service.GetResponse(request);
        Status = "received " + response.Packet.Length.ToString("N0") + " bytes";
        await Task.Delay(250);
        if (!response.IsSuccess) {
            return;
        }
        Data = await getEntries(response.Packet);

        Name = "in All plots";
        OnPropertyChanged(nameof(Data));
        OnPropertyChanged(nameof(Name));
    }
    async void getData(int? id) {
        if (id == null) {
            Data = null;
            Name = null;
            OnPropertyChanged(nameof(Data));
            OnPropertyChanged(nameof(Name));
            return;
        }
        var date = DateTime.Today.AddYears(-2);
        date = new DateTime(date.Year, date.Month, 1);

        Status = "requesting data";
        await Task.Delay(250);
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetPlotDueChart,
            Bytes = new List<ArraySegment<byte>>() {
                BitConverter.GetBytes(id.Value),
                Encoding.ASCII.GetBytes(date.ToString("yyyy-MM-dd") +'\0')
            }
        };

        var response = await App.service.GetResponse(request);
        Status = "received " + response.Packet.Length.ToString("N0") + " bytes";
        await Task.Delay(250);
        if (!response.IsSuccess) {
            Status = LocalConstants.DownMessage;
            return;
        }
        Data = await getEntries(response.Packet);

        Name = Data.Count > 0 ? "in " + AppData.plots.First(x => x.Id == id).Name : null;
        OnPropertyChanged(nameof(Data));
        OnPropertyChanged(nameof(Name));
    }

    Task<List<PlotWiseDue>> getEntries(byte[] packet) {
        var list = new List<PlotWiseDue>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        int start = 0;
        while (read < span.Length) {
            while (span[read] != 0) read++;
            var month = Encoding.ASCII.GetString(span.Slice(start, read - start));
            start = ++read;
            while (span[read] != 0) read++;
            var tenant = Encoding.ASCII.GetString(span.Slice(start, read - start));
            read++;
            list.Add(new PlotWiseDue() {
                Tenant = tenant,
                Month = month,
                Due = BitConverter.ToInt32(span.Slice(read, 4)),
            });
            read += 4;
            start = read;
        }
        return Task.FromResult(list);
    }
}

﻿class AddTenantVM : AddBase<Tenant>
{
    public string ErrorName { get; set; }
    public string ErrorFather { get; set; }
    public string ErrorAddress { get; set; }
    public string ErrorContactNo { get; set; }
    public bool IsValid { get; set; }

    public AddTenantVM()  {
        TObject.PropertyChanged += validate;
        initializeValidationProperties();
    }

    void initializeValidationProperties() {
        IsValid = false;
        ErrorName = "Name is required";
        ErrorFather = "Father is required";
        ErrorAddress = "Addres is required";
        ErrorContactNo = "Contact No. is required";
        OnPropertyChanged(nameof(ErrorName));
        OnPropertyChanged(nameof(ErrorFather));
        OnPropertyChanged(nameof(ErrorAddress));
        OnPropertyChanged(nameof(ErrorContactNo));
        OnPropertyChanged(nameof(IsValid));
    }

    #region validation rules
    void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Tenant.Name): validateName(); break;
            case nameof(Tenant.Father): validateFather(); break;
            case nameof(Tenant.Address): validateAddress(); break;
            case nameof(Tenant.ContactNo): validateContactNo(); break;
        }
        IsValid =
            ErrorName == string.Empty &&
            ErrorFather == string.Empty &&
            ErrorAddress == string.Empty &&
            ErrorContactNo == string.Empty
            ? true : false;
        OnPropertyChanged(nameof(IsValid));

    }
    void validateName() {
        ErrorName = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Name)) ErrorName = "Name is required";
        else {
            for (int i = 0; i < AppData.tenants.Count; i++) {
                if (string.Equals(AppData.tenants[i].Name, TObject.Name.Trim(), StringComparison.OrdinalIgnoreCase)) {
                    ErrorName = "Name exits";
                    break;
                }
            }
        }
        OnPropertyChanged(nameof(ErrorName));
    }
    void validateFather() {
        ErrorFather = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Father)) ErrorFather = "Father is required";
        OnPropertyChanged(nameof(ErrorFather));
    }
    void validateAddress() {
        ErrorAddress = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Address)) ErrorAddress = "Address is required";
        OnPropertyChanged(nameof(ErrorAddress));
    }
    void validateContactNo() {
        ErrorContactNo = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.ContactNo)) ErrorContactNo = "Contact No. is required";
        OnPropertyChanged(nameof(ErrorContactNo));
    }
    #endregion

    #region base implementation
    protected override ObservableCollection<Tenant> collection => AppData.tenants;
    protected override string errorTitle => "Tenant";
    protected override List<ArraySegment<byte>> bytes => TObject.GetBytes();
    protected override Function function => Function.AddTenant;
    protected override void renewTObject() {
        TObject.PropertyChanged -= validate;
        TObject = new Tenant();
        OnPropertyChanged(nameof(TObject));
        TObject.PropertyChanged += validate;
        initializeValidationProperties();
    }
    #endregion
}

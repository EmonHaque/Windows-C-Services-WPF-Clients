﻿class AddLeaseVM : AddBase<Lease>
{
    CollectionViewSource plots, spaces, tenants;
    bool isAddingReceivable;
    string amount;
    public string Amount {
        get { return amount; }
        set {
            if (amount != value) {
                amount = value;
                OnPropertyChanged(nameof(Amount));
                validateAmount();
            }
        }
    }
    public string ErrorPlotId { get; set; }
    public string ErrorSpaceId { get; set; }
    public string ErrorTenantId { get; set; }
    public string ErrorBusiness { get; set; }
    public string ErrorDate { get; set; }
    public string ErrorAmount { get; set; }
    public string ErrorHeadId { get; set; }
    public string ErrorCharge { get; set; }
    public bool IsValid { get; set; }
    public bool IsReceivableValid { get; set; }
    public string PlotQuery { get; set; }
    public string SpaceQuery { get; set; }
    public string TenantQuery { get; set; }
    public string HeadQuery { get; set; }
    public Receivable NewReceivable { get; set; }
    public ICollectionView Plots { get; set; }
    public ICollectionView VacantSpaces { get; set; }
    public ICollectionView AvailableTenants { get; set; }
    public ICollectionView ReceivableHeads { get; set; }
    public Action AddReceivable { get; set; }
    public Action<Receivable> RemoveReceivable { get; set; }
    public Action<SelectQuery, string> FilterCommand { get; set; }
    public static event Action<Lease> LeaseAdded;

    public AddLeaseVM() {
        initializeCollections();
        TObject.PropertyChanged += validate;
        NewReceivable = new Receivable() { LeaseId = TObject.Id };
        initializeFilters();
        AddReceivable = addReceivable;
        RemoveReceivable = removeReceivable;
        NewReceivable.PropertyChanged += validateReceivable;
        initializeValidationProperties();
        FilterCommand = filterCommand;
        ErrorPlotId = ErrorSpaceId = ErrorTenantId = " is required";

        ((App)Application.Current).appData.PlotAdded += onPlotAdded;
        ((App)Application.Current).appData.SpaceAdded += onSpaceAdded;
        ((App)Application.Current).appData.TenantAdded += onTenantAdded;
        ((App)Application.Current).appData.HeadAdded += onHeadAdded;
    }

    void onHeadAdded(Head head) {
        if(head.ControlId == AppData.controlIdOfReceivable) {
            NewReceivable.HeadId = head.Id;
        }
    }

    void onTenantAdded(Tenant t) => TObject.TenantId = t.Id;
    void onPlotAdded(Plot p) => TObject.PlotId = p.Id;
    void onSpaceAdded(Space s) {
        if(TObject.PlotId == s.PlotId)
            TObject.SpaceId = s.Id;
    }

    void filterCommand(SelectQuery parameter, string query) {
        switch (parameter) {
            case SelectQuery.Plot: PlotQuery = query; Plots.Refresh(); break;
            case SelectQuery.Space: SpaceQuery = query; VacantSpaces.Refresh(); break;
            case SelectQuery.Tenant: TenantQuery = query; AvailableTenants.Refresh(); break;
            case SelectQuery.Head:
                if (!isAddingReceivable) {
                    HeadQuery = query;
                    ReceivableHeads.Refresh();
                }
                break;
        }
    }

    void initializeValidationProperties() {
        IsValid = false;
        ErrorCharge = ErrorDate = " is required";
        ErrorBusiness = "Business is required";
        ErrorAmount = "Amount is required";

        OnPropertyChanged(nameof(ErrorBusiness));
        OnPropertyChanged(nameof(ErrorDate));
        OnPropertyChanged(nameof(ErrorCharge));
        OnPropertyChanged(nameof(IsValid));
    }

    #region validation rules
    void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Lease.PlotId): validatePlotId(); break;
            case nameof(Lease.SpaceId): validateSpaceId(); break;
            case nameof(Lease.TenantId): validateTenantId(); break;
            case nameof(Lease.Business): validateBusiness(); break;
            case nameof(Lease.DateStart): validateDate(); break;
        }
        checkValidity();
    }
    void validateReceivable(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Receivable.Amount):
            case nameof(Receivable.HeadId): validateHead(); break;
        }
        IsReceivableValid =
            ErrorHeadId == string.Empty &&
            ErrorAmount == string.Empty
            ? true : false;
        OnPropertyChanged(nameof(IsReceivableValid));
    }
    void validatePlotId() {
        ErrorPlotId = string.Empty;
        if (TObject.PlotId == null)
            ErrorPlotId = " is required";
        OnPropertyChanged(nameof(ErrorPlotId));
        VacantSpaces.Refresh();
        TObject.SpaceId = (VacantSpaces.CurrentItem as Space)?.Id;
    }
    void validateSpaceId() {
        ErrorSpaceId = string.Empty;
        if (TObject.SpaceId == null)
            ErrorSpaceId = " is required";
        OnPropertyChanged(nameof(ErrorSpaceId));
    }
    void validateTenantId() {
        ErrorTenantId = string.Empty;
        if (TObject.TenantId == null)
            ErrorTenantId = " is required";
        OnPropertyChanged(nameof(ErrorTenantId));
    }
    void validateBusiness() {
        ErrorBusiness = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Business))
            ErrorBusiness = "Business is required";
        OnPropertyChanged(nameof(ErrorBusiness));
    }
    void validateDate() {
        ErrorDate = string.Empty;
        if (TObject.DateStart == null)
            ErrorDate = " is required";
        OnPropertyChanged(nameof(ErrorDate));
    }
    void validateHead() {
        ErrorHeadId = string.Empty;
        if (NewReceivable.HeadId == null)
            ErrorHeadId = " is required";
        OnPropertyChanged(nameof(ErrorHeadId));
    }
    void validateAmount() {
        ErrorAmount = string.Empty;
        if (string.IsNullOrWhiteSpace(Amount))
            ErrorAmount = "Amount in required";
        else {
            int x;
            if (int.TryParse(Amount, out x)) {
                if (x > 0) {
                    NewReceivable.Amount = x;
                    ErrorAmount = string.Empty;
                }
                else ErrorAmount = "Positive integers only";
            }
            else ErrorAmount = "Integer only";
        }
        OnPropertyChanged(nameof(ErrorAmount));

        IsReceivableValid =
            ErrorHeadId == string.Empty &&
            ErrorAmount == string.Empty
            ? true : false;
        OnPropertyChanged(nameof(IsReceivableValid));
    }
    void checkValidity() {
        IsValid =
            ErrorPlotId == string.Empty &&
            ErrorSpaceId == string.Empty &&
            ErrorTenantId == string.Empty &&
            ErrorDate == string.Empty &&
            ErrorBusiness == string.Empty &&
            ErrorCharge == string.Empty;
        OnPropertyChanged(nameof(IsValid));
    }
    #endregion

    #region For Constructor
    void initializeCollections() {
        plots = new CollectionViewSource() { Source = AppData.plots };
        spaces = new CollectionViewSource() {
            Source = AppData.spaces,
            IsLiveFilteringRequested = true,
            LiveFilteringProperties = { nameof(Space.IsVacant), nameof(Space.PlotId) }
        };
        tenants = new CollectionViewSource() {
            Source = AppData.tenants,
            IsLiveFilteringRequested = true,
            LiveFilteringProperties = { nameof(Tenant.HasLeft) }
        };
        Plots = plots.View;
        VacantSpaces = spaces.View;
        AvailableTenants = tenants.View;
        ReceivableHeads = new CollectionViewSource() { Source = AppData.heads }.View;
    }

    void initializeFilters() {
        Plots.Filter = filterPlots;
        VacantSpaces.Filter = filterSpaces;
        AvailableTenants.Filter = filterTenant;
        ReceivableHeads.Filter = filterReceivableHeads;
    }
    #endregion

    #region Commands
    void addReceivable() {
        isAddingReceivable = true;
        NewReceivable.PropertyChanged -= validateReceivable;
        TObject.FixedReceivables.Add(NewReceivable);

        NewReceivable = new Receivable() { LeaseId = TObject.Id };
        NewReceivable.PropertyChanged += validateReceivable;
        OnPropertyChanged(nameof(NewReceivable));

        Amount = null;
        if (ErrorCharge != string.Empty) {
            ErrorCharge = string.Empty;
            OnPropertyChanged(nameof(ErrorCharge));
            checkValidity();
        }
        ReceivableHeads.Refresh();
        NewReceivable.HeadId = (ReceivableHeads.CurrentItem as Head)?.Id;
        isAddingReceivable = false;
    }
    void removeReceivable(Receivable receivable) {
        isAddingReceivable = true;
        TObject.FixedReceivables.Remove(receivable);
        ReceivableHeads.Refresh();
        if (ReceivableHeads.CurrentItem == null)
            ReceivableHeads.MoveCurrentToFirst();
        if (TObject.FixedReceivables.Count == 0) {
            ErrorCharge = " is required";
            OnPropertyChanged(nameof(ErrorCharge));
            checkValidity();
        }
        isAddingReceivable = false;
    }
    #endregion

    #region Filters
    bool filterPlots(object o) {
        if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
        return ((Plot)o).Name.ToLower().Contains(PlotQuery);
        //if (string.IsNullOrWhiteSpace(query)) return true;
        //return ((Plot)o).Name.ToLower().Contains(query);
    }
    bool filterSpaces(object o) {
        if (TObject.PlotId == null) return false;
        var space = o as Space;
        var result = space.IsVacant && space.PlotId == TObject.PlotId;
        if (string.IsNullOrWhiteSpace(SpaceQuery)) return result;
        return space.Name.ToLower().Contains(SpaceQuery) && result;
        //if (string.IsNullOrWhiteSpace(query)) return result;
        //return space.Name.ToLower().Contains(query) && result;
    }
    bool filterTenant(object o) {
        var tenant = o as Tenant;
        if (string.IsNullOrWhiteSpace(TenantQuery)) return !tenant.HasLeft;
        return tenant.Name.ToLower().Contains(TenantQuery) && !tenant.HasLeft;
        //if (string.IsNullOrWhiteSpace(query)) return !tenant.HasLeft;
        //return tenant.Name.ToLower().Contains(query) && !tenant.HasLeft;
    }
    bool filterReceivableHeads(object o) {
        var head = o as Head;
        var result = head.ControlId == AppData.controlIdOfReceivable
            && TObject.FixedReceivables.FirstOrDefault(x => x.HeadId == head.Id) == null;
        if (string.IsNullOrWhiteSpace(HeadQuery)) return result;
        return head.Name.ToLower().Contains(HeadQuery) && result;
    }
    #endregion

    #region base implementation
    protected override ObservableCollection<Lease> collection => AppData.leases;
    protected override List<ArraySegment<byte>> bytes => TObject.GetBytes(TObject.FixedReceivables);
    protected override string errorTitle => "Lease";
    protected override Function function => Function.AddLease;
    protected override void renewTObject() {
        TObject.PropertyChanged -= validate;
        TObject.PlotName = AppData.plots.First(x => x.Id == TObject.PlotId).Name;
        TObject.SpaceName = AppData.spaces.First(x => x.Id == TObject.SpaceId).Name;
        TObject.TenantName = AppData.tenants.First(x => x.Id == TObject.TenantId).Name;
        LeaseAdded?.Invoke(TObject);

        TObject = new Lease() {
            PlotId = TObject.PlotId,
            SpaceId = TObject.SpaceId,
            TenantId = TObject.TenantId,
            Business = null,
            DateStart = null
        };
        OnPropertyChanged(nameof(TObject));
        TObject.PropertyChanged += validate;
        initializeValidationProperties();
        AppData.spaces.First(x => x.Id == TObject.SpaceId).IsVacant = false;

        NewReceivable.LeaseId = TObject.Id;
        ReceivableHeads.Refresh();
        ReceivableHeads.MoveCurrentToFirst();
        NewReceivable.HeadId = (ReceivableHeads.CurrentItem as Head)?.Id;
    }
    #endregion
}

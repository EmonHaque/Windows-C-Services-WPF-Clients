﻿class AddSpaceVM : AddBase<Space>
{
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value?.Trim().ToLower();
                Plots.Refresh();
            }
        }
    }
    CollectionViewSource plots;
    public string ErrorPlotId { get; set; }
    public string ErrorName { get; set; }
    public string ErrorDescription { get; set; }
    public bool IsValid { get; set; }
    public ICollectionView Plots { get; set; }

    public AddSpaceVM() {
        plots = new CollectionViewSource() { Source = AppData.plots };
        Plots = plots.View;
        Plots.Filter = filterPlot;
       
        TObject.IsVacant = true;
        ErrorPlotId = " is required";
        TObject.PropertyChanged += validate;
        initializeValidationProperties();
        validatePlotId();
        
        ((App)Application.Current).appData.PlotAdded += onPlotAdded;
    }

    void onPlotAdded(Plot p) => TObject.PlotId = p.Id;

    void initializeValidationProperties() {
        IsValid = false;
        ErrorName = "Name is required";
        ErrorDescription = "Description is required";

        OnPropertyChanged(nameof(ErrorName));
        OnPropertyChanged(nameof(ErrorDescription));
        OnPropertyChanged(nameof(IsValid));
    }

    bool filterPlot(object o) {
        var plot = o as Plot;
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return plot.Name.ToLower().Contains(Query);
    }

    #region validation rules
    void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Space.PlotId): validatePlotId(); break;
            case nameof(Space.Name): validateName(); break;
            case nameof(Space.Description): validateDescription(); break;
        }
        IsValid =
            ErrorPlotId == string.Empty &&
            ErrorName == string.Empty &&
            ErrorDescription == string.Empty
            ? true : false;
        OnPropertyChanged(nameof(IsValid));
    }
    void validatePlotId() {
        ErrorPlotId = string.Empty;
        if (TObject.PlotId == null)
            ErrorPlotId = " is required";
        OnPropertyChanged(nameof(ErrorPlotId));
    }
    void validateName() {
        ErrorName = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Name)) ErrorName = "Name is required";
        else {
            if (TObject.PlotId != null) {
                for (int i = 0; i < AppData.spaces.Count; i++) {
                    if (AppData.spaces[i].PlotId == TObject.PlotId) {
                        if (string.Equals(AppData.spaces[i].Name, TObject.Name.Trim(), StringComparison.OrdinalIgnoreCase)) {
                            ErrorName = "Name exists";
                            break;
                        }
                    }
                }
            }
        }
        OnPropertyChanged(nameof(ErrorName));
    }
    void validateDescription() {
        ErrorDescription = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Description)) ErrorDescription = "Description is required";
        OnPropertyChanged(nameof(ErrorDescription));
    }
    #endregion

    #region base implementation
    protected override ObservableCollection<Space> collection => AppData.spaces;
    protected override string errorTitle => "Space";
    protected override List<ArraySegment<byte>> bytes => TObject.GetBytes();
    protected override Function function => Function.AddSpace;
    protected override void renewTObject() {
        TObject.PropertyChanged -= validate;
        TObject.PlotName = AppData.plots.First(x => x.Id == TObject.PlotId).Name;
        TObject = new Space() {
            PlotId = TObject.PlotId,
            IsVacant = true
        };
        OnPropertyChanged(nameof(TObject));
        TObject.PropertyChanged += validate;
        initializeValidationProperties();
    }
    #endregion
}

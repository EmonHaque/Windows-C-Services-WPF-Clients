﻿class EditHeadVM : EditBase<Head>
{
    CollectionViewSource editableControls;
    bool isEqual;
    int? selectedControl;
    public int? SelectedControl {
        get { return selectedControl; }
        set {
            if (selectedControl != value) {
                selectedControl = value;
                Editables.Refresh();
            }
        }
    }
    string queryHead;
    public string QueryHead {
        get { return queryHead; }
        set {
            if (queryHead != value) {
                queryHead = value?.Trim().ToLower();
                Editables.Refresh();
            }
        }
    }
    public string NonEditableControlQuery { get; set; }
    public string ControlQuery { get; set; }
    public string ErrorControlId { get; set; }
    public string ErrorName { get; set; }
    public string ErrorDescription { get; set; }
    public bool IsValid { get; set; }
    public ICollectionView NonEditableControlHeads { get; set; }
    public ICollectionView ControlHeads { get; set; }
    public Action<SelectQuery, string> FilterCommand { get; set; }

    public EditHeadVM() {
        Editables = new CollectionViewSource() { Source = AppData.heads }.View;
        NonEditableControlHeads = new CollectionViewSource() { Source = AppData.controlHeads }.View;
        editableControls = new CollectionViewSource() { Source = AppData.controlHeads };
        ControlHeads = editableControls.View;
        Editables.Filter = filterHeads;
        NonEditableControlHeads.Filter = filterControls;
        ControlHeads.Filter = filterEditableControls;
        FilterCommand = filterCommand;
    }
    
    void filterCommand(SelectQuery parameter, string query) {
        switch (parameter) {
            case SelectQuery.ControlHead: ControlQuery = query; ControlHeads.Refresh(); break;
            case SelectQuery.NonEditable: NonEditableControlQuery = query; NonEditableControlHeads.Refresh(); break;
        }
    }

    #region filter
    bool filterHeads(object o) {
        if (SelectedControl == null) return false;
        var head = (Head)o;
        var result = head.ControlId == SelectedControl;
        if (string.IsNullOrWhiteSpace(QueryHead)) return result;
        return result && head.Name.ToLower().Contains(QueryHead);
    }
    bool filterControls(object o) {
        if (string.IsNullOrWhiteSpace(NonEditableControlQuery)) return true;
        return ((ControlHead)o).Name.ToLower().Contains(NonEditableControlQuery);
    }
    bool filterEditableControls(object o) {
        if (string.IsNullOrWhiteSpace(ControlQuery)) return true;
        return ((ControlHead)o).Name.ToLower().Contains(ControlQuery);
    }
    #endregion

    #region validation rules
    void validateControlId() {
        ErrorControlId = string.Empty;
        if (Edited.ControlId == null)
            ErrorControlId = "Control is required";
        else validateName();
        OnPropertyChanged(nameof(ErrorControlId));
    }
    void validateName() {
        ErrorName = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Name))
            ErrorName = "Name is required";
        else {
            var trimmedName = Edited.Name.Trim();
            if (Selected.ControlId != Edited.ControlId) {
                for (int i = 0; i < AppData.heads.Count; i++) {
                    if (AppData.heads[i].ControlId == Edited.ControlId)
                        if (string.Equals(trimmedName, AppData.heads[i].Name, StringComparison.OrdinalIgnoreCase))
                            ErrorName = "Name exists";
                }
            }
            else {
                if (!string.Equals(trimmedName, Selected.Name, StringComparison.OrdinalIgnoreCase)) {
                    for (int i = 0; i < AppData.heads.Count; i++) {
                        if (AppData.heads[i].ControlId == Edited.ControlId)
                            if (string.Equals(trimmedName, AppData.heads[i].Name, StringComparison.OrdinalIgnoreCase))
                                ErrorName = "Name exists";
                    }
                }
            }
        }
        OnPropertyChanged(nameof(ErrorName));
    }
    void validateDescription() {
        ErrorDescription = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Description))
            ErrorDescription = "Description is required";
        OnPropertyChanged(nameof(ErrorDescription));
    }
    #endregion

    #region base implementation
    protected override Function function => Function.EditHead;
    protected override string errorTitle => "Head";
    protected override List<ArraySegment<byte>> bytes => Edited.GetBytes();
    protected override Head clone() {
        return new Head() {
            Id = Selected.Id,
            ControlId = Selected.ControlId,
            Name = Selected.Name,
            Description = Selected.Description
        };
    }
    protected override void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Head.ControlId): validateControlId(); break;
            case nameof(Head.Name): validateName(); break;
            case nameof(Head.Description): validateDescription(); break;
        }
        isEqual =
            Selected.ControlId == Edited.ControlId &&
            string.Equals(Selected.Name, Edited.Name, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.Description, Edited.Description, StringComparison.OrdinalIgnoreCase);
        IsValid =
            !isEqual &&
            ErrorControlId == string.Empty &&
            ErrorName == string.Empty &&
            ErrorDescription == string.Empty;
        OnPropertyChanged(nameof(IsValid));
    }
    protected override void setValidationProperties() {
        isEqual = true;
        IsValid = false;
        ErrorControlId =
        ErrorName =
        ErrorDescription = string.Empty;
        OnPropertyChanged(nameof(ErrorControlId));
        OnPropertyChanged(nameof(ErrorName));
        OnPropertyChanged(nameof(ErrorDescription));
        OnPropertyChanged(nameof(IsValid));
    }
    #endregion
}

﻿class PlotwiseRentTemplate : DataTemplate
{
    public PlotwiseRentTemplate(HomePinTip tip) {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid" };
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col6 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var tenant = new FrameworkElementFactory(typeof(HiBlock));
        var rent = new FrameworkElementFactory(typeof(TextBlock));
        var cash = new FrameworkElementFactory(typeof(TextBlock));
        var mobile = new FrameworkElementFactory(typeof(TextBlock));
        var kind = new FrameworkElementFactory(typeof(TextBlock));
        var total = new FrameworkElementFactory(typeof(TextBlock));
        Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                    new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right)
                }
        });
        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col6.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        rent.SetValue(Grid.ColumnProperty, 1);
        cash.SetValue(Grid.ColumnProperty, 2);
        mobile.SetValue(Grid.ColumnProperty, 3);
        kind.SetValue(Grid.ColumnProperty, 4);
        total.SetValue(Grid.ColumnProperty, 5);
        tenant.SetValue(HiBlock.HorizontalAlignmentProperty, HorizontalAlignment.Left);

        tenant.SetBinding(HiBlock.TextProperty, new Binding(nameof(PlotwiseRent.Tenant)));
        tenant.SetBinding(HiBlock.QueryProperty, new Binding(nameof(tip.Query)) { Source = tip });
        rent.SetBinding(TextBlock.TextProperty, new Binding(nameof(PlotwiseRent.Rent)) { StringFormat = Constants.NumberFormat });
        cash.SetBinding(TextBlock.TextProperty, new Binding(nameof(PlotwiseRent.Cash)) { StringFormat = Constants.NumberFormat });
        mobile.SetBinding(TextBlock.TextProperty, new Binding(nameof(PlotwiseRent.Mobile)) { StringFormat = Constants.NumberFormat });
        kind.SetBinding(TextBlock.TextProperty, new Binding(nameof(PlotwiseRent.Kind)) { StringFormat = Constants.NumberFormat });
        total.SetBinding(TextBlock.TextProperty, new Binding(nameof(PlotwiseRent.Total)) { StringFormat = Constants.NumberFormat });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);
        grid.AppendChild(col6);
        grid.AppendChild(tenant);
        grid.AppendChild(rent);
        grid.AppendChild(cash);
        grid.AppendChild(mobile);
        grid.AppendChild(kind);
        grid.AppendChild(total);

        Triggers.Add(new Trigger() {
            Property = ItemsControl.AlternationIndexProperty,
            Value = 1,
            Setters = {
                new Setter(Grid.BackgroundProperty, Constants.BackgroundDark, "grid")
            }
        });

        VisualTree = grid;
    }
}

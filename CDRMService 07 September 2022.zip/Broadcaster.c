#include <winsock2.h>
#include "Structures.h"
#include "List.h"
#include "BlockingQueue.h"
#include "Messenger.h"

#pragma region variables
extern byte isRunning;
extern List receivers;
extern BlockingQueue publicResponses;
extern CRITICAL_SECTION criticalReceiver;

static HANDLE broadcastThread;
static List disconnectedReceivers;
#pragma endregion

static void sendSite(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	Site* site = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], site->id);
		sendString(list[i], site->name);
		sendString(list[i], site->address);
	}
}
static void sendParty(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	Party* party = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], party->id);
		sendString(list[i], party->name);
		sendString(list[i], party->address);
		sendString(list[i], party->phone);
	}
}
static void sendHead(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	Head* head = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], head->id);
		sendString(list[i], head->name);
	}
}
static void sendSubhead(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	Subhead* subHead = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], subHead->id);
		sendString(list[i], subHead->name);
	}
}
static void sendUnit(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	Unit* unit = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], unit->id);
		sendString(list[i], unit->name);
	}
}
static void sendNoteType(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	NoteType* type = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], type->id);
		sendString(list[i], type->name);
	}
}
static void sendNote(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	NoteEntry* note = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], note->id);
		sendInt(list[i], note->siteId);
		sendInt(list[i], note->noteTypeId);
		sendString(list[i], note->date);
		sendString(list[i], note->entry);
	}
	free(note->date);
	free(note->entry);
	free(r->data);
}
static void sendDeletedId(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	int *idp = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], *idp);
	}
	free(r->data);
}

static ulong BroadcastResponse(void* p) {
	while (isRunning) {
		ResponsePublic* r = takeOutFrom(&publicResponses);
		EnterCriticalSection(&criticalReceiver);
		switch (r->function) {
			case AddSite: 
			case EditSite: sendSite(r); break;
			case AddParty: 
			case EditParty: sendParty(r); break;
			case AddHead: 
			case EditHead: sendHead(r); break;
			case AddSubHead: 
			case EditSubHead: sendSubhead(r); break;
			case AddUnit: 
			case EditUnit: sendUnit(r); break;
			case AddNoteType: 
			case EditNoteType: sendNoteType(r); break;
			case AddNote: 
			case EditNote: sendNote(r); break;
			case DeleteNote:
			case DeletePurchaseSell:
			case DeleteReceiptPayment: sendDeletedId(r); break;
		}
		LeaveCriticalSection(&criticalReceiver);
		free(r);

		if (disconnectedReceivers.count > 0) {
			EnterCriticalSection(&criticalReceiver);
			SOCKET* list = disconnectedReceivers.data;
			for (int i = 0; i < disconnectedReceivers.count; i++) {
				closesocket(list[i]);
				removeFromList(&receivers, list[i]);
			}
			LeaveCriticalSection(&criticalReceiver);
			disconnectedReceivers.count = 0;
			if (disconnectedReceivers.capacity > 5) {
				disconnectedReceivers.capacity = 5;
				disconnectedReceivers.data = realloc(disconnectedReceivers.data, 5 * POINTER_SIZE);
			}
		}
	}
	CloseHandle(broadcastThread);
	return 0;
}

void InitializeBroadcaster() {
	disconnectedReceivers.count = 0;
	disconnectedReceivers.capacity = 5;
	disconnectedReceivers.data = malloc(5 * POINTER_SIZE);
	broadcastThread = CreateThread(NULL, 0, BroadcastResponse, NULL, 0, NULL);
}
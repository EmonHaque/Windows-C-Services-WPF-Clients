#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "sqlite3.lib")
#include <ws2tcpip.h>
#include "Structures.h"
#include "List.h"
#include "BlockingQueue.h"
#include "Service.h"

#pragma region variables
CRITICAL_SECTION criticalReceiver;
byte isRunning;
List receivers;
BlockingQueue requests;

static SOCKET server;
static CRITICAL_SECTION criticalSender;
static List senders;
#pragma endregion

#pragma region protos
extern void InitializeDatabase();
extern void InitializeDispatcher();
extern void InitializeBroadcaster();

static void initialize();
static void acceptClient();
static void cleanup();
#pragma endregion

int main() {
	SetActions(initialize, acceptClient, cleanup);
#ifdef _DEBUG 
	RunServiceDebug();
#else 
	RunServiceRelease();
#endif 
	return 0;
}

static void initialize() {
	const wchar_t* IP = L"127.0.0.1";
	const int PORT = 5558;

	WSADATA w;
	WSAStartup(MAKEWORD(2, 2), &w);
	SOCKADDR_IN address = { AF_INET, htons(PORT) };
	InetPton(AF_INET, IP, &address.sin_addr.s_addr);
	server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	bind(server, &address, sizeof(address));
	listen(server, SOMAXCONN);
	isRunning = 1;

	receivers.capacity = senders.capacity = 5;
	receivers.count = senders.count = 0;
	receivers.data = malloc(receivers.capacity * SENDER_SIZE);
	senders.data = malloc(senders.capacity * SENDER_SIZE);

	requests.count = 0;
	requests.capacity = 5;
	requests.data = malloc(requests.capacity * POINTER_SIZE);
	requests.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&requests.section);

	InitializeCriticalSection(&criticalSender);
	InitializeCriticalSection(&criticalReceiver);

	InitializeDatabase();
	InitializeDispatcher();
	InitializeBroadcaster();
}
static ulong enqueueRequest(void* p) {
	SOCKET client = p;
	byte isConnected = 1;
	char header[4];
	int packetSize, read, newRead;

	while (isConnected) {
		read = recv(client, header, 4, 0);
		if (read <= 0) {
			isConnected = 0;
			break;
		}
		while (read < 4) {
			newRead = recv(client, &header[read], 4 - read, 0);
			if (newRead <= 0) {
				isConnected = 0;
				break;
			}
			read += newRead;
		}
		memcpy(&packetSize, header, 4);
		Request* r = malloc(REQUEST_SIZE);
		r->sender = client;
		r->length = packetSize;
		r->packet = malloc(packetSize);
		read = newRead = 0;
		while (read < packetSize) {
			newRead = recv(client, r->packet, packetSize - read, 0);
			if (newRead <= 0) {
				isConnected = 0;
				break;
			}
			read += newRead;
		}
		memcpy(&r->userId, &r->packet[0], 4);
		memcpy(&r->function, &r->packet[4], 4);
		putInto(&requests, r);
	}
	EnterCriticalSection(&criticalSender);
	Sender** list = senders.data;
	Sender* s = 0;
	for (size_t i = 0; i < senders.count; i++) {
		if (list[i]->socket == client) {
			s = list[i];
			break;
		}
	}
	closesocket(client);
	CloseHandle(s->thread);
	removeFromList(&senders, s);
	free(s);
	LeaveCriticalSection(&criticalSender);
	return 0;
}
static void acceptClient() {
	while (isRunning) {
		SOCKADDR_IN from;
		int length = sizeof(from);
		SOCKET client = accept(server, &from, &length);
		//char ipv4[INET_ADDRSTRLEN];
		//inet_ntop(AF_INET, &(from.sin_addr), ipv4, INET_ADDRSTRLEN);
		BOOL b = TRUE;
		setsockopt(client, IPPROTO_TCP, TCP_NODELAY, &b, sizeof(BOOL));

		byte isReceiver;
		int read = recv(client, &isReceiver, 1, 0);
		if (isReceiver) {
			EnterCriticalSection(&criticalReceiver);
			addToList(&receivers, client);
			LeaveCriticalSection(&criticalReceiver);
		}
		else {
			EnterCriticalSection(&criticalSender);
			HANDLE requestThread = CreateThread(NULL, 0, enqueueRequest, client, 0, NULL);
			Sender* s = malloc(SENDER_SIZE);
			s->socket = client;
			s->thread = requestThread;
			addToList(&senders, s);
			LeaveCriticalSection(&criticalSender);
		}
	}
}
static void cleanup() {
	isRunning = 0;
	closesocket(server);
	WSACleanup();
}
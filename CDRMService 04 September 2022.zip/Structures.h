#pragma once
#include <WinSock2.h>
#include "Defined.h"
#include "List.h"

typedef struct {
	SOCKET socket;
	HANDLE thread;
} Sender;

typedef struct  {
	int site;
	int party;
	int head;
	int subHead;
	int unit;
	int noteType;
} Totals;

typedef struct {
    byte isTopLevel; // one packed byte for all these bytes?
    byte isCash;
    byte isSell;
    byte isConstruction;
    byte isReceipt;
    int amount;
    int siteId;
    int partyId;
    int headId;
    int subHeadId;
    int unitId;
    double quantity;
    char* date;
    char* narration;
} EntryInsert;

typedef struct {
    int id;
    char* name;
    char* address;
} Site;

typedef struct {
    int id;
    char* name;
    char* address;
    char* phone;
} Party;

typedef struct {
    int id;
    char* name;
} Head;

typedef struct {
    int id;
    char* name;
} Subhead;

typedef struct {
    int id;
    char* name;
} Unit;

typedef struct {
    int id;
    char* name;
} NoteType;

typedef struct {
    int id;
    char* date;
    char* type;
    char* site;
    char* entry;
} Note;
typedef struct {
    int id;
    int noteTypeId;
    int siteId;
    char* date;
    char* entry;
} NoteEntry;

typedef struct {
    char* start;
    char* from;
    char* to;
    char* end;
} ReportDates;

typedef struct {
    char* date;
    char* particulars;
    int receivablePayment;
    int payableReceipt;
} ReportEntry;

typedef struct {
    int partyId;
    int purchaseReceipt;
    int sellPayment;
    char* head;
} SumTransaction;

typedef struct {
    byte isSell;
    byte isConstruction;
    int purchase;
    int sell;
    double quantity;
    char* date;
    char* site;
    char* party;
    char* head;
    char* subHead;
    char* unit;
    char* narration;
} Due;

typedef struct {
    int payment;
    int receipt;
    byte isCash;
    char* date;
    char* party;
    char* head;
    char* narration;
    char* month;
} ReceiptPayment;

typedef struct {
    int id;
    byte isCash;
    byte isReceipt;
    char* date;
    char* amount;
    char* party;
    char* head;
    char* narration;
} ReceiptPaymentEntry;

typedef struct {
    int id;
    byte isSell;
    byte isConstruction;
    char* date;
    char* site;
    char* party;
    char* head;
    char* subHead;
    char* unit;
    char* amount;
    char* quantity;
    char* narration;
} PurchaseSellEntry;

typedef struct {
    char* key;
    int value;
} KeyValueSeries;

typedef struct {
    char* key;
    int value1;
    int value2;
    int value3;
} KeyTrippleValueSeries;

typedef enum {
    GetInitialData,
    GetPurchaseSellByDate,
    GetReceiptPaymentByDate,
    GetNotes,
    GetDues,
    GetDates,
    GetLedger,
    GetPurchaseSell,
    GetReceiptPayment,
    GetDetailPurchasePayable,
    GetAllHeadOrSitewisePurchase,
    GetSingleHeadOrSitewisePurchase,
    GetAllPartyTransactions,
    GetSinglePartyTransaction,
    GetPurchases,
    GetPayments,

    AddSite,
    AddParty,
    AddHead,
    AddSubHead,
    AddUnit,
    AddNoteType,
    AddNote,
    AddEntries,

    EditSite,
    EditParty,
    EditHead,
    EditSubHead,
    EditUnit,
    EditNoteType,
    EditNote,
    EditReceiptPayment,
    EditPurchaseSell,

    DeleteReceiptPayment,
    DeletePurchaseSell,
    DeleteNote
} Function;

typedef struct {
	SOCKET sender;
	int length;
	char* packet;
	int userId;
	Function function;
} Request;

typedef struct {
	SOCKET sender;
	Function function;
	int size;
	void* data;
	uint count;
} ResponsePersonal;

typedef struct {
	int size;
	Function function;
	int userId;
	void* data;
} ResponsePublic;

typedef struct {
	byte isSuccess;
	char text[50];
} ShortMessage;
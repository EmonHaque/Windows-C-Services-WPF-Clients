#include "Structures.h"
#include "Messenger.h"
#include "BlockingQueue.h"

#pragma region variables
extern byte isRunning;
extern BlockingQueue personalResponses;

static BlockingQueue garbagePersonalResponses;
static HANDLE dispatcherThread, freePersonalResponseThread;
#pragma endregion

static void sendShortMessage(ResponsePersonal* r) {
	ShortMessage* message = r->data;
	sendInt(r->sender, r->size);
	sendByte(r->sender, message->isSuccess);
	if(!message->isSuccess)
		sendString(r->sender, message->text);
	putInto(&garbagePersonalResponses, r);
}
static void sendIntOnSuccessTextOnFailure(ResponsePersonal* r) {
	ShortMessage* message = r->data;
	sendInt(r->sender, r->size);
	sendByte(r->sender, message->isSuccess);
	if (message->isSuccess) {
		int* value = message->text;
		sendInt(r->sender, *value);
	}
	else sendString(r->sender, message->text);
	putInto(&garbagePersonalResponses, r);
}
static void getPurchaseSellByDate(ResponsePersonal* r) {
	PurchaseSellEntry** list = r->data;
	sendInt(r->sender, r->size);
	for (uint i = 0; i < r->count; i++) {
		if (sendInt(r->sender, list[i]->id) < 0) break;
		sendByte(r->sender, list[i]->isSell);
		sendByte(r->sender, list[i]->isConstruction);
		sendString(r->sender, list[i]->date);
		sendString(r->sender, list[i]->site);
		sendString(r->sender, list[i]->party);
		sendString(r->sender, list[i]->head);
		sendString(r->sender, list[i]->subHead);
		sendString(r->sender, list[i]->unit);
		sendString(r->sender, list[i]->amount);
		sendString(r->sender, list[i]->quantity);
		sendString(r->sender, list[i]->narration);
	}
	putInto(&garbagePersonalResponses, r);
}
static void getReceiptPaymentByDate(ResponsePersonal* r) {
	ReceiptPaymentEntry** list = r->data;
	sendInt(r->sender, r->size);
	for (uint i = 0; i < r->count; i++) {
		if (sendInt(r->sender, list[i]->id) < 0) break;
		sendByte(r->sender, list[i]->isCash);
		sendByte(r->sender, list[i]->isReceipt);
		sendString(r->sender, list[i]->date);
		sendString(r->sender, list[i]->amount);
		sendString(r->sender, list[i]->party);
		sendString(r->sender, list[i]->head);
		sendString(r->sender, list[i]->narration);
	}
	putInto(&garbagePersonalResponses, r);
}
static void getDates(ResponsePersonal* r) {
	ReportDates* dates = r->data;
	sendInt(r->sender, r->size);
	sendString(r->sender, dates->from);
	sendString(r->sender, dates->start);
	sendString(r->sender, dates->to);
	sendString(r->sender, dates->end);
	putInto(&garbagePersonalResponses, r);
}
static void getNotes(ResponsePersonal* r) {
	Note** list = r->data;
	sendInt(r->sender, r->size);
	for (uint i = 0; i < r->count; i++) {
		if (sendInt(r->sender, list[i]->id) < 0) break;
		sendString(r->sender, list[i]->date);
		sendString(r->sender, list[i]->type);
		sendString(r->sender, list[i]->site);
		sendString(r->sender, list[i]->entry);
	}
	putInto(&garbagePersonalResponses, r);
}
static void getDues(ResponsePersonal* r) {
	SumTransaction** list = r->data;
	sendInt(r->sender, r->size);
	for (uint i = 0; i < r->count; i++) {
		if (sendInt(r->sender, list[i]->partyId) < 0) break;
		sendInt(r->sender, list[i]->purchaseReceipt);
		sendInt(r->sender, list[i]->sellPayment);
		sendString(r->sender, list[i]->head);
	}
	putInto(&garbagePersonalResponses, r);
}
static void getLedger(ResponsePersonal* r) {
	ReportEntry** list = r->data;
	sendInt(r->sender, r->size);
	for (uint i = 0; i < r->count; i++) {
		if (sendString(r->sender, list[i]->date) < 0) break;
		sendString(r->sender, list[i]->particulars);
		sendInt(r->sender, list[i]->receivablePayment);
		sendInt(r->sender, list[i]->payableReceipt);
	}
	putInto(&garbagePersonalResponses, r);
}
static void getPurchaseSell(ResponsePersonal* r) {
	Due** list = r->data;
	sendInt(r->sender, r->size);
	for (uint i = 0; i < r->count; i++) {
		if(sendByte(r->sender, list[i]->isSell) < 0) break;
		sendByte(r->sender, list[i]->isConstruction);
		sendInt(r->sender, list[i]->purchase);
		sendInt(r->sender, list[i]->sell);
		sendDouble(r->sender, list[i]->quantity);
		sendString(r->sender, list[i]->date);
		sendString(r->sender, list[i]->site);
		sendString(r->sender, list[i]->party);
		sendString(r->sender, list[i]->head);
		sendString(r->sender, list[i]->subHead);
		sendString(r->sender, list[i]->unit);
		sendString(r->sender, list[i]->narration);
	}
	putInto(&garbagePersonalResponses, r);
}
static void getReceiptPayment(ResponsePersonal* r) {
	ReceiptPayment** list = r->data;
	sendInt(r->sender, r->size);
	for (uint i = 0; i < r->count; i++) {
		if (sendInt(r->sender, list[i]->payment) < 0) break;
		sendInt(r->sender, list[i]->receipt);
		sendByte(r->sender, list[i]->isCash);
		sendString(r->sender, list[i]->date);
		sendString(r->sender, list[i]->party);
		sendString(r->sender, list[i]->head);
		sendString(r->sender, list[i]->narration);
		sendString(r->sender, list[i]->month);
	}
	putInto(&garbagePersonalResponses, r);
}
static void sendKeyValueSeries(ResponsePersonal* r) {
	KeyValueSeries** list = r->data;
	sendInt(r->sender, r->size);
	for (uint i = 0; i < r->count; i++) {
		if (sendString(r->sender, list[i]->key) < 0) break;
		sendInt(r->sender, list[i]->value);
	}
	putInto(&garbagePersonalResponses, r);
}
static void sendKeyTrippleValueSeries(ResponsePersonal* r) {
	KeyTrippleValueSeries** list = r->data;
	sendInt(r->sender, r->size);
	for (uint i = 0; i < r->count; i++) {
		if (sendString(r->sender, list[i]->key) < 0) break;
		sendInt(r->sender, list[i]->value1);
		sendInt(r->sender, list[i]->value2);
		sendInt(r->sender, list[i]->value3);
	}
	putInto(&garbagePersonalResponses, r);
}

static ulong DispatchPersonalResponse(void* p) {
	while (isRunning) {
		ResponsePersonal* r = takeOutFrom(&personalResponses);
		switch (r->function) {
			case AddSite: 
			case AddParty:
			case AddHead:
			case AddSubHead:
			case AddUnit:
			case AddNoteType: sendIntOnSuccessTextOnFailure(r); break;

			case AddNote:
			case AddEntries:
			case EditSite:
			case EditParty:
			case EditHead:
			case EditSubHead:
			case EditUnit:
			case EditNoteType: 
			case EditNote:
			case EditPurchaseSell:
			case EditReceiptPayment:
			case DeleteNote:
			case DeletePurchaseSell:
			case DeleteReceiptPayment: sendShortMessage(r); break;

			case GetPurchaseSellByDate: getPurchaseSellByDate(r); break;
			case GetReceiptPaymentByDate: getReceiptPaymentByDate(r); break;
			case GetDates: getDates(r); break;
			case GetNotes: getNotes(r); break;
			case GetDues: getDues(r); break;
			case GetLedger: getLedger(r); break;
			case GetPurchaseSell: getPurchaseSell(r); break;
			case GetReceiptPayment: getReceiptPayment(r); break;
			case GetPurchases:
			case GetPayments:
			case GetDetailPurchasePayable:
			case GetAllHeadOrSitewisePurchase: 
			case GetSingleHeadOrSitewisePurchase: sendKeyValueSeries(r); break;
			case GetAllPartyTransactions: 
			case GetSinglePartyTransaction: sendKeyTrippleValueSeries(r); break;
		}
	}
	return 0;
}
static ulong FreePersonalResponse(void* p) {
	while (isRunning) {
		ResponsePersonal* r = takeOutFrom(&garbagePersonalResponses);
		switch (r->function) {
			case GetPurchaseSellByDate: {
				PurchaseSellEntry** list = r->data;
				for (uint i = 0; i < r->count; i++) {
					free(list[i]->date);
					free(list[i]->amount);
					free(list[i]->site);
					free(list[i]->party);
					free(list[i]->head);
					free(list[i]->subHead);
					free(list[i]->quantity);
					free(list[i]->unit);
					free(list[i]->narration);
					free(list[i]);
				}
			} break;
			case GetReceiptPaymentByDate: {
				ReceiptPaymentEntry** list = r->data;
				for (uint i = 0; i < r->count; i++) {
					free(list[i]->date);
					free(list[i]->amount);
					free(list[i]->party);
					free(list[i]->head);
					free(list[i]->narration);
					free(list[i]);
				}
			} break;
			case GetDates: {
				ReportDates* dates = r->data;
				free(dates->from);
				free(dates->start);
				free(dates->to);
				free(dates->end);
			} break;
			case GetNotes: {
				Note** list = r->data;
				for (uint i = 0; i < r->count; i++) {
					free(list[i]->date);
					free(list[i]->type);
					free(list[i]->site);
					free(list[i]->entry);
					free(list[i]);
				}
			} break;
			case GetDues: {
				SumTransaction** list = r->data;
				for (uint i = 0; i < r->count; i++) {
					free(list[i]->head);
					free(list[i]);
				}
			} break;
			case GetLedger: {
				ReportEntry** list = r->data;
				for (uint i = 0; i < r->count; i++) {
					free(list[i]->date);
					free(list[i]->particulars);
					free(list[i]);
				}
			} break;
			case GetPurchaseSell: {
				Due** list = r->data;
				for (uint i = 0; i < r->count; i++) {
					free(list[i]->date);
					free(list[i]->site);
					free(list[i]->party);
					free(list[i]->head);
					free(list[i]->subHead);
					free(list[i]->unit);
					free(list[i]->narration);
					free(list[i]);
				}
			} break;
			case GetReceiptPayment: {
				ReceiptPayment** list = r->data;
				for (uint i = 0; i < r->count; i++) {
					free(list[i]->date);
					free(list[i]->party);
					free(list[i]->head);
					free(list[i]->narration);
					free(list[i]->month);
					free(list[i]);
				}
			} break;
			case GetPurchases:
			case GetPayments:
			case GetDetailPurchasePayable:
			case GetAllHeadOrSitewisePurchase:
			case GetSingleHeadOrSitewisePurchase: {
				KeyValueSeries** list = r->data;
				for (uint i = 0; i < r->count; i++) {
					free(list[i]->key);
					free(list[i]);
				}
			} break;
			case GetAllPartyTransactions:
			case GetSinglePartyTransaction: {
				KeyTrippleValueSeries** list = r->data;
				for (uint i = 0; i < r->count; i++) {
					free(list[i]->key);
					free(list[i]);
				}
			} break;
		}
		free(r->data);
		free(r);
	}
	return 0;
}

void InitializeDispatcher() {
	garbagePersonalResponses.count = 0;
	garbagePersonalResponses.capacity = 10;
	garbagePersonalResponses.data = malloc(garbagePersonalResponses.capacity * POINTER_SIZE);
	garbagePersonalResponses.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&garbagePersonalResponses.section);

	dispatcherThread = CreateThread(NULL, 0, DispatchPersonalResponse, NULL, 0, NULL);
	freePersonalResponseThread = CreateThread(NULL, 0, FreePersonalResponse, NULL, 0, NULL);
}
#include <time.h>
#include <stdio.h>
#include "List.h"
#include "BlockingQueue.h"
#include "Messenger.h"
#include "Structures.h"
#include "sqlite3.h"

#pragma region variables
extern byte isRunning;
extern BlockingQueue requests;

BlockingQueue personalResponses, publicResponses;

static sqlite3* connection;
static sqlite3_stmt* command;
static Totals total;
static List sites, parties, heads, subHeads, units, noteTypes;
static BlockingQueue garbageRequests;
static HANDLE requestProcessThread, freeRequestThread;
#pragma endregion

// addHead, addSubHead, addUnit, addNoteType are identical macro or some other method
// editHead, editSubHead, editUnit, editNoteType are identical macro or some other method
// deleteReceiptPayment and deletePurchaseSell are identical take one more arg to change the query

static void initializeList() {
	int size = 50;
	int initialSize = size * POINTER_SIZE;

	sites.capacity =
		parties.capacity =
		heads.capacity =
		subHeads.capacity =
		units.capacity =
		noteTypes.capacity = size;

	sites.count =
		parties.count =
		heads.count =
		subHeads.count =
		units.count =
		noteTypes.count = 0;

	sites.data = malloc(initialSize);
	parties.data = malloc(initialSize);
	heads.data = malloc(initialSize);
	subHeads.data = malloc(initialSize);
	units.data = malloc(initialSize);
	noteTypes.data = malloc(initialSize);
}
static void initializeQueue() {
	personalResponses.count = 0;
	personalResponses.capacity = 10;
	personalResponses.data = malloc(personalResponses.capacity * POINTER_SIZE);
	personalResponses.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&personalResponses.section);

	publicResponses.count = 0;
	publicResponses.capacity = 10;
	publicResponses.data = malloc(publicResponses.capacity * POINTER_SIZE);
	publicResponses.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&publicResponses.section);
}
static void addShortPersonalResponse(Request* r, ShortMessage* s, int size) {
	ResponsePersonal* response = malloc(RESPONSE_PERSONAL_SIZE);
	response->sender = r->sender;
	response->function = r->function;
	response->data = s;
	response->size = 1 + size;
	putInto(&personalResponses, response);
}
static void addLongPersonalResponse(Request* r, List l, int size) {
	ResponsePersonal* response = malloc(RESPONSE_PERSONAL_SIZE);
	response->sender = r->sender;
	response->function = r->function;
	response->size = size;
	response->data = l.data;
	response->count = l.count;
	putInto(&personalResponses, response);
}
static void addPublicResponse(Request* r, void* d, int size) {
	ResponsePublic* pr = malloc(RESPONSE_PUBLIC_SIZE);
	pr->function = r->function;
	pr->userId = r->userId;
	pr->data = d;
	pr->size = size;
	putInto(&publicResponses, pr);
}
static int mallocate(char* src, char** dst) {
	int length = strlen(src);
	int extendedLength = length + 1;
	*dst = malloc(extendedLength);
	memcpy_s(*dst, length, src, length);
	(*dst)[length] = 0;
	return extendedLength;
}
static void sendStartupPackets(SOCKET s) {
	sendInt(s, total.site);
	Site** si = sites.data;
	for (uint i = 0; i < sites.count; i++) {
		sendInt(s, si[i]->id);
		sendString(s, si[i]->name);
		sendString(s, si[i]->address);
	}
	sendInt(s, total.party);
	Party** pa = parties.data;
	for (uint i = 0; i < parties.count; i++) {
		sendInt(s, pa[i]->id);
		sendString(s, pa[i]->name);
		sendString(s, pa[i]->address);
		sendString(s, pa[i]->phone);
	}
	sendInt(s, total.head);
	Head** he = heads.data;
	for (uint i = 0; i < heads.count; i++) {
		sendInt(s, he[i]->id);
		sendString(s, he[i]->name);
	}
	sendInt(s, total.subHead);
	Subhead** sh = subHeads.data;
	for (uint i = 0; i < subHeads.count; i++) {
		sendInt(s, sh[i]->id);
		sendString(s, sh[i]->name);
	}
	sendInt(s, total.unit);
	Unit** un = units.data;
	for (uint i = 0; i < units.count; i++) {
		sendInt(s, un[i]->id);
		sendString(s, un[i]->name);
	}
	sendInt(s, total.noteType);
	NoteType** nt = noteTypes.data;
	for (uint i = 0; i < noteTypes.count; i++) {
		sendInt(s, nt[i]->id);
		sendString(s, nt[i]->name);
	}
}

static void addSite(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	char* cursor, * name, * address;
	name = strtok_s(&r->packet[12], "", &cursor), cursor++;
	address = cursor;

	Site** si = sites.data;
	for (uint i = 0; i < sites.count; i++) {
		if (_stricmp(name, si[i]->name) == 0) {
			memcpy_s(message->text, 4, &si[i]->id, 4);
			size = 4;
			isSuccess = 0;
			break;
		}
	}
	if (isSuccess) {
		char* sql = "INSERT INTO Sites(Name, Address) VALUES(?, ?)";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 2, address, -1, SQLITE_STATIC);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to insert Site");
		}
		else {
			Site* newSite = malloc(sizeof(Site));
			newSite->id = sites.count == 0 ? 1 : si[sites.count - 1]->id + 1;
			mallocate(name, &newSite->name);
			mallocate(address, &newSite->address);

			total.site += r->length - 8;
			addToList(&sites, newSite);
			addPublicResponse(r, newSite, r->length);

			memcpy_s(message->text, 4, &newSite->id, 4);
			size = 4;
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addParty(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	char* cursor, * name, * address, * phone;
	name = strtok_s(&r->packet[12], "", &cursor), cursor++;
	address = strtok_s(0, "", &cursor), cursor++;
	phone = cursor;

	Party** pa = parties.data;
	for (uint i = 0; i < parties.count; i++) {
		if (_stricmp(name, pa[i]->name) == 0) {
			memcpy_s(message->text, 4, &pa[i]->id, 4);
			size = 4;
			isSuccess = 0;
			break;
		}
	}
	if (isSuccess) {
		char* sql = "INSERT INTO Parties(Name, Address, Phone) VALUES(?, ?, ?)";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 2, address, -1, SQLITE_STATIC);
		if (strlen(phone) > 0) sqlite3_bind_text(command, 3, phone, -1, SQLITE_STATIC);
		else sqlite3_bind_null(command, 3);

		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to insert Party");
		}
		else {
			Party* newParty = malloc(sizeof(Party));
			newParty->id = parties.count == 0 ? 1 : pa[parties.count - 1]->id + 1;
			mallocate(name, &newParty->name);
			mallocate(address, &newParty->address);
			mallocate(phone, &newParty->phone);

			total.party += r->length - 8;
			addToList(&parties, newParty);
			addPublicResponse(r, newParty, r->length);

			memcpy_s(message->text, 4, &newParty->id, 4);
			size = 4;
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addHead(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	char* name = &r->packet[12];
	Head** he = heads.data;
	for (uint i = 0; i < heads.count; i++) {
		if (_stricmp(name, he[i]->name) == 0) {
			memcpy_s(message->text, 4, &he[i]->id, 4);
			size = 4;
			isSuccess = 0;
			break;
		}
	}
	if (isSuccess) {
		char* sql = "INSERT INTO Heads(Name) VALUES(?)";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to insert Head");
		}
		else {
			Head* newHead = malloc(sizeof(Head));
			newHead->id = heads.count == 0 ? 1 : he[heads.count - 1]->id + 1;
			mallocate(name, &newHead->name);

			total.head += r->length - 8;
			addToList(&heads, newHead);
			addPublicResponse(r, newHead, r->length);

			memcpy_s(message->text, 4, &newHead->id, 4);
			size = 4;
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addSubHead(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	char* name = &r->packet[12];
	Subhead** sh = subHeads.data;
	for (uint i = 0; i < subHeads.count; i++) {
		if (_stricmp(name, sh[i]->name) == 0) {
			memcpy_s(message->text, 4, &sh[i]->id, 4);
			size = 4;
			isSuccess = 0;
			break;
		}
	}
	if (isSuccess) {
		char* sql = "INSERT INTO SubHeads(Name) VALUES(?)";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to insert Subhead");
		}
		else {
			Subhead* newSubhead = malloc(sizeof(Subhead));
			newSubhead->id = subHeads.count == 0 ? 1 : sh[subHeads.count - 1]->id + 1;
			mallocate(name, &newSubhead->name);

			total.subHead += r->length - 8;
			addToList(&subHeads, newSubhead);
			addPublicResponse(r, newSubhead, r->length);

			memcpy_s(message->text, 4, &newSubhead->id, 4);
			size = 4;
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addUnit(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	char* name = &r->packet[12];
	Unit** un = units.data;
	for (uint i = 0; i < units.count; i++) {
		if (_stricmp(name, un[i]->name) == 0) {
			memcpy_s(message->text, 4, &un[i]->id, 4);
			size = 4;
			isSuccess = 0;
			break;
		}
	}
	if (isSuccess) {
		char* sql = "INSERT INTO Units(Name) VALUES(?)";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to insert Unit");
		}
		else {
			Unit* newUnit = malloc(sizeof(Unit));
			newUnit->id = units.count == 0 ? 1 : un[units.count - 1]->id + 1;
			mallocate(name, &newUnit->name);

			total.unit += r->length - 8;
			addToList(&subHeads, newUnit);
			addPublicResponse(r, newUnit, r->length);

			memcpy_s(message->text, 4, &newUnit->id, 4);
			size = 4;
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addNoteType(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	char* name = &r->packet[12];
	NoteType** nt = noteTypes.data;
	for (uint i = 0; i < noteTypes.count; i++) {
		if (_stricmp(name, nt[i]->name) == 0) {
			memcpy_s(message->text, 4, &nt[i]->id, 4);
			size = 4;
			isSuccess = 0;
			break;
		}
	}
	if (isSuccess) {
		char* sql = "INSERT INTO NoteTypes(Name) VALUES(?)";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to insert NoteType");
		}
		else {
			NoteType* newType = malloc(sizeof(NoteType));
			newType->id = noteTypes.count == 0 ? 1 : nt[noteTypes.count - 1]->id + 1;
			mallocate(name, &newType->name);

			total.noteType += r->length - 8;
			addToList(&noteTypes, newType);
			addPublicResponse(r, newType, r->length);

			memcpy_s(message->text, 4, &newType->id, 4);
			size = 4;
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addNote(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	int siteId, noteTypeId;
	char* cursor, * date, * entry, * sql;
	memcpy_s(&siteId, 4, &r->packet[12], 4);
	memcpy_s(&noteTypeId, 4, &r->packet[16], 4);
	date = strtok_s(&r->packet[20], "", &cursor), cursor++;
	entry = cursor;

	sql = "INSERT INTO Notes(SiteId, NoteTypeId, Date, Entry) VALUES(?, ?, ?, ?)";
	sqlite3_prepare(connection, sql, -1, &command, 0);
	sqlite3_bind_int(command, 1, siteId);
	sqlite3_bind_int(command, 2, noteTypeId);
	sqlite3_bind_text(command, 3, date, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 4, entry, -1, SQLITE_STATIC);
	int result = sqlite3_step(command);
	sqlite3_finalize(command);
	if (result != SQLITE_DONE) {
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Failed to insert Note");
	}
	else {
		int id = sqlite3_last_insert_rowid(connection);
		int broadcastSize = 8 + 12;
		NoteEntry* newNote = malloc(sizeof(NoteEntry));
		newNote->id = id;
		newNote->noteTypeId = noteTypeId;
		newNote->siteId = siteId;
		broadcastSize += mallocate(date, &newNote->date);
		broadcastSize += mallocate(entry, &newNote->entry);

		addPublicResponse(r, newNote, broadcastSize);
	}
	addShortPersonalResponse(r, message, size);
}
static void addEntries(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	int size = 0;

	char* cursor = &r->packet[8];
	char* end = r->packet + r->length;	
	char* sql;
	int	result = SQLITE_DONE;
	sqlite3_exec(connection, "BEGIN", NULL, NULL, NULL);
	do {
		EntryInsert e;
		memcpy_s(&e.isTopLevel, 1, cursor, 1), cursor++;
		memcpy_s(&e.isCash, 1, cursor, 1), cursor++;
		memcpy_s(&e.isSell, 1, cursor, 1), cursor++;
		memcpy_s(&e.isConstruction, 1, cursor, 1), cursor++;
		memcpy_s(&e.isReceipt, 1, cursor, 1), cursor++;
		memcpy_s(&e.amount, 4, cursor, 4), cursor += 4;
		memcpy_s(&e.siteId, 4, cursor, 4), cursor += 4;
		memcpy_s(&e.partyId, 4, cursor, 4), cursor += 4;
		memcpy_s(&e.headId, 4, cursor, 4), cursor += 4;
		memcpy_s(&e.subHeadId, 4, cursor, 4), cursor += 4;
		memcpy_s(&e.unitId, 4, cursor, 4), cursor += 4;
		memcpy_s(&e.quantity, 8, cursor, 8), cursor += 8;

		char* token;
		e.date = strtok_s(cursor, "", &token), token++;
		e.narration = strtok_s(0, "", &token), token++;
		cursor = token;

		if (e.isTopLevel) {
			sql = "INSERT INTO Dues(Date, Amount, IsSell, IsConstruction, SiteId, PartyId, HeadId, SubHeadId, UnitId, Quantity, Narration) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			sqlite3_prepare(connection, sql, -1, &command, 0);
			sqlite3_bind_text(command, 1, e.date, -1, SQLITE_STATIC);
			sqlite3_bind_int(command, 2, e.amount);
			sqlite3_bind_int(command, 3, e.isSell);
			sqlite3_bind_int(command, 4, e.isConstruction);
			sqlite3_bind_int(command, 5, e.siteId);
			sqlite3_bind_int(command, 6, e.partyId);
			sqlite3_bind_int(command, 7, e.headId);
			if (e.subHeadId > 0) sqlite3_bind_int(command, 8, e.subHeadId);
			else sqlite3_bind_null(command, 8);
			if (e.unitId > 0) sqlite3_bind_int(command, 9, e.unitId);
			else sqlite3_bind_null(command, 9);
			if (e.quantity > 0) sqlite3_bind_double(command, 10, e.quantity);
			else sqlite3_bind_null(command, 10);
			if(e.narration) sqlite3_bind_text(command, 11, e.narration, -1, SQLITE_STATIC);
			else sqlite3_bind_null(command, 11);
		}
		else {
			sql = "INSERT INTO ReceiptPayments(Date, Amount, PartyId, HeadId, IsReceipt, IsCash, Narration) VALUES(?, ?, ?, ?, ?, ?, ?)";
			sqlite3_prepare(connection, sql, -1, &command, 0);
			sqlite3_bind_text(command, 1, e.date, -1, SQLITE_STATIC);
			sqlite3_bind_int(command, 2, e.amount);
			sqlite3_bind_int(command, 3, e.partyId);
			sqlite3_bind_int(command, 4, e.headId);
			sqlite3_bind_int(command, 5, e.isReceipt);
			sqlite3_bind_int(command, 6, e.isCash);
			if (e.narration) sqlite3_bind_text(command, 7, e.narration, -1, SQLITE_STATIC);
			else sqlite3_bind_null(command, 7);
		}
		result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			sqlite3_exec(connection, "ROLLBACK", NULL, NULL, NULL);
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Error inserting entry");
			break;
		}
		
	} while (cursor < end);

	if (result == SQLITE_DONE) sqlite3_exec(connection, "COMMIT", NULL, NULL, NULL);
	addShortPersonalResponse(r, message, size);
}

static void editSite(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isNotEqual = 1;
	int size = 0;

	int id;
	char* cursor, * name, * address;
	memcpy_s(&id, 4, &r->packet[8], 4);
	name = strtok_s(&r->packet[12], "", &cursor), cursor++;
	address = cursor;

	Site** si = sites.data;
	Site* original = { 0 };
	for (uint i = 0; i < sites.count; i++) {
		if (si[i]->id != id) continue;
		if (_stricmp(si[i]->name, name) == 0
			&& _stricmp(si[i]->address, address) == 0) {
			isNotEqual = 0;
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Site exists");
		}
		else original = si[i];
		break;
	}
	if (isNotEqual) {
		char* sql = "UPDATE Sites SET Name = ?, Address = ? WHERE Id = ?";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 2, address, -1, SQLITE_STATIC);
		sqlite3_bind_int(command, 3, original->id);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to update Site");
		}
		else {
			total.site -= (
				2
				+ strlen(original->name)
				+ strlen(original->address)
				);
			free(original->name);
			free(original->address);

			total.site += mallocate(name, &original->name);
			total.site += mallocate(address, &original->address);
			addPublicResponse(r, original, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void editParty(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isNotEqual = 1;
	int size = 0;

	int id;
	char* cursor, * name, * address, * phone;
	memcpy_s(&id, 4, &r->packet[8], 4);
	name = strtok_s(&r->packet[12], "", &cursor), cursor++;
	address = strtok_s(0, "", &cursor), cursor++;
	phone = cursor;

	Party** pa = parties.data;
	Party* original = { 0 };
	for (uint i = 0; i < parties.count; i++) {
		if (pa[i]->id != id) continue;
		if (_stricmp(pa[i]->name, name) == 0
			&& _stricmp(pa[i]->address, address) == 0
			&& _stricmp(pa[i]->phone, phone) == 0) {
			isNotEqual = 0;
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Party exists");
		}
		else original = pa[i];
		break;
	}
	if (isNotEqual) {
		char* sql = "UPDATE Parties SET Name = ?, Address = ?, Phone = ? WHERE Id = ?";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 2, address, -1, SQLITE_STATIC);
		if (strlen(phone) > 0) sqlite3_bind_text(command, 3, phone, -1, SQLITE_STATIC);
		else sqlite3_bind_null(command, 3);
		sqlite3_bind_int(command, 4, original->id);

		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to update Party");
		}
		else {
			total.party -= (
				3
				+ strlen(original->name)
				+ strlen(original->address)
				+ strlen(original->phone)
				);
			free(original->name);
			free(original->address);
			free(original->phone);

			total.party += mallocate(name, &original->name);
			total.party += mallocate(address, &original->address);
			total.party += mallocate(phone, &original->phone);
			addPublicResponse(r, original, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void editHead(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isNotEqual = 1;
	int size = 0;

	int id;
	memcpy_s(&id, 4, &r->packet[8], 4);
	char* name = &r->packet[12];

	Head** he = heads.data;
	Head* original = { 0 };
	for (uint i = 0; i < heads.count; i++) {
		if (he[i]->id != id) continue;
		if (_stricmp(he[i]->name, name) == 0) {
			isNotEqual = 0;
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Head exists");
		}
		else original = he[i];
		break;
	}
	if (isNotEqual) {
		char* sql = "UPDATE Heads SET Name = ? WHERE Id = ?";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_int(command, 2, original->id);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to update Head");
		}
		else {
			total.head -= (1 + strlen(original->name));
			free(original->name);
			total.head += mallocate(name, &original->name);
			addPublicResponse(r, original, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void editSubHead(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isNotEqual = 1;
	int size = 0;

	int id;
	memcpy_s(&id, 4, &r->packet[8], 4);
	char* name = &r->packet[12];

	Subhead** sh = subHeads.data;
	Subhead* original = { 0 };
	for (uint i = 0; i < subHeads.count; i++) {
		if (sh[i]->id != id) continue;
		if (_stricmp(sh[i]->name, name) == 0) {
			isNotEqual = 0;
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Subhead exists");
		}
		else original = sh[i];
		break;
	}
	if (isNotEqual) {
		char* sql = "UPDATE SubHeads SET Name = ? WHERE Id = ?";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_int(command, 2, original->id);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to update Subhead");
		}
		else {
			total.subHead -= (1 + strlen(original->name));
			free(original->name);
			total.subHead += mallocate(name, &original->name);
			addPublicResponse(r, original, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void editUnit(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isNotEqual = 1;
	int size = 0;

	int id;
	memcpy_s(&id, 4, &r->packet[8], 4);
	char* name = &r->packet[12];

	Unit** un = units.data;
	Unit* original = { 0 };
	for (uint i = 0; i < units.count; i++) {
		if (un[i]->id != id) continue;
		if (_stricmp(un[i]->name, name) == 0) {
			isNotEqual = 0;
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Unit exists");
		}
		else original = un[i];
		break;
	}
	if (isNotEqual) {
		char* sql = "UPDATE Units SET Name = ? WHERE Id = ?";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_int(command, 2, original->id);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to update Unit");
		}
		else {
			total.unit -= (1 + strlen(original->name));
			free(original->name);
			total.unit += mallocate(name, &original->name);
			addPublicResponse(r, original, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void editNoteType(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isNotEqual = 1;
	int size = 0;

	int id;
	memcpy_s(&id, 4, &r->packet[8], 4);
	char* name = &r->packet[12];

	NoteType** nt = noteTypes.data;
	NoteType* original = { 0 };
	for (uint i = 0; i < noteTypes.count; i++) {
		if (nt[i]->id != id) continue;
		if (_stricmp(nt[i]->name, name) == 0) {
			isNotEqual = 0;
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Unit NoteType");
		}
		else original = nt[i];
		break;
	}
	if (isNotEqual) {
		char* sql = "UPDATE NoteTypes SET Name = ? WHERE Id = ?";
		sqlite3_prepare(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_int(command, 2, original->id);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to update NoteType");
		}
		else {
			total.noteType -= (1 + strlen(original->name));
			free(original->name);
			total.noteType += mallocate(name, &original->name);
			addPublicResponse(r, original, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void editNote(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	int id, siteId, noteTypeId;
	char* cursor, * date, * entry, * sql;
	memcpy_s(&id, 4, &r->packet[8], 4);
	memcpy_s(&siteId, 4, &r->packet[12], 4);
	memcpy_s(&noteTypeId, 4, &r->packet[16], 4);
	date = strtok_s(&r->packet[20], "", &cursor), cursor++;
	entry = cursor;

	sql = "UPDATE Notes SET SiteId = ?, NoteTypeId = ?, Date = ?, Entry = ? WHERE Id = ?";
	sqlite3_prepare(connection, sql, -1, &command, 0);
	sqlite3_bind_int(command, 1, siteId);
	sqlite3_bind_int(command, 2, noteTypeId);
	sqlite3_bind_text(command, 3, date, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 4, entry, -1, SQLITE_STATIC);
	sqlite3_bind_int(command, 5, id);
	int result = sqlite3_step(command);
	sqlite3_finalize(command);
	if (result != SQLITE_DONE) {
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Failed to update Note");
	}
	else {
		int broadcastSize = 8 + 12;
		NoteEntry* edited = malloc(sizeof(NoteEntry));
		edited->id = id;
		edited->noteTypeId = noteTypeId;
		edited->siteId = siteId;
		broadcastSize += mallocate(date, &edited->date);
		broadcastSize += mallocate(entry, &edited->entry);

		addPublicResponse(r, edited, broadcastSize);
	}
	addShortPersonalResponse(r, message, size);
}
static void editReceiptPayment(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	byte isReceipt, isCash;
	int id, partyId, headId, amount;
	char* cursor, * date, * narration, * sql;
	memcpy_s(&isReceipt, 1, &r->packet[8], 1);
	memcpy_s(&isCash, 1, &r->packet[9], 1);
	memcpy_s(&id, 4, &r->packet[10], 4);
	memcpy_s(&partyId, 4, &r->packet[14], 4);
	memcpy_s(&headId, 4, &r->packet[18], 4);
	memcpy_s(&amount, 4, &r->packet[22], 4);

	date = strtok_s(&r->packet[26], "", &cursor), cursor++;
	narration = cursor;

	sql = "UPDATE ReceiptPayments SET Date = ?, Amount = ?, PartyId = ?, HeadId = ?, IsReceipt = ?, IsCash = ?, Narration = ? WHERE Id = ?";
	sqlite3_prepare(connection, sql, -1, &command, 0);
	sqlite3_bind_text(command, 1, date, -1, SQLITE_STATIC);
	sqlite3_bind_int(command, 2, amount);
	sqlite3_bind_int(command, 3, partyId);
	sqlite3_bind_int(command, 4, headId);
	sqlite3_bind_int(command, 5, isReceipt);
	sqlite3_bind_int(command, 6, isCash);
	if (strlen(narration) > 0) sqlite3_bind_text(command, 7, narration, -1, SQLITE_STATIC);
	else sqlite3_bind_null(command, 7);
	sqlite3_bind_int(command, 8, id);
	int result = sqlite3_step(command);
	sqlite3_finalize(command);
	if (result != SQLITE_DONE) {
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Failed to update entry");
	}
	else {
		// broadcast
	}
	addShortPersonalResponse(r, message, size);
}
static void editPurchaseSell(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	byte isSell, isConstruction;
	int id, siteId, partyId, headId, subHeadId, unitId, amount;
	double quantity;
	char* cursor, * date, * narration, * sql;

	memcpy_s(&isSell, 1, &r->packet[8], 1);
	memcpy_s(&isConstruction, 1, &r->packet[9], 1);
	memcpy_s(&id, 4, &r->packet[10], 4);
	memcpy_s(&siteId, 4, &r->packet[14], 4);
	memcpy_s(&partyId, 4, &r->packet[18], 4);
	memcpy_s(&headId, 4, &r->packet[22], 4);
	memcpy_s(&subHeadId, 4, &r->packet[26], 4);
	memcpy_s(&unitId, 4, &r->packet[30], 4);
	memcpy_s(&amount, 4, &r->packet[34], 4);
	memcpy_s(&quantity, 8, &r->packet[38], 8);

	date = strtok_s(&r->packet[46], "", &cursor), cursor++;
	narration = cursor;

	sql = "UPDATE Dues SET Date=?, Amount=?, IsSell=?, IsConstruction=?, SiteId=?, PartyId=?, HeadId=?, SubHeadId=?, UnitId=?, Quantity=?, Narration=? WHERE Id=?";
	sqlite3_prepare(connection, sql, -1, &command, 0);
	sqlite3_bind_text(command, 1, date, -1, SQLITE_STATIC);
	sqlite3_bind_int(command, 2, amount);
	sqlite3_bind_int(command, 3, isSell);
	sqlite3_bind_int(command, 4, isConstruction);
	sqlite3_bind_int(command, 5, siteId);
	sqlite3_bind_int(command, 6, partyId);
	sqlite3_bind_int(command, 7, headId);
	if (subHeadId > 0) sqlite3_bind_int(command, 8, subHeadId);
	else sqlite3_bind_null(command, 8);
	if (unitId > 0) sqlite3_bind_int(command, 9, unitId);
	else sqlite3_bind_null(command, 9);
	if (quantity > 0) sqlite3_bind_double(command, 10, quantity);
	else sqlite3_bind_null(command, 10);
	if(strlen(narration) > 0) sqlite3_bind_text(command, 11, narration, -1, SQLITE_STATIC);
	else sqlite3_bind_null(command, 11);
	sqlite3_bind_int(command, 12, id);
	int result = sqlite3_step(command);
	sqlite3_finalize(command);
	if (result != SQLITE_DONE) {
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Failed to update entry");
	}
	else {
		// broadcast
	}
	addShortPersonalResponse(r, message, size);
}

static void deleteNote(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	byte isSuccess = 1;
	int size = 0;

	int id;
	memcpy_s(&id, 4, &r->packet[8], 4);
	char *sql = "DELETE FROM Notes WHERE Id = ?";
	sqlite3_prepare(connection, sql, -1, &command, 0);
	sqlite3_bind_int(command, 1, id);
	int result = sqlite3_step(command);
	sqlite3_finalize(command);
	if (result != SQLITE_DONE) {
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Failed to delete Note");
	}
	else {
		int* idp = malloc(sizeof(int));
		*idp = id;
		addPublicResponse(r, idp, r->length);
	}
	addShortPersonalResponse(r, message, size);
}
static void deleteReceiptPayment(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int id, size = 0;
	memcpy_s(&id, 4, &r->packet[8], 4);
	char* sql = "DELETE From ReceiptPayments WHERE Id = ?";
	sqlite3_prepare(connection, sql, -1, &command, 0);
	sqlite3_bind_int(command, 1, id);
	int result = sqlite3_step(command);
	sqlite3_finalize(command);
	if (result != SQLITE_DONE) {
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Failed to delete entry");
	}
	else {
		int* idp = malloc(sizeof(int));
		*idp = id;
		addPublicResponse(r, idp, r->length);
	}
	addShortPersonalResponse(r, message, size);
}
static void deletePurchaseSell(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int id, size = 0;
	memcpy_s(&id, 4, &r->packet[8], 4);
	char* sql = "DELETE From Dues WHERE Id = ?";
	sqlite3_prepare(connection, sql, -1, &command, 0);
	sqlite3_bind_int(command, 1, id);
	int result = sqlite3_step(command);
	sqlite3_finalize(command);
	if (result != SQLITE_DONE) {
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Failed to delete entry");
	}
	else {
		int* idp = malloc(sizeof(int));
		*idp = id;
		addPublicResponse(r, idp, r->length);
	}
	addShortPersonalResponse(r, message, size);
}

static void getPurchaseSellByDate(Request* r) {
	char* date = &r->packet[8];
	char* sql =
		"SELECT Date, cast(Amount as text), IsSell, IsConstruction, si.Name, pa.Name, he.Name, "
		"coalesce(sh.Name, ''), coalesce(Quantity, ''), coalesce(un.Name, ''), coalesce(Narration, ''), d.Id FROM Dues d "
		"LEFT JOIN Sites si ON si.Id = d.SiteId "
		"LEFT JOIN Parties pa ON pa.Id = d.PartyId "
		"LEFT JOIN Heads he ON he.Id = d.HeadId "
		"LEFT JOIN SubHeads sh ON sh.Id = d.SubHeadId "
		"LEFT JOIN Units un ON un.Id = d.UnitId "
		"WHERE Date = ?";
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_text(command, 1, date, -1, SQLITE_STATIC);
	int size = 0;
	List list = { 0,10,malloc(10 * sizeof(PurchaseSellEntry)) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		PurchaseSellEntry* pse = malloc(sizeof(PurchaseSellEntry));
		pse->isSell = (byte)sqlite3_column_int(command, 2);
		pse->isConstruction = (byte)sqlite3_column_int(command, 3);
		pse->id = sqlite3_column_int(command, 11);
		size += (
			6
			+ mallocate(sqlite3_column_text(command, 0), &pse->date)
			+ mallocate(sqlite3_column_text(command, 1), &pse->amount)
			+ mallocate(sqlite3_column_text(command, 4), &pse->site)
			+ mallocate(sqlite3_column_text(command, 5), &pse->party)
			+ mallocate(sqlite3_column_text(command, 6), &pse->head)
			+ mallocate(sqlite3_column_text(command, 7), &pse->subHead)
			+ mallocate(sqlite3_column_text(command, 8), &pse->quantity)
			+ mallocate(sqlite3_column_text(command, 9), &pse->unit)
			+ mallocate(sqlite3_column_text(command, 10), &pse->narration)
			);
		addToList(&list, pse);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getReceiptPaymentByDate(Request* r) {
	char* date = &r->packet[8];
	char* sql =
		"SELECT Date, cast(Amount as text), pa.Name, he.Name, IsReceipt, IsCash, coalesce(Narration, ''), d.Id FROM ReceiptPayments d "
		"LEFT JOIN Parties pa ON pa.Id = d.PartyId "
		"LEFT JOIN Heads he ON he.Id = d.HeadId "
		"WHERE Date = ?";
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_text(command, 1, date, -1, SQLITE_STATIC);
	int size = 0;
	List list = { 0,10,malloc(10 * sizeof(ReceiptPaymentEntry)) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		ReceiptPaymentEntry* rpe = malloc(sizeof(ReceiptPaymentEntry));

		rpe->isReceipt = (byte)sqlite3_column_int(command, 4);
		rpe->isCash = (byte)sqlite3_column_int(command, 5);
		rpe->id = sqlite3_column_int(command, 7);
		size += (
			6
			+ mallocate(sqlite3_column_text(command, 0), &rpe->date)
			+ mallocate(sqlite3_column_text(command, 1), &rpe->amount)
			+ mallocate(sqlite3_column_text(command, 2), &rpe->party)
			+ mallocate(sqlite3_column_text(command, 3), &rpe->head)
			+ mallocate(sqlite3_column_text(command, 6), &rpe->narration)
			);
		addToList(&list, rpe);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getDates(Request* r) {
	ReportDates* dates = malloc(REPORT_DATE_SIZE);

	time_t now = time(0);
	struct tm tmStruct;
	localtime_s(&tmStruct, &now);

	int yearNum = tmStruct.tm_year + 1900 - 1;
	char date[11], year[5], month[3], day[3];
	sprintf_s(year, sizeof(year), "%d", yearNum);
	if (tmStruct.tm_mon < 10) sprintf_s(month, sizeof(month), "0%d", tmStruct.tm_mon);
	else sprintf_s(month, sizeof(month), "%d", tmStruct.tm_mon);
	if (tmStruct.tm_mday < 10) sprintf_s(day, sizeof(day), "0%d", tmStruct.tm_mday);
	else sprintf_s(day, sizeof(day), "%d", tmStruct.tm_mday);
	snprintf(date, sizeof(date), "%s-%s-%s", year, month, day);

	int size = mallocate(date, &dates->from);
	char* sql =
		"WITH t(StartDate, EndDate) AS( "
		"SELECT MIN(Date), MAX(Date) FROM Dues "
		"UNION "
		"SELECT MIN(Date), MAX(Date) FROM ReceiptPayments "
		") SELECT MIN(StartDate), MAX(EndDate) FROM t";
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_step(command);
	if (sqlite3_column_type(command, 0) == SQLITE_NULL) {
		size += mallocate(date, &dates->start);
		yearNum++;
		sprintf_s(year, sizeof(year), "%d", yearNum);
		snprintf(date, sizeof(date), "%s-%s-%s", year, month, day);
		size += mallocate(date, &dates->to);
		size += mallocate(date, &dates->end);
	}
	else {
		size += mallocate(sqlite3_column_text(command, 0), &dates->start);
		size += mallocate(sqlite3_column_text(command, 1), &dates->to);
		size += mallocate(sqlite3_column_text(command, 1), &dates->end);
		//dates->end = dates->to;
	}
	sqlite3_finalize(command);

	ResponsePersonal* rp = malloc(RESPONSE_PERSONAL_SIZE);
	rp->data = dates;
	rp->function = r->function;
	rp->sender = r->sender;
	rp->size = size;
	putInto(&personalResponses, rp);
}
static void getNotes(Request* r) {
	int size = 0;
	List list = { 0, 10, malloc(10 * NOTE_SIZE) };
	char* sql =
		"SELECT n.Id, Date, nt.Name, si.Name, Entry FROM Notes n "
		"LEFT JOIN Sites si ON si.Id = n.SiteId "
		"LEFT JOIN NoteTypes nt ON nt.Id = n.NoteTypeId "
		"ORDER BY Date DESC";
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Note* note = malloc(NOTE_SIZE);
		note->id = sqlite3_column_int(command, 0);
		size += (
			4
			+ mallocate(sqlite3_column_text(command, 1), &note->date)
			+ mallocate(sqlite3_column_text(command, 2), &note->type)
			+ mallocate(sqlite3_column_text(command, 3), &note->site)
			+ mallocate(sqlite3_column_text(command, 4), &note->entry)
			);
		addToList(&list, note);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getDues(Request* r) {
	int size = 0;
	List list = { 0, 10, malloc(10 * SUM_TRANSACTION_SIZE) };
	char* sql =
		"WITH t1(PartyId, Head, Purchase, Sell) AS( "
		"SELECT PartyId, CASE IsSell WHEN 0 THEN 'Purchase' ELSE 'Sell' END Head, "
		"SUM(CASE WHEN IsSell = 0 THEN Amount ELSE 0 END), "
		"SUM(CASE WHEN IsSell = 1 THEN Amount ELSE 0 END) "
		"FROM Dues "
		"GROUP BY PartyId, Head "
		"), "
		"t2(PartyId, Head, Receipt, Payment) AS( "
		"SELECT PartyId, he.Name Head, "
		"SUM(CASE WHEN IsReceipt = 1 THEN Amount ELSE 0 END), "
		"SUM(CASE WHEN IsReceipt = 0 THEN Amount ELSE 0 END) "
		"FROM ReceiptPayments rp "
		"LEFT JOIN Heads he ON he.Id = rp.HeadId "
		"GROUP BY PartyId, Head "
		"), "
		"t3(PartyId, Head, PurRec, SelPay) AS( "
		"SELECT * FROM t1 UNION ALL "
		"SELECT PartyId, CASE Head "
		"WHEN 'Payable' THEN 'Paid' "
		"WHEN 'Receivable' THEN 'Received' "
		"ELSE Head END Head, "
		"Receipt, Payment "
		"FROM t2 "
		") "
		"SELECT* FROM t3";
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	while (sqlite3_step(command) == SQLITE_ROW) {
		SumTransaction* st = malloc(SUM_TRANSACTION_SIZE);
		st->partyId = sqlite3_column_int(command, 0);
		st->purchaseReceipt = sqlite3_column_int(command, 2);
		st->sellPayment = sqlite3_column_int(command, 3);
		size += (12 + mallocate(sqlite3_column_text(command, 1), &st->head));
		addToList(&list, st);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getLedger(Request* r) {
	int id, size;
	memcpy_s(&id, 4, &r->packet[8], 4);
	size = 0;
	List list = { 0, 10, malloc(10 * REPORT_ENTRY_SIZE) };

	char* sql = "WITH t1(Date, Particulars, Receivable, Payable) AS( "
		"SELECT Date, si.Name || ' - ' || he.Name || coalesce(' - ' || sh.Name, '') || "
		"coalesce(' - ' || Quantity, '') || coalesce(' ' || un.Name, '') || "
		"coalesce(' - ' || Narration, ''), "
		"CASE WHEN IsSell = 1 THEN Amount ELSE 0 END, "
		"CASE WHEN IsSell = 0 THEN Amount ELSE 0 END "
		"FROM Dues t "
		"LEFT JOIN Sites si ON t.SiteId = si.Id "
		"LEFT JOIN Heads he ON t.HeadId = he.Id "
		"LEFT JOIN SubHeads sh ON t.SubHeadId = sh.Id "
		"LEFT JOIN Units un ON t.UnitId = un.Id "
		"WHERE PartyId = ? "
		"), "
		"t2(Date, Particulars, Receivable, Payable) AS( "
		"SELECT Date, he.Name || ' - ' || "
		"CASE IsCash WHEN 0 THEN 'Cash' WHEN 1 THEN 'Mobile' WHEN 2 THEN 'Discount' END, "
		"CASE WHEN IsReceipt = 0 THEN Amount ELSE 0 END, "
		"CASE WHEN IsReceipt = 1 THEN Amount ELSE 0 END "
		"FROM ReceiptPayments t "
		"LEFT JOIN Heads he ON t.HeadId = he.Id "
		"WHERE PartyId = ? "
		"), "
		"t3 AS(SELECT * FROM t1 UNION ALL SELECT * FROM t2) "
		"SELECT* FROM t3 ORDER BY Date";

	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_int(command, 1, id);
	sqlite3_bind_int(command, 2, id);
	while (sqlite3_step(command) == SQLITE_ROW) {
		ReportEntry* entry = malloc(REPORT_ENTRY_SIZE);
		entry->receivablePayment = sqlite3_column_int(command, 2);
		entry->payableReceipt = sqlite3_column_int(command, 3);
		size += (
			8
			+ mallocate(sqlite3_column_text(command, 0), &entry->date)
			+ mallocate(sqlite3_column_text(command, 1), &entry->particulars)
			);
		addToList(&list, entry);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getPurchaseSell(Request* r) {
	int size = 0;
	List list = { 0,10,malloc(10 * DUE_SIZE) };
	char* cursor, * from, * to, * sql;
	from = strtok_s(&r->packet[8], "", &cursor), cursor++;
	to = strtok_s(0, "", &cursor);

	sql = "SELECT Date, si.Name, pa.Name, he.Name, coalesce(sh.Name, ''), coalesce(Quantity, 0), "
		"coalesce(un.Name, ''), coalesce(Narration, ''), IsSell, IsConstruction, "
		"CASE IsSell WHEN 0 THEN Amount ELSE 0 END, "
		"CASE IsSell WHEN 1 THEN Amount ELSE 0 END "
		"FROM Dues d "
		"LEFT JOIN Sites si ON d.SiteId = si.Id "
		"LEFT JOIN Parties pa ON d.PartyId = pa.Id "
		"LEFT JOIN Heads he ON d.HeadId = he.Id "
		"LEFT JOIN SubHeads sh ON d.SubHeadId = sh.Id "
		"LEFT JOIN Units un ON d.UnitId = un.Id "
		"WHERE Date BETWEEN ? AND ?";
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_text(command, 1, from, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 2, to, -1, SQLITE_STATIC);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Due* due = malloc(DUE_SIZE);
		due->quantity = sqlite3_column_double(command, 5);
		due->isSell = (byte)sqlite3_column_int(command, 8);
		due->isConstruction = (byte)sqlite3_column_int(command, 9);
		due->purchase = sqlite3_column_int(command, 10);
		due->sell = sqlite3_column_int(command, 11);
		size += (
			18
			+ mallocate(sqlite3_column_text(command, 0), &due->date)
			+ mallocate(sqlite3_column_text(command, 1), &due->site)
			+ mallocate(sqlite3_column_text(command, 2), &due->party)
			+ mallocate(sqlite3_column_text(command, 3), &due->head)
			+ mallocate(sqlite3_column_text(command, 4), &due->subHead)
			+ mallocate(sqlite3_column_text(command, 6), &due->unit)
			+ mallocate(sqlite3_column_text(command, 7), &due->narration)
			);
		addToList(&list, due);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getReceiptPayment(Request* r) {
	int size = 0;
	List list = { 0,10,malloc(10 * RECEIPT_PAYMENT_SIZE) };
	char* cursor, * from, * to, * sql;
	from = strtok_s(&r->packet[8], "", &cursor), cursor++;
	to = strtok_s(0, "", &cursor);
	sql = "SELECT Date, pa.Name, he.Name, coalesce(Narration, ''), strftime('%Y - %m', Date), "
		"CASE WHEN IsReceipt = 0 THEN Amount ELSE 0 END, "
		"CASE WHEN IsReceipt = 1 THEN Amount ELSE 0 END, "
		"IsCash "
		"FROM ReceiptPayments rp "
		"LEFT JOIN Parties pa ON pa.Id = rp.PartyId "
		"LEFT JOIN Heads he ON he.Id = rp.HeadId "
		"WHERE Date BETWEEN ? AND ?";
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_text(command, 1, from, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 2, to, -1, SQLITE_STATIC);
	while (sqlite3_step(command) == SQLITE_ROW) {
		ReceiptPayment* rp = malloc(RECEIPT_PAYMENT_SIZE);
		rp->payment = sqlite3_column_int(command, 5);
		rp->receipt = sqlite3_column_int(command, 6);
		rp->isCash = (byte)sqlite3_column_int(command, 7);
		size += (
			9
			+ mallocate(sqlite3_column_text(command, 0), &rp->date)
			+ mallocate(sqlite3_column_text(command, 1), &rp->party)
			+ mallocate(sqlite3_column_text(command, 2), &rp->head)
			+ mallocate(sqlite3_column_text(command, 3), &rp->narration)
			+ mallocate(sqlite3_column_text(command, 4), &rp->month)
			);
		addToList(&list, rp);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getDetailPurchasePayable(Request* r) {
	byte state;
	int id;
	char* cursor, * type, * from, * to, * sql = 0;
	type = strtok_s(r->packet + 8, "", &cursor), cursor++;
	from = strtok_s(0, "", &cursor), cursor++;
	to = strtok_s(0, "", &cursor), cursor++;
	memcpy_s(&state, 1, cursor, 1), cursor++;
	memcpy_s(&id, 4, cursor, 4);

	if (strcmp(type, "Site") == 0) {
		switch (state) {
			case 0:// Head
				sql = "SELECT Heads.Name, SUM(Amount), 0, 0 FROM Dues "
					"LEFT JOIN Heads ON Heads.Id = Dues.HeadId "
					"WHERE IsSell = 0 AND SiteId = ? AND "
					"Date BETWEEN ? AND ? "
					"GROUP BY Heads.Name";
				break;
			case 1:// Party
				sql = "SELECT Parties.Name, SUM(Amount), 0, 0 FROM Dues "
					"LEFT JOIN Parties ON Parties.Id = Dues.PartyId "
					"WHERE IsSell = 0 AND SiteId = ? AND "
					"Date BETWEEN ? AND ? "
					"GROUP BY Parties.Name";
				break;
		}
	}
	else if (strcmp(type, "Head") == 0) {
		switch (state) {
			case 0:// Site
				sql = "SELECT Sites.Name, SUM(Amount), 0, 0 FROM Dues "
					"LEFT JOIN Sites ON Sites.Id = Dues.SiteId "
					"WHERE IsSell = 0 AND HeadId = ? AND "
					"Date BETWEEN ? AND ? "
					"GROUP BY Sites.Name";
				break;
			case 1:// Party
				sql = "SELECT Parties.Name, SUM(Amount), 0, 0 FROM Dues "
					"LEFT JOIN Parties ON Parties.Id = Dues.PartyId "
					"WHERE IsSell = 0 AND HeadId = ? AND "
					"Date BETWEEN ? AND ? "
					"GROUP BY Parties.Name";
				break;
		}
	}
	else {
		switch (state) {
			case 0:// Site
				sql = "SELECT Sites.Name, SUM(Amount), 0, 0 FROM Dues "
					"LEFT JOIN Sites ON Sites.Id = Dues.SiteId "
					"WHERE IsSell = 0 AND PartyId = ? AND "
					"Date BETWEEN ? AND ? "
					"GROUP BY Sites.Name";
				break;
			case 1:// Head
				sql = "SELECT Heads.Name, SUM(Amount), 0, 0 FROM Dues "
					"LEFT JOIN Heads ON Heads.Id = Dues.HeadId "
					"WHERE IsSell = 0 AND PartyId = ? AND "
					"Date BETWEEN ? AND ? "
					"GROUP BY Heads.Name";
				break;
		}
	}
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_int(command, 1, id);
	sqlite3_bind_text(command, 2, from, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 3, to, -1, SQLITE_STATIC);

	int size = 0;
	List list = { 0,10,malloc(10 * sizeof(KeyValueSeries)) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		KeyValueSeries* kv = malloc(sizeof(KeyValueSeries));
		kv->value = sqlite3_column_int(command, 1);
		size += (4 + mallocate(sqlite3_column_text(command, 0), &kv->key));
		addToList(&list, kv);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getAllHeadOrSitewisePurchase(Request* r) {
	char* cursor, * type, * from, * to, * sql;
	type = strtok_s(r->packet + 8, "", &cursor), cursor++;
	from = strtok_s(0, "", &cursor), cursor++;
	to = strtok_s(0, "", &cursor);

	if (strcmp(type, "Head") == 0) {
		sql = "SELECT Heads.Name, SUM(Amount) FROM Dues "
			"LEFT JOIN Heads ON Heads.Id = Dues.HeadId "
			"WHERE IsSell = 0 AND "
			"Date BETWEEN ? AND ? "
			"GROUP BY Heads.Name";
	}
	else {
		sql = "SELECT Sites.Name, SUM(Amount) FROM Dues "
			"LEFT JOIN Sites ON Sites.Id = Dues.SiteId "
			"WHERE IsSell = 0 AND "
			"Date BETWEEN ? AND ? "
			"GROUP BY Sites.Name";
	}
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_text(command, 1, from, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 2, to, -1, SQLITE_STATIC);
	int size = 0;
	List list = { 0,10,malloc(10 * sizeof(KeyValueSeries)) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		KeyValueSeries* kv = malloc(sizeof(KeyValueSeries));
		kv->value = sqlite3_column_int(command, 1);
		size += (4 + mallocate(sqlite3_column_text(command, 0), &kv->key));
		addToList(&list, kv);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getSingleHeadOrSitewisePurchase(Request* r) {
	byte state;
	int id, max;
	memcpy_s(&state, 1, &r->packet[8], 1);
	memcpy_s(&id, 4, &r->packet[9], 4);
	memcpy_s(&max, 4, &r->packet[13], 4);
	char* type = &r->packet[17];
	char* sql = 0;
	switch (state) {
		case 0: {
			if (strcmp(type, "Head") == 0) {
				sql = "WITH t AS( "
					"SELECT Date, SUM(Amount) FROM Dues WHERE HeadId = ? AND IsSell = 0 "
					"GROUP BY Date "
					"ORDER BY Date DESC "
					"LIMIT ?) "
					"SELECT * FROM t ORDER BY Date";
			}
			else {
				sql = "WITH t AS( "
					"SELECT Date, SUM(Amount) FROM Dues WHERE SiteId = ? AND IsSell = 0 "
					"GROUP BY Date "
					"ORDER BY Date DESC "
					"LIMIT ?) "
					"SELECT * FROM t ORDER BY Date";
			}
		} break;
		case 1: {
			if (strcmp(type, "Head") == 0) {
				sql = "WITH t AS( "
					"SELECT strftime('%Y - %m', Date) Month, SUM(Amount) FROM Dues "
					"WHERE HeadId = ? AND IsSell = 0 "
					"GROUP BY Month "
					"ORDER BY Month DESC "
					"LIMIT ?) "
					"SELECT * FROM t ORDER BY Month";
			}
			else {
				sql = "WITH t AS( "
					"SELECT strftime('%Y - %m', Date) Month, SUM(Amount) FROM Dues "
					"WHERE SiteId = ? AND IsSell = 0 "
					"GROUP BY Month "
					"ORDER BY Month DESC "
					"LIMIT ?) "
					"SELECT * FROM t ORDER BY Month";
			}
		} break;
	}
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_int(command, 1, id);
	sqlite3_bind_int(command, 2, max);

	int size = 0;
	List list = { 0,10,malloc(10 * sizeof(KeyValueSeries)) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		KeyValueSeries* kv = malloc(sizeof(KeyValueSeries));
		kv->value = sqlite3_column_int(command, 1);
		size += (4 + mallocate(sqlite3_column_text(command, 0), &kv->key));
		addToList(&list, kv);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);

}
static void getAllPartyTransactions(Request* r) {
	char* cursor, * from, * to, * sql;
	strtok_s(r->packet + 8, "", &cursor), cursor++; // skip type
	from = strtok_s(0, "", &cursor), cursor++;
	to = strtok_s(0, "", &cursor);

	sql = "WITH t1 (Party, Purchase, Payment, Due) AS( "
		"SELECT Parties.Name, SUM(Amount), 0, 0 FROM Dues "
		"LEFT JOIN Parties ON Parties.Id = Dues.PartyId "
		"WHERE IsSell = 0 AND "
		"Date BETWEEN ? AND ? "
		"GROUP BY Parties.Name "
		"), "
		"t2(Party, Purchase, Payment, Due) AS( "
		"SELECT Parties.Name, 0, SUM(Amount), 0 FROM ReceiptPayments rp "
		"LEFT JOIN Parties ON Parties.Id = rp.PartyId "
		"WHERE IsReceipt = 0 AND "
		"Date BETWEEN ? AND ? "
		"GROUP BY Parties.Name "
		"), "
		"t3(Party, Purchase, Payment, Due) AS( "
		"SELECT * FROM t1 "
		"UNION ALL "
		"SELECT * FROM t2 "
		"), "
		"t4(Party, Purchase, Payment, Due) AS( "
		"SELECT Party, SUM(Purchase), SUM(Payment), SUM(Purchase - Payment) "
		"FROM t3 "
		"GROUP BY Party "
		") "
		"SELECT * FROM t4";

	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_text(command, 1, from, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 2, to, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 3, from, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 4, to, -1, SQLITE_STATIC);
	int size = 0;
	List list = { 0,10,malloc(10 * sizeof(KeyTrippleValueSeries)) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		KeyTrippleValueSeries* kv = malloc(sizeof(KeyTrippleValueSeries));
		kv->value1 = sqlite3_column_int(command, 1);
		kv->value2 = sqlite3_column_int(command, 2);
		kv->value3 = sqlite3_column_int(command, 3);
		size += (12 + mallocate(sqlite3_column_text(command, 0), &kv->key));
		addToList(&list, kv);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getSinglePartyTransaction(Request* r) {
	byte state;
	int id, max;
	memcpy_s(&state, 1, &r->packet[8], 1);
	memcpy_s(&id, 4, &r->packet[9], 4);
	memcpy_s(&max, 4, &r->packet[13], 4);
	char* sql = 0;
	if (state) {
		sql = "WITH t1(Date, Puchase, Payment, Due) AS( "
			"SELECT Date, SUM(Amount), 0, 0 FROM Dues WHERE PartyId = ? AND IsSell = 0 "
			"GROUP BY Date "
			"ORDER BY Date DESC "
			"LIMIT ? "
			"), "
			"t2(Date, Puchase, Payment, Due) AS( "
			"SELECT(SELECT MIN(Date) FROM t1), 0, 0, "
			"(SELECT SUM(Amount) FROM Dues WHERE Date <= (SELECT MIN(Date) FROM t1) AND PartyId = ? AND IsSell = 0) "
			"- (SELECT SUM(Amount) FROM ReceiptPayments WHERE Date <= (SELECT MIN(Date) FROM t1) AND PartyId = ? AND IsReceipt = 0) "
			"), "
			"t3(Date, Puchase, Payment, Due) AS( "
			"SELECT Date, 0, SUM(Amount), 0 FROM ReceiptPayments WHERE PartyId = ? AND IsReceipt = 0 "
			"AND Date >= (SELECT MIN(Date) FROM t1) "
			"GROUP BY Date "
			"), "
			"t4(Date, Puchase, Payment, Due) AS( "
			"SELECT * FROM t1 "
			"UNION ALL "
			"SELECT * FROM t2 "
			"UNION ALL "
			"SELECT * FROM t3 "
			"), "
			"t5(Date, Puchase, Payment, Due) AS( "
			"SELECT Date, SUM(Puchase), SUM(Payment), SUM(Due) FROM t4 "
			"GROUP BY Date "
			"), "
			"t6(RowNum, Date, Puchase, Payment, Due) AS( "
			"SELECT ROW_NUMBER() OVER(), * FROM t5 ORDER BY Date "
			") "
			"SELECT Date, Puchase, Payment, "
			"CASE RowNum WHEN 1 THEN Due ELSE "
			"SUM(Due + Puchase - Payment) OVER(ORDER BY RowNum) END Due "
			"FROM t6 LIMIT ?";
	}
	else {
		sql = "WITH t1(Month, Puchase, Payment, Due) AS( "
			"SELECT strftime('%Y - %m', Date) Month, SUM(Amount), 0, 0 FROM Dues WHERE PartyId = ? AND IsSell = 0 "
			"GROUP BY Month "
			"ORDER BY Month DESC "
			"LIMIT ? "
			"), "
			"t2(Month, Puchase, Payment, Due) AS( "
			"SELECT(SELECT MIN(Month) FROM t1), 0, 0, "
			"(SELECT SUM(Amount) FROM Dues WHERE strftime('%Y - %m', Date) <= (SELECT MIN(Month) FROM t1) AND PartyId = ? AND IsSell = 0) "
			"- (SELECT SUM(Amount) FROM ReceiptPayments WHERE strftime('%Y - %m', Date) <= (SELECT MIN(Month) FROM t1) AND PartyId = ? AND IsReceipt = 0) "
			"), "
			"t3(Month, Puchase, Payment, Due) AS( "
			"SELECT strftime('%Y - %m', Date) Month, 0, SUM(Amount), 0 FROM ReceiptPayments WHERE PartyId = ? AND IsReceipt = 0 "
			"AND Month >= (SELECT MIN(Month) FROM t1) "
			"GROUP BY Month "
			"), "
			"t4(Month, Puchase, Payment, Due) AS( "
			"SELECT * FROM t1 "
			"UNION ALL "
			"SELECT * FROM t2 "
			"UNION ALL "
			"SELECT * FROM t3 "
			"), "
			"t5(Month, Puchase, Payment, Due) AS( "
			"SELECT Month, SUM(Puchase), SUM(Payment), SUM(Due) FROM t4 "
			"GROUP BY Month "
			"), "
			"t6(RowNum, Month, Puchase, Payment, Due) AS( "
			"SELECT ROW_NUMBER() OVER(), * FROM t5 ORDER BY Month "
			") "
			"SELECT Month, Puchase, Payment, "
			"CASE RowNum WHEN 1 THEN Due ELSE "
			"SUM(Due + Puchase - Payment) OVER(ORDER BY RowNum) END Due "
			"FROM t6 LIMIT ?";
	}
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_int(command, 1, id);
	sqlite3_bind_int(command, 2, max);
	sqlite3_bind_int(command, 3, id);
	sqlite3_bind_int(command, 4, id);
	sqlite3_bind_int(command, 5, id);
	sqlite3_bind_int(command, 6, max);
	int size = 0;
	List list = { 0,10,malloc(10 * sizeof(KeyTrippleValueSeries)) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		KeyTrippleValueSeries* kv = malloc(sizeof(KeyTrippleValueSeries));
		kv->value1 = sqlite3_column_int(command, 1);
		kv->value2 = sqlite3_column_int(command, 2);
		kv->value3 = sqlite3_column_int(command, 3);
		size += (12 + mallocate(sqlite3_column_text(command, 0), &kv->key));
		addToList(&list, kv);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getPurchases(Request* r) {
	byte state;
	char* cursor, * from, * to, * sql;
	memcpy_s(&state, 1, &r->packet[8], 1);
	from = strtok_s(&r->packet[9], "", &cursor), cursor++;
	to = strtok_s(0, "", &cursor);

	if (state == 4) { // All
		sql = "SELECT Sites.Name, SUM(Amount) FROM Dues "
			"LEFT JOIN Sites ON Sites.Id = SiteId "
			"WHERE IsSell = 0 AND Date BETWEEN ? AND ?";
		sqlite3_prepare_v2(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, from, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 2, to, -1, SQLITE_STATIC);
	}
	else {
		sql = "SELECT Sites.Name, SUM(Amount) FROM Dues "
			"LEFT JOIN Sites ON Sites.Id = SiteId "
			"WHERE IsSell = 0 AND IsConstruction = ? AND "
			"Date BETWEEN ? AND ? "
			"GROUP BY Sites.Name";
		sqlite3_prepare_v2(connection, sql, -1, &command, 0);
		sqlite3_bind_int(command, 1, state);
		sqlite3_bind_text(command, 2, from, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 3, to, -1, SQLITE_STATIC);
	}
	int size = 0;
	List list = { 0,10,malloc(10 * sizeof(KeyValueSeries)) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		KeyValueSeries* kv = malloc(sizeof(KeyValueSeries));
		kv->value = sqlite3_column_int(command, 1);
		size += (4 + mallocate(sqlite3_column_text(command, 0), &kv->key));
		addToList(&list, kv);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getPayments(Request* r) {
	char* cursor, * from, * to, * sql;
	from = strtok_s(&r->packet[8], "", &cursor), cursor++;
	to = strtok_s(0, "", &cursor);

	sql = "SELECT CASE IsCash WHEN 0 THEN 'Cash' WHEN 1 THEN 'Mobile' ELSE 'Discount' END Mode, "
		"SUM(Amount) FROM ReceiptPayments WHERE IsReceipt = 0 AND "
		"Date BETWEEN ? AND ? "
		"GROUP BY Mode";
	sqlite3_prepare_v2(connection, sql, -1, &command, 0);
	sqlite3_bind_text(command, 1, from, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 2, to, -1, SQLITE_STATIC);

	int size = 0;
	List list = { 0,10,malloc(10 * sizeof(KeyValueSeries)) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		KeyValueSeries* kv = malloc(sizeof(KeyValueSeries));
		kv->value = sqlite3_column_int(command, 1);
		size += (4 + mallocate(sqlite3_column_text(command, 0), &kv->key));
		addToList(&list, kv);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}

static ulong ProcessRequest(void* p) {
	while (isRunning) {
		Request* r = takeOutFrom(&requests);
		switch (r->function) {
			case GetInitialData: sendStartupPackets(r->sender); break;
			case GetPurchaseSellByDate: getPurchaseSellByDate(r); break;
			case GetReceiptPaymentByDate: getReceiptPaymentByDate(r); break;
			case GetDates: getDates(r); break;
			case GetNotes: getNotes(r); break;
			case GetDues: getDues(r); break;
			case GetLedger: getLedger(r); break;
			case GetPurchaseSell: getPurchaseSell(r); break;
			case GetReceiptPayment: getReceiptPayment(r); break;
			case GetDetailPurchasePayable: getDetailPurchasePayable(r); break;
			case GetAllHeadOrSitewisePurchase: getAllHeadOrSitewisePurchase(r); break;
			case GetSingleHeadOrSitewisePurchase: getSingleHeadOrSitewisePurchase(r); break;
			case GetAllPartyTransactions: getAllPartyTransactions(r); break;
			case GetSinglePartyTransaction: getSinglePartyTransaction(r); break;
			case GetPurchases: getPurchases(r); break;
			case GetPayments: getPayments(r); break;

			case AddSite: addSite(r); break;
			case AddParty: addParty(r); break;
			case AddHead: addHead(r); break;
			case AddSubHead: addSubHead(r); break;
			case AddUnit: addUnit(r); break;
			case AddNoteType: addNoteType(r); break;
			case AddNote: addNote(r); break;
			case AddEntries: addEntries(r); break;

			case EditSite: editSite(r); break;
			case EditParty: editParty(r); break;
			case EditHead: editHead(r); break;
			case EditSubHead: editSubHead(r); break;
			case EditUnit: editUnit(r); break;
			case EditNoteType: editNoteType(r); break;
			case EditNote: editNote(r); break;
			case EditPurchaseSell: editPurchaseSell(r); break;
			case EditReceiptPayment: editReceiptPayment(r); break;

			case DeleteReceiptPayment: deleteReceiptPayment(r); break;
			case DeletePurchaseSell: deletePurchaseSell(r); break;
			case DeleteNote: deleteNote(r); break;
		}
		putInto(&garbageRequests, r);
	}
	return 0;
}
static ulong FreeRequest(void* p) {
	while (isRunning) {
		Request* r = takeOutFrom(&garbageRequests);
		free(r->packet);
		free(r);
	}
	return 0;
}

void InitializeDatabase() {
	garbageRequests.count = 0;
	garbageRequests.capacity = 5;
	garbageRequests.data = malloc(garbageRequests.capacity * POINTER_SIZE);
	garbageRequests.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&garbageRequests.section);

	freeRequestThread = CreateThread(NULL, 0, FreeRequest, NULL, 0, NULL);
	requestProcessThread = CreateThread(NULL, 0, ProcessRequest, NULL, 0, NULL);

	initializeList();
	initializeQueue();

	char* database = "C:/Users/Emon/Desktop/CDRM.db";
	sqlite3_open(database, &connection);
	char* query =
		"SELECT * FROM Sites; "
		"SELECT * FROM Heads; "
		"SELECT * FROM SubHeads; "
		"SELECT Id, Name, Address, coalesce(Phone, '') FROM Parties; "
		"SELECT * FROM Units; "
		"SELECT * FROM NoteTypes";

	char* pzTail;
	sqlite3_prepare_v2(connection, query, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Site* site = malloc(SITE_SIZE);
		site->id = sqlite3_column_int(command, 0);
		total.site += (
			4
			+ mallocate(sqlite3_column_text(command, 1), &site->name)
			+ mallocate(sqlite3_column_text(command, 2), &site->address)
			);
		addToList(&sites, site);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(connection, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Head* head = malloc(HEAD_SIZE);
		head->id = sqlite3_column_int(command, 0);
		total.head += (4 + mallocate(sqlite3_column_text(command, 1), &head->name));
		addToList(&heads, head);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(connection, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Subhead* subHead = malloc(SUBHEAD_SIZE);
		subHead->id = sqlite3_column_int(command, 0);

		total.subHead += (4 + mallocate(sqlite3_column_text(command, 1), &subHead->name));
		addToList(&subHeads, subHead);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(connection, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Party* party = malloc(PARTY_SIZE);
		party->id = sqlite3_column_int(command, 0);
		total.party += (
			4
			+ mallocate(sqlite3_column_text(command, 1), &party->name)
			+ mallocate(sqlite3_column_text(command, 2), &party->address)
			+ mallocate(sqlite3_column_text(command, 3), &party->phone)
			);
		addToList(&parties, party);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(connection, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Unit* unit = malloc(UNIT_SIZE);
		unit->id = sqlite3_column_int(command, 0);
		total.unit += (4 + mallocate(sqlite3_column_text(command, 1), &unit->name));
		addToList(&units, unit);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(connection, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		NoteType* type = malloc(NOTE_TYPE_SIZE);
		type->id = sqlite3_column_int(command, 0);
		total.noteType += (4 + mallocate(sqlite3_column_text(command, 1), &type->name));
		addToList(&noteTypes, type);
	}
	sqlite3_finalize(command);
}
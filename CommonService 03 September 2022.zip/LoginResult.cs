﻿public class LoginResult
{
    public Role Role { get; set; }
    public int UserId { get; set; }
    public bool IsSuccess { get; set; }

    public static LoginResult FromBytes(byte[] array) {
        var span = new ReadOnlySpan<byte>(array);
        var level = BitConverter.ToInt32(span.Slice(0, 4));
        var id = BitConverter.ToInt32(span.Slice(4, 4));
        var status = BitConverter.ToBoolean(span.Slice(8, 1));
        return new LoginResult() {
            Role = (Role)level,
            UserId = id,
            IsSuccess = status
        };
    }
}

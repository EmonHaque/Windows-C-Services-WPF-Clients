﻿public enum Role
{
    None,
    Super,
    Admin,
    Reader
}

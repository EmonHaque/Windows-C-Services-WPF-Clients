﻿public class AppFile
{
    public int Size { get; set; }
    public string Name { get; set; }
    public byte[] Content { get; set; }

    public static AppFile FromBytes(byte[] array) {
        int start = 0;
        while (true) {
            if (array[start] != 0) {
                start++;
                continue;
            }
            break;
        }
        return new AppFile() {
            Name = Encoding.ASCII.GetString(array.Take(start).ToArray()),
            Content = array.Skip(start + 1).ToArray()
        };
    }
}

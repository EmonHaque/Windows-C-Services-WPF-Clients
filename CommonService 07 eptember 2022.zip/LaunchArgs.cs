﻿public class LaunchArgs
{
    public string App { get; set; }
    public string Version { get; set; }
    public string Path { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        var app = Encoding.ASCII.GetBytes(App + '\0');
        var version = Encoding.ASCII.GetBytes(Version + '\0');
        var size = BitConverter.GetBytes(app.Length + version.Length);
        return new List<ArraySegment<byte>>() { size, app, version };
    }
}

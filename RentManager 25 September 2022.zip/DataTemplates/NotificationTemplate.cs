﻿class NotificationTemplate : DataTemplate
{
    Action decreaseCount;
	public NotificationTemplate(Action decreaseCount) {
        this.decreaseCount = decreaseCount;
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var category = new FrameworkElementFactory(typeof(TextBlock));
        var message = new FrameworkElementFactory(typeof(TextBlock));

        grid.SetValue(Grid.BackgroundProperty, new SolidColorBrush(Colors.Transparent));  
        col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(100));
        message.SetValue(Grid.ColumnProperty, 1);
        message.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        
        category.SetBinding(TextBlock.TextProperty, new Binding(nameof(Notification.Category)));
        message.SetBinding(TextBlock.TextProperty, new Binding(nameof(Notification.Message)));
        
        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(category);
        grid.AppendChild(message);
        VisualTree = grid;

        grid.AddHandler(Grid.LoadedEvent, new RoutedEventHandler(onLoaded));
        grid.AddHandler(Grid.MouseUpEvent, new MouseButtonEventHandler(onClicked));
        grid.AddHandler(Grid.UnloadedEvent, new RoutedEventHandler(onUnloaded));
    }

    void onClicked(object sender, MouseButtonEventArgs e) {
        var grid = (Grid)sender;
        var notification = (Notification)grid.DataContext;
        if (!notification.IsRead) {
            notification.IsRead = true;
            grid.Background = Brushes.Transparent;
            decreaseCount.Invoke();
        }
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        var grid = (Grid)sender;
        grid.RemoveHandler(Grid.LoadedEvent, (RoutedEventHandler)onLoaded);
        grid.RemoveHandler(Grid.MouseUpEvent, (RoutedEventHandler)onLoaded);
        grid.RemoveHandler(Grid.UnloadedEvent, (RoutedEventHandler)onUnloaded);
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        var grid = (Grid)sender;
        var notification = (Notification)grid.DataContext;
        if (!notification.IsRead) {
            var brush = new SolidColorBrush(Colors.Transparent);
            grid.Background = brush;
            var anim = new ColorAnimation() {
                Duration = TimeSpan.FromMilliseconds(750),
                From = Colors.CornflowerBlue,
                To = Color.FromArgb(175, 0, 0, 0)
            };
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
    }
}

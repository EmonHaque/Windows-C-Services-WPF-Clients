﻿class LocalConstants
{
    public const string DownMessage = "Service down!";
}

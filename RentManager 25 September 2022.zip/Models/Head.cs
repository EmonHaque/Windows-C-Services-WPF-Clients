﻿class Head : Notifiable
{
    public int? Id { get; set; }
    int? controlId;
    public int? ControlId {
        get { return controlId; }
        set {
            if (controlId != value) {
                controlId = value;
                OnPropertyChanged(nameof(ControlId));
            }
        }
    }
    string name;
    public string Name {
        get { return name; }
        set {
            if (name != value) {
                name = value;
                OnPropertyChanged(nameof(Name));
            }
        }
    }
    string description;
    public string Description {
        get { return description; }
        set {
            if (description != value) {
                description = value;
                OnPropertyChanged(nameof(Description));
            }
        }
    }
}

﻿class HomeView : View
{
    override public string Icon => Icons.Home;
    public override FrameworkElement container => grid;
    Grid grid;
    public HomeView() {
        var counts = new Counts();
        var plotDue = new PlotDue();
        var plotRent = new PlotRent();
        var tenantDetail = new TenantDetail();
        var rentDetail = new RentDetail();
        var rent = new Rent();

        Grid.SetColumn(plotRent, 1);
        Grid.SetColumn(plotDue, 2);
        Grid.SetRow(rent, 1);
        Grid.SetRow(rentDetail, 1);
        Grid.SetRow(tenantDetail, 1);
        Grid.SetColumn(rentDetail, 1);
        Grid.SetColumn(tenantDetail, 2);
        grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition(),
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                },
            Children = { counts, plotRent, plotDue, rent, rentDetail, tenantDetail }
        };
        AddVisualChild(grid);
    }
}

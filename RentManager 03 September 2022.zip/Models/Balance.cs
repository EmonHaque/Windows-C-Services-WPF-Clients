﻿class Balance
{
    public string Tenant { get; set; }
    public string Space { get; set; }
    public string DateStart { get; set; }
    public string DateEnd { get; set; }
    public int Security { get; set; }
    public int Rent { get; set; }
    public int Due { get; set; }
    public bool IsExpired { get; set; }
    public int Count { get; set; }
}

﻿class LedgerTemplate : DataTemplate
{
    public LedgerTemplate(string query, object viewModel, double fixedColumnsWidth = 80, double margin = 5) {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var date = new FrameworkElementFactory(typeof(TextBlock));
        var receivable = new FrameworkElementFactory(typeof(TextBlock));
        var receipt = new FrameworkElementFactory(typeof(TextBlock));
        var balance = new FrameworkElementFactory(typeof(TextBlock));
        var particulars = new FrameworkElementFactory(typeof(HiBlock));
        var names = new FrameworkElementFactory(typeof(Run));
        var narration = new FrameworkElementFactory(typeof(Run));

        grid.SetValue(Grid.MarginProperty, new Thickness(0, 0, margin, 0));
        col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));
        col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));

        receivable.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        receipt.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        balance.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        receivable.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        receipt.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        balance.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);

        particulars.SetValue(Grid.ColumnProperty, 1);
        receivable.SetValue(Grid.ColumnProperty, 2);
        receipt.SetValue(Grid.ColumnProperty, 3);
        balance.SetValue(Grid.ColumnProperty, 4);
        particulars.SetValue(HiBlock.TextWrappingProperty, TextWrapping.Wrap);
        narration.SetValue(Run.FontStyleProperty, FontStyles.Italic);
        narration.SetValue(Run.ForegroundProperty, Brushes.Gray);

        if (margin == 0) {
            date.SetValue(TextBlock.ForegroundProperty, Brushes.Black);
            names.SetValue(Run.ForegroundProperty, Brushes.Black);
            receivable.SetValue(TextBlock.ForegroundProperty, Brushes.Black);
            receipt.SetValue(TextBlock.ForegroundProperty, Brushes.Black);
            balance.SetValue(TextBlock.ForegroundProperty, Brushes.Black);
        }

        date.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Date)) { StringFormat = "dd MMM yyy" });
        particulars.SetBinding(HiBlock.QueryProperty, new Binding(query) { Source = viewModel, IsAsync = true });
        names.SetBinding(Run.TextProperty, new Binding(nameof(ReportEntry.Particulars)));
        narration.SetBinding(Run.TextProperty, new Binding(nameof(ReportEntry.Narration)));
        receivable.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Receivable)) { StringFormat = Constants.NumberFormat });
        receipt.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Receipt)) { StringFormat = Constants.NumberFormat });
        balance.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Balance)) { StringFormat = Constants.NumberFormat });

        particulars.AppendChild(names);
        particulars.AppendChild(narration);
        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);
        grid.AppendChild(date);
        grid.AppendChild(particulars);
        grid.AppendChild(receivable);
        grid.AppendChild(receipt);
        grid.AppendChild(balance);
        VisualTree = grid;
    }
}

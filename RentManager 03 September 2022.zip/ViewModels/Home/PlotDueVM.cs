﻿class PlotDueVM : Notifiable
{
    int? currentId;
    bool state;
    public bool State {
        get { return state; }
        set {
            if (state != value) {
                state = value;
                if (state) getData(0);
                else if (currentId != null) getData(currentId);
                else {
                    Data = null;
                    OnPropertyChanged(nameof(Data));
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
    }
    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }
    public List<PlotwiseDue> Data { get; set; }
    public string Name { get; set; }

    public PlotDueVM() => RentVM.SelectionChanged += onSelectionChanged;

    public void Refresh() {
        if (State) getData(0);
        else getData(currentId);
    }
    void onSelectionChanged(int? id, List<DepositDueRent> arg2) {
        if (currentId == id) return;
        currentId = id;
        if (!State) getData(currentId);
        else {
            State = false;
            OnPropertyChanged(nameof(State));
        }
    }
    async void getData(int? id) {
        if (id == null) {
            Data = null;
            Name = null;
            OnPropertyChanged(nameof(Data));
            OnPropertyChanged(nameof(Name));
            return;
        }
        var date = DateTime.Today.AddYears(-2);
        date = new DateTime(date.Year, date.Month, 1);

        Status = "requesting data";
        await Task.Delay(250);
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetPlotDueChart,
            Bytes = new List<ArraySegment<byte>>() {
                BitConverter.GetBytes(id.Value),
                Encoding.ASCII.GetBytes(date.ToString("yyyy-MM-dd") +'\0')
            }
        };

        var response = await App.service.GetResponse(request);
        Status = "received " + response.Packet.Length.ToString("N0") + " bytes";
        await Task.Delay(250);
        if (!response.IsSuccess) {
            Status = LocalConstants.DownMessage;
            return;
        }
        Data = await Task.Run(response.Packet.ToPlotwiseDues).ConfigureAwait(false);

        if(id == 0) Name = "in All plots";
        else Name = Data.Count > 0 ? "in " + AppData.plots.First(x => x.Id == id).Name : null;
        
        OnPropertyChanged(nameof(Data));
        OnPropertyChanged(nameof(Name));
    }
}

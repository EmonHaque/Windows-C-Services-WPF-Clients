﻿public class CountBlock : Border
{
    TextBlock text;
    public CountBlock() {
        VerticalAlignment = VerticalAlignment.Center;
        MinWidth = 20;
        text = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center
        };
        CornerRadius = new CornerRadius(10);
        Background = Constants.BackgroundDark;
        BorderBrush = Brushes.LightGray;
        BorderThickness = new Thickness(0.5);
        Padding = new Thickness(5, 2, 5, 2);
        Child = text;
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        text.SetBinding(TextBlock.TextProperty, new Binding(nameof(Count)) { Source = this });
    }

    public string Count {
        get { return (string)GetValue(CountProperty); }
        set { SetValue(CountProperty, value); }
    }
    public static readonly DependencyProperty CountProperty =
        DependencyProperty.Register("Count", typeof(string), typeof(CountBlock), new PropertyMetadata(null));
}

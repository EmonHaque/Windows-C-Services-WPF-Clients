﻿class Ledger : Grid
{
    TextBlock totalReceivable, totalReceipt;
    Run totalEntry;
    Border header, footer;
    ListBox entries;
    Thickness padding;
    double fixedColumnWidth = 80;
    public string Source { get; set; }
    object viewModel;
    string query;

    public Ledger(object viewModel, string query) {
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

        this.viewModel = viewModel;
        this.query = query;
        padding = new Thickness(5, 0, 5, 0);
        initializeHeader();
        initializeEntries();
        initializeFooter();

        SetRow(entries, 1);
        SetRow(footer, 2);

        Children.Add(header);
        Children.Add(entries);
        Children.Add(footer);
    }

    void initializeHeader() {
        var date = new TextBlock() { Text = "Date" };
        var particulars = new TextBlock() { Text = "Particulars" };
        var charges = new TextBlock() {
            Inlines = {
                    new Run(){Text = "Receivable/"},
                    new LineBreak(),
                    new Run(){Text = "Payment"}
                },
            HorizontalAlignment = HorizontalAlignment.Right,
            TextAlignment = TextAlignment.Right
        };
        var receipt = new TextBlock() { Text = "Receipt", HorizontalAlignment = HorizontalAlignment.Right };
        var balance = new TextBlock() {
            Text = "Balance",
            HorizontalAlignment = HorizontalAlignment.Right
        };
        SetColumn(particulars, 1);
        SetColumn(charges, 2);
        SetColumn(receipt, 3);
        SetColumn(balance, 4);

        var grid = new Grid() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness + Constants.ScrollPresenterMargin, 0),
            Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center),
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                            }
                        }
                    }
                },
            ColumnDefinitions = {
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(),
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) }
                },
            Children = { date, particulars, charges, receipt, balance }
        };
        header = new Border() {
            Padding = padding,
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
    }
    void initializeEntries() {
        entries = new ListBox() {
            Margin = new Thickness(0,3,0,3),
            ItemTemplate = new LedgerTemplate(query, viewModel),
            Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                            }
                        }
                    }
                }
        };
    }
    void initializeFooter() {
        totalEntry = new Run();
        var totalText = new TextBlock() { Inlines = { "Total of ", totalEntry } };
        totalReceivable = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalReceipt = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        SetColumn(totalReceivable, 2);
        SetColumn(totalReceipt, 3);
        var grid = new Grid() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness + Constants.ScrollPresenterMargin, 0),
            Resources = {
                    {
                        typeof(TextBlock),
                        new Style(){
                        Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)}
                        }
                    }
                },
            ColumnDefinitions = {
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(),
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) }
                },
            Children = { totalText, totalReceivable, totalReceipt }
        };

        footer = new Border() {
            Padding = padding,
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
        totalEntry.SetBinding(Run.TextProperty, new Binding(nameof(ReportBase.TotalEntry)) { StringFormat = "N0"});
        totalReceivable.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportBase.TotalReceivable)) { StringFormat = Constants.NumberFormat });
        totalReceipt.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportBase.TotalReceipt)) { StringFormat = Constants.NumberFormat });
    }

    #region DependencyProperties
    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }

    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(Ledger), new PropertyMetadata(null, onSourceChanged));

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as Ledger;
        o.entries.ItemsSource = (IEnumerable)e.NewValue;
    }
    #endregion
}

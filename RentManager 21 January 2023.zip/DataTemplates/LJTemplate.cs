﻿class LJTemplate : DataTemplate
{
	public LJTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid" };
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var tenant = new FrameworkElementFactory(typeof(TextBlock));
        var space = new FrameworkElementFactory(typeof(TextBlock));
        var dateStart = new FrameworkElementFactory(typeof(TextBlock));
        var dateEnd = new FrameworkElementFactory(typeof(TextBlock));
        var receivable = new FrameworkElementFactory(typeof(TextBlock));

        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));

        space.SetValue(Grid.ColumnProperty, 1);
        dateStart.SetValue(Grid.ColumnProperty, 2);
        dateEnd.SetValue(Grid.ColumnProperty, 3);
        receivable.SetValue(Grid.ColumnProperty, 4);

        tenant.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        space.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        dateStart.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Center);
        dateEnd.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Center);
        receivable.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        space.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        dateStart.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        dateEnd.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        receivable.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);

        tenant.SetBinding(TextBlock.TextProperty, new Binding(nameof(LeftOrJoined.Tenant)));
        space.SetBinding(TextBlock.TextProperty, new Binding(nameof(LeftOrJoined.Space)));
        dateStart.SetBinding(TextBlock.TextProperty, new Binding(nameof(LeftOrJoined.DateStart)));
        dateEnd.SetBinding(TextBlock.TextProperty, new Binding(nameof(LeftOrJoined.DateEnd)));
        receivable.SetBinding(TextBlock.TextProperty, new Binding(nameof(LeftOrJoined.Receivable)) { StringFormat = "N0"});

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);
        grid.AppendChild(tenant);
        grid.AppendChild(space);
        grid.AppendChild(dateStart);
        grid.AppendChild(dateEnd);
        grid.AppendChild(receivable);
        VisualTree = grid;
    }
}

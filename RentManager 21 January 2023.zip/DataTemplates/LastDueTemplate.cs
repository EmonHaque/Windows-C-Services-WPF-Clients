﻿class LastDueTemplate : DataTemplate
{
	public LastDueTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));

        var space = new FrameworkElementFactory(typeof(TextBlock));
		var security = new FrameworkElementFactory(typeof(TextBlock));
		var due = new FrameworkElementFactory(typeof(TextBlock));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));

        security.SetValue(Grid.ColumnProperty, 1);
        due.SetValue(Grid.ColumnProperty, 2);

        due.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        security.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

        space.SetBinding(TextBlock.TextProperty, new Binding(nameof(LastDue.Space)));
        security.SetBinding(TextBlock.TextProperty, new Binding(nameof(LastDue.Security)) { StringFormat = Constants.NumberFormat });
        due.SetBinding(TextBlock.TextProperty, new Binding(nameof(LastDue.Due)) { StringFormat = Constants.NumberFormat });


        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(space);
        grid.AppendChild(security);
        grid.AppendChild(due);

        VisualTree = grid;
    }
}

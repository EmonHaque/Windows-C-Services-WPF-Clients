﻿class ReportPlot : LedgerView
{
    public override string Icon => Icons.Plot;
    ReportPlotVM vm;
    protected override ReportBase viewModel => vm;
    protected override string reportType => "Plot";
    protected override string display => "Name";
    protected override void initialize() {
        vm = new ReportPlotVM();
    }
}

﻿class ReportSpace : LedgerView
{
    public override string Icon => Icons.Space;

    ReportSpaceVM vm;
    ControlTemplate template;
    protected override ReportBase viewModel => vm;
    protected override ControlTemplate groupTemplate => template;
    protected override string reportType => "Space";
    protected override string display => "Name";
    protected override void initialize() {
        vm = new ReportSpaceVM();
        template = new GroupedSpaceTemplate(nameof(vm.Query), vm);
    }
}

﻿class RPnLJ : View
{
    public override string Icon => Icons.Periodic;
    public override FrameworkElement container => grid;
    Grid grid;
    public RPnLJ() {
        var receiptPayments = new ReportRPs();
        var leftOrJoined = new ReportLeftOrJoined();
        Grid.SetColumn(leftOrJoined, 1);
        grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){Width = new GridLength(1.25, GridUnitType.Star)},
                new ColumnDefinition()
            },
            Children = { receiptPayments, leftOrJoined }
        };
        AddVisualChild(grid);
    }
}

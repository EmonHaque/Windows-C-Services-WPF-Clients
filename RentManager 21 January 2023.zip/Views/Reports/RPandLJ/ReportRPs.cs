﻿class ReportRPs : CardView
{
    //public override string Icon => Icons.Periodic;
    public override string Header => "Receipt & Payments";

    TextBlock title, status;
    EditText search;
    DayPicker from, to;
    CommandButton refresh, print;
    ListBox entries;
    Grid entryGrid;
    ExpanderState expandState;
    DependencyPropertyDescriptor expandStateDescriptor;
    ReportRPsVM viewModel;

    public override void OnFirstSight() {
        base.OnFirstSight();
        viewModel = new ReportRPsVM();
        DataContext = viewModel;
        initializeUI();
        bind();

        expandStateDescriptor = DependencyPropertyDescriptor.FromProperty(ExpanderState.IsTrueProperty, typeof(ExpanderState));
        expandStateDescriptor.AddValueChanged(expandState, onExpandedChanged);
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Unloaded -= onUnloaded;
        expandStateDescriptor.RemoveValueChanged(expandState, onExpandedChanged);
    }

    void onExpandedChanged(object? sender, EventArgs e) {
        var items = Helper.FindVisualChildren<GroupItem>(entries);
        if (expandState.IsTrue) {
            foreach (GroupItem item in items) item.Tag = true;
            expandState.ToolTip = "Collapse";
        }
        else {
            foreach (GroupItem item in items) item.Tag = false;
            expandState.ToolTip = "Expand";
        }
    }

    void initializeUI() {
        search = new EditText() {
            Hint = "Search",
            Icon = Icons.Search,
            IsTrimBottomRequested = true
        };
        title = new TextBlock() {
            Text = "for the period",
            FontSize = 12,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 0, 5, 0)
        };
        from = new DayPicker() {
            Hint = "From",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true,
        };
        to = new DayPicker() {
            Hint = "To",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true,
        };
        refresh = new CommandButton() {
            Icon = Icons.Refresh,
            ToolTip = "Refresh",
            Command = viewModel.Refresh,
            Margin = new Thickness(5, 0, 0, 0)
        };
        print = new CommandButton() {
            Icon = Icons.Print,
            ToolTip = "Print",
            Command = viewModel.Print,
            Margin = new Thickness(5, 0, 0, 0)
        };
        Grid.SetColumn(title, 1);
        Grid.SetColumn(from, 2);
        Grid.SetColumn(to, 3);
        Grid.SetColumn(refresh, 4);
        Grid.SetColumn(print, 5);

        var headerGrid = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
            Children = { search, title, from, to, refresh, print }
        };
        initializeEntryGrid();
        Grid.SetRow(entryGrid, 1);
        var grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition()
                },
            Children = { headerGrid, entryGrid }
        };

        status = new TextBlock() { Margin = new Thickness(0, 0, 5, 0) };
        addActions(new UIElement[] { status });
        setContent(grid);
    }
    void initializeEntryGrid() {
        expandState = new ExpanderState() {
            Margin = new Thickness(0, 0, 5, 0),
            VerticalAlignment = VerticalAlignment.Center,
            ToolTip = "Expand"
        };
        var particulars = new TextBlock() { Text = "Particulars", HorizontalAlignment = HorizontalAlignment.Left };
        var cash = new TextBlock() { Text = "Cash" };
        var electronic = new TextBlock() { Text = "Mobile" };
        var kind = new TextBlock() { Text = "Kind" };
        var total = new TextBlock() { Text = "Total" };
        Grid.SetColumn(particulars, 1);
        Grid.SetColumn(cash, 2);
        Grid.SetColumn(electronic, 3);
        Grid.SetColumn(kind, 4);
        Grid.SetColumn(total, 5);
        var grid = new Grid() {
            Margin = new Thickness(2, 0, 5, 0),
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) }
             },
            Children = { expandState, particulars, cash, electronic, kind, total },
            Resources = {{
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold),
                                new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right)
                            }
                        }
                    }
                }
        };
        var header = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 2, 0, 2),
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
        Grid.SetColumnSpan(header, 4);
        entries = new ListBox() {
            ItemTemplate = new RPTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new GroupedRPTemplate())
                        },
                        Triggers = {
                            new MultiDataTrigger() {
                                Conditions = {
                                    new Condition(new Binding(nameof(CollectionViewGroup.IsBottomLevel)), true),
                                    new Condition(new Binding(nameof(CollectionViewGroup.ItemCount)), 1),
                                },
                                Setters = {
                                    new Setter(GroupItem.TemplateProperty, new GroupedRTSingleTemplate())
                                }
                            }
                        }
                    }
                }
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false)),
                        }
                    }
                }
            }
        };
        Grid.SetRow(entries, 1);
        Grid.SetColumnSpan(entries, 4);
        entryGrid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { header, entries }
        };
    }
    void bind() {
        status.SetBinding(TextBlock.TextProperty, new Binding(nameof(viewModel.Status)));
        from.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(viewModel.From)));
        from.SetBinding(DayPicker.ErrorProperty, new Binding(nameof(viewModel.ErrorFrom)));
        to.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(viewModel.To)));
        to.SetBinding(DayPicker.ErrorProperty, new Binding(nameof(viewModel.ErrorTo)));
        entries.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(viewModel.RPs)));
        search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.Query)) { Mode = BindingMode.OneWayToSource });
        refresh.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.IsRefreshValid)));
        print.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.IsPrintValid)));
    }
}

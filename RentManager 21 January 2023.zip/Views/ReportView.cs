﻿class ReportView : ViewContainer
{
    override public string Icon => Icons.Ledger;
    public ReportView() {
        Children.Add(new Balances());
        Children.Add(new ReportPlot());
        Children.Add(new ReportSpace());
        Children.Add(new ReportTenant());
        Children.Add(new RPnLJ());
        //Children.Add(new ReportRPs());
    }
}

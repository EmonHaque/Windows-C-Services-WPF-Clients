﻿class TenantDetail : CardView
{
    public override string Header => "Due & Payments";

    MultiBarchart bar;
    SelectItem tenant;
    BiState state;
    TextBlock deposit, status ;
    ActionButton refresh;
    TenantDetailVM viewModel;

    public override void OnFirstSight() {
        base.OnFirstSight();
        viewModel = new TenantDetailVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }
    void refreshCommand() {
        if (BusyWindow.IsOpened) return;
        var position = PointToScreen(new Point(0, 0));
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin;
        position.Y += Constants.CardMargin;
        var width = ActualWidth - 2 * Constants.CardMargin;
        var height = ActualHeight - 2 * Constants.CardMargin;

        BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
        viewModel.Refresh.Invoke();
        BusyWindow.Terminate();
    }
    void initializeUI() {
        status = new TextBlock() { 
            Margin = new Thickness(0, 0, 10, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        state = new BiState() {
            Text = "Existing",
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(0, 0, 5, 0)
        };
        refresh = new ActionButton() {
            Command = refreshCommand,
            Icon = Icons.Refresh,
            ToolTip = "Reload",
            Focusable = false
        };
        addActions(new UIElement[] { status, state, refresh });
        tenant = new SelectItem() {
            Hint = "Tenant",
            IsRequired = true,
            Icon = Icons.Tenant,
            SelectedValuePath = nameof(Tenant.Id),
            ItemTemplate = new TenantTemplate(nameof(viewModel.Query), viewModel)
        };

        deposit = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 0, 10, 0),
            FontStyle = FontStyles.Italic
        };
        bar = new MultiBarchart();
        Grid.SetRow(deposit, 1);
        Grid.SetRow(bar, 2);
        var grid = new Grid() {
            Margin = new Thickness(0,5,0,0),
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
            Children = { tenant, deposit, bar }
        };
        setContent(grid);
    }
    void bind() {
        status.SetBinding(TextBlock.TextProperty, new Binding(nameof(viewModel.Status)));
        bar.SetBinding(MultiBarchart.ItemSourceProperty, new Binding(nameof(viewModel.Data)));
        refresh.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.IsRefreshvalid)));

        tenant.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(viewModel.SelectedTenant)));
        //tenant.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorTenantId)));
        tenant.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.Tenants)));
        tenant.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.Query)) { Mode = BindingMode.OneWayToSource });
        state.SetBinding(BiState.IsTrueProperty, new Binding(nameof(viewModel.State)));
        deposit.SetBinding(TextBlock.TextProperty, new Binding(nameof(viewModel.Deposit)));
    }
}

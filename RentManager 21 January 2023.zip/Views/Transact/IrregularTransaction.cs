﻿class IrregularTransaction : TransactionBase
{
    public override string Icon => Icons.IrregularTransaction;
    public override string Header => "Irregular";

    IrregularTransactionVM vm = new();
    protected override TransactionBaseVM viewModel => vm;
    protected override string plotSelectedValuePath => nameof(Plot.Id);
    protected override string plotDisplayMemberPath => nameof(Plot.Name);

    protected override void setSpace() {
        space.SelectedValuePath = nameof(Space.Id);
        space.DisplayPath = nameof(Space.Name);
    }
}

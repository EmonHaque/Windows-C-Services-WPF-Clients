﻿class TransactionView : View
{
    public override string Icon => Icons.Transact;
    public override FrameworkElement container => grid;
    Grid grid;
    public TransactionView() : base() {
        var rent = new BulkRentTransaction();
        var transactions = new ViewContainer() {
            Children = {
                new RegularTransaction(),
                new IrregularTransaction()
            }
        };
        Grid.SetColumn(transactions, 1);
        grid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(){Width = new GridLength(1, GridUnitType.Star)},
                    new ColumnDefinition(){Width = new GridLength(2, GridUnitType.Star)},
                },
            Children = { rent, transactions }
        };
        AddVisualChild(grid);
    }
}

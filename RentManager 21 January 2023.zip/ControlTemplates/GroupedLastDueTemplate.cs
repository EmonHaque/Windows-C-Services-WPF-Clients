﻿class GroupedLastDueTemplate : ControlTemplate
{
    Dictionary<string, bool> expandStates = new();

    public GroupedLastDueTemplate() {
        TargetType = typeof(GroupItem);
        var expander = new FrameworkElementFactory(typeof(Expander));
        var border = new FrameworkElementFactory(typeof(Border));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));

        expander.SetValue(Expander.TemplateProperty, new ExpanderTemplate());
        expander.SetValue(Expander.HeaderTemplateProperty, new HeaderTeamplate());
        expander.SetValue(Expander.IsExpandedProperty, true);

        border.SetValue(Border.BorderBrushProperty, Brushes.LightGray);
        border.SetValue(Border.BorderThicknessProperty, new Thickness(0, 0.25, 0, 0.25));

        border.AppendChild(items);
        expander.AppendChild(border);
        VisualTree = expander;
    }

    class HeaderTeamplate : DataTemplate
    {
        public HeaderTeamplate() {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var header = new FrameworkElementFactory(typeof(TextBlock));
            var totals = new FrameworkElementFactory(typeof(ContentControl));

            col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(2 * 70));
            totals.SetValue(Grid.ColumnProperty, 1);
            header.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);

            var source = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1);
            header.SetBinding(TextBlock.TextProperty, new Binding("DataContext." + nameof(GroupItem.Name)) {
                Mode = BindingMode.OneWay,
                RelativeSource = source
            });
            totals.SetValue(ContentControl.ContentTemplateProperty, new SummaryTemplate());
            totals.SetBinding(ContentControl.ContentProperty, new Binding("DataContext") {
                RelativeSource = source,
                Converter = new SummaryConverter(),
                Mode = BindingMode.OneWay
            });

            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(header);
            grid.AppendChild(totals);

            VisualTree = grid;
        }

        class SummaryTemplate : DataTemplate
        {
            public SummaryTemplate() {
                var grid = new FrameworkElementFactory(typeof(Grid));
                var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
                var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
                var security = new FrameworkElementFactory(typeof(TextBlock));
                var due = new FrameworkElementFactory(typeof(TextBlock));

                col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
                col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
                due.SetValue(Grid.ColumnProperty, 1);
                
                due.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
                security.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
                due.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
                security.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);

                security.SetBinding(TextBlock.TextProperty, new Binding("Item1") { StringFormat = Constants.NumberFormat });
                due.SetBinding(TextBlock.TextProperty, new Binding("Item2") { StringFormat = Constants.NumberFormat });

                grid.AppendChild(col1);
                grid.AppendChild(col2);
                grid.AppendChild(security);
                grid.AppendChild(due);

                VisualTree = grid;
            }
        }

        class SummaryConverter : IValueConverter
        {
            public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
                var group = (CollectionViewGroup)value;
                var items = group.Items.OfType<LastDue>();
                int security = 0, due = 0;
                foreach (var item in items) {
                    security += item.Security;
                    due += item.Due;
                }
                return new Tuple<int, int>(security, due);
            }

            public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
                throw new NotImplementedException();
            }
        }
    }
}

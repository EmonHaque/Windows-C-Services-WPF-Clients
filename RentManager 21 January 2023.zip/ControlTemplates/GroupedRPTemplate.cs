﻿class GroupedRPTemplate : ControlTemplate
{
    Dictionary<string, bool> expandStates = new();

    public GroupedRPTemplate() {
        TargetType = typeof(GroupItem);
        var expander = new FrameworkElementFactory(typeof(Expander));
        var border = new FrameworkElementFactory(typeof(Border));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));

        expander.SetValue(Expander.TemplateProperty, new ExpanderTemplate());
        expander.SetValue(Expander.HeaderTemplateProperty, new RPHeaderTemplate());
        border.SetValue(Border.BorderBrushProperty, Brushes.LightGray);
        expander.SetBinding(Expander.IsExpandedProperty, new Binding(nameof(Expander.Tag)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(GroupItem), 1),
            TargetNullValue = false
        });
        border.SetBinding(Border.BorderThicknessProperty, new Binding() {
            Mode = BindingMode.OneWay,
            Converter = Converters.cvgBorderThickness
        });
        border.AppendChild(items);
        expander.AppendChild(border);
        VisualTree = expander;

        expander.AddHandler(Expander.LoadedEvent, new RoutedEventHandler(onExpanderLoaded));
        expander.AddHandler(Expander.ExpandedEvent, new RoutedEventHandler(onIsExpandChanged));
        expander.AddHandler(Expander.CollapsedEvent, new RoutedEventHandler(onIsExpandChanged));
        expander.AddHandler(Expander.UnloadedEvent, new RoutedEventHandler(onExpanderUnloaded));
    }

    void onExpanderLoaded(object sender, RoutedEventArgs e) {
        var expander = (Expander)sender;
        var context = (CollectionViewGroup)expander.DataContext;

        var group = context.Name.ToString();
        if (expandStates.ContainsKey(group)) {
            expander.IsExpanded = expandStates[group];
        }
        else expandStates.Add(group, expander.IsExpanded);
    }
    void onIsExpandChanged(object sender, RoutedEventArgs e) {
        var expander = (Expander)sender;
        var context = (CollectionViewGroup)expander.DataContext;
        var group = context.Name.ToString();
        expandStates[group] = expander.IsExpanded;
    }
    void onExpanderUnloaded(object sender, RoutedEventArgs e) {
        var expander = (Expander)sender;
        expander.RemoveHandler(Expander.LoadedEvent, (RoutedEventHandler)onExpanderLoaded);
        expander.RemoveHandler(Expander.ExpandedEvent, (RoutedEventHandler)onIsExpandChanged);
        expander.RemoveHandler(Expander.CollapsedEvent, (RoutedEventHandler)onIsExpandChanged);
        expander.RemoveHandler(Expander.UnloadedEvent, (RoutedEventHandler)onExpanderUnloaded);
    }
}
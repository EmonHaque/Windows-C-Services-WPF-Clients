﻿class GroupedLastPaymentTemplate : ControlTemplate
{
    public GroupedLastPaymentTemplate() {
        TargetType = typeof(GroupItem);
        var expander = new FrameworkElementFactory(typeof(Expander));
        var border = new FrameworkElementFactory(typeof(Border));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));

        expander.SetValue(Expander.TemplateProperty, new ExpanderTemplate());
        expander.SetValue(Expander.HeaderTemplateProperty, new HeaderTeamplate());
        expander.SetValue(Expander.IsExpandedProperty, true);

        border.SetValue(Border.BorderBrushProperty, Brushes.LightGray);
        border.SetValue(Border.BorderThicknessProperty, new Thickness(0, 0.25, 0, 0.25));

        border.AppendChild(items);
        expander.AppendChild(border);
        VisualTree = expander;
    }

    class HeaderTeamplate : DataTemplate
    {
        public HeaderTeamplate() {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var header = new FrameworkElementFactory(typeof(TextBlock));
            var total = new FrameworkElementFactory(typeof(TextBlock));

            col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
            total.SetValue(Grid.ColumnProperty, 1);
            total.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
            total.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            header.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);

            var source = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1);
            header.SetBinding(TextBlock.TextProperty, new Binding("DataContext." + nameof(GroupItem.Name)) {
                Mode = BindingMode.OneWay,
                RelativeSource = source
            });
           
            total.SetBinding(TextBlock.TextProperty, new Binding("DataContext") {
                RelativeSource = source,
                Converter = new SummaryConverter(),
                Mode = BindingMode.OneWay,
                StringFormat = Constants.NumberFormat
            });

            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(header);
            grid.AppendChild(total);

            VisualTree = grid;
        }

        class SummaryConverter : IValueConverter
        {
            public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
                var group = (CollectionViewGroup)value;
                var items = group.Items.OfType<LastPayment>();
                return items.Sum(x => x.Amount);
            }

            public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
                throw new NotImplementedException();
            }
        }
    }
}

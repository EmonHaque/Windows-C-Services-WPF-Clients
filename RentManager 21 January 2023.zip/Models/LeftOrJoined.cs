﻿class LeftOrJoined
{
    public string Status { get; set; }
    public string Plot { get; set; }
    public string Space { get; set; }
    public string Tenant { get; set; }
    public int Receivable { get; set; }
    public string DateStart { get; set; }
    public string DateEnd { get; set; }
}

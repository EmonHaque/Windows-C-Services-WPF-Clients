﻿class LastDue
{
    public string Plot { get; set; }
    public string Space { get; set; }
    public int Security { get; set; }
    public int Due { get; set; }
}

﻿class LastPayment
{
    public string Plot { get; set; }
    public string Space { get; set; }
    public int Amount { get; set; }
    public int IsCash { get; set; }
}

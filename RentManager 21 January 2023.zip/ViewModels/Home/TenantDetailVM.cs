﻿class TenantDetailVM : Notifiable
{
    bool isSelectedByUser;
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value?.Trim().ToLower();
                Tenants.Refresh();
            }
        }
    }
    int? selectedTenant;
    public int? SelectedTenant {
        get { return selectedTenant; }
        set {
            if (selectedTenant != value) {
                selectedTenant = value;
                onTenatChanged(value);
            }
        }
    }
    bool state;
    public bool State {
        get { return state; }
        set {
            if (state != value) {
                state = value;
                Tenants.Refresh();
                if (isSelectedByUser) isSelectedByUser = false;
                else {
                    SelectedTenant = Tenants.CurrentItem == null ? null : ((Tenant)Tenants.CurrentItem).Id;
                    OnPropertyChanged(nameof(SelectedTenant));
                }
            }
        }
    }
    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }
    public List<RentPayment> Data { get; set; }
    public Action Refresh { get; set; }
    public bool IsRefreshvalid { get; set; }
    public ICollectionView Tenants { get; set; }
    public string Deposit { get; set; }

    public TenantDetailVM() {
        Tenants = new CollectionViewSource() { Source = AppData.tenants }.View;
        Tenants.Filter = filterTenants;
        RentDetailVM.SelectionChanged += setTenant; ;
        Refresh = () => onTenatChanged(SelectedTenant);
        State = true;
    }

    void setTenant(int? o) {
        if (!State) {
            isSelectedByUser = true;
            State = true;
            OnPropertyChanged(nameof(State));
        }
        SelectedTenant = o;
        OnPropertyChanged(nameof(SelectedTenant));
    }
    bool filterTenants(object o) {
        var tenant = (Tenant)o;
        switch (State) {
            case true:
                return string.IsNullOrWhiteSpace(Query) ? true && !tenant.HasLeft : tenant.Name.ToLower().Contains(Query) && !tenant.HasLeft;
            case false:
                return string.IsNullOrWhiteSpace(Query) ? true && tenant.HasLeft : tenant.Name.ToLower().Contains(Query) && tenant.HasLeft;
        }
    }
    async Task onTenatChanged(int? id) {
        if (SelectedTenant == null) {
            Data = null;
            IsRefreshvalid = false;
            Deposit = null;
            OnPropertyChanged(nameof(IsRefreshvalid));
            OnPropertyChanged(nameof(Data));
            OnPropertyChanged(nameof(Deposit));
            return;
        }
        Status = "requesting data";
        await Task.Delay(250);
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetTenantDetail,
            Bytes = new List<ArraySegment<byte>>() {
                BitConverter.GetBytes(id.Value)
            }
        };
        var response = await App.service.GetResponse(request);
        Status = "received " + response.Packet.Length.ToString("N0") + " bytes";
        await Task.Delay(250);
        if (!response.IsSuccess) {
            Status = LocalConstants.DownMessage;
            return;
        }
        Deposit = "Deposit " + BitConverter.ToInt32(response.Packet).ToString("N0");
        Data = await Task.Run(response.Packet.ToRentPayments).ConfigureAwait(false);

        IsRefreshvalid = true;
        OnPropertyChanged(nameof(Deposit));
        OnPropertyChanged(nameof(IsRefreshvalid));
        OnPropertyChanged(nameof(Data));
    }
}

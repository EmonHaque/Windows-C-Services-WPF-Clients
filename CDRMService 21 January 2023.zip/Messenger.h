#pragma once
#include <WinSock2.h>

int sendString(SOCKET, char*);
int sendByte(SOCKET, byte);
int sendInt(SOCKET, int);
int sendDouble(SOCKET, double);

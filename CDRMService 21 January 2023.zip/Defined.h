#pragma once

#define POINTER_SIZE sizeof(void*)
#define SENDER_SIZE sizeof(Sender)
#define RECEIVER_SIZE sizeof(Receiver)
#define REQUEST_SIZE sizeof(Request)
#define RESPONSE_PERSONAL_SIZE sizeof(ResponsePersonal)
#define RESPONSE_PUBLIC_SIZE sizeof(ResponsePublic)
#define SHORT_MESSAGE_SIZE sizeof(ShortMessage)

#define SITE_SIZE sizeof(Site)
#define PARTY_SIZE sizeof(Party)
#define HEAD_SIZE sizeof(Head)
#define SUBHEAD_SIZE sizeof(Subhead)
#define UNIT_SIZE sizeof(Unit)
#define NOTE_TYPE_SIZE sizeof(NoteType)
#define NOTE_SIZE sizeof(Note)
#define REPORT_ENTRY_SIZE sizeof(ReportEntry)
#define REPORT_DATE_SIZE sizeof(ReportDates)
#define SUM_TRANSACTION_SIZE sizeof(SumTransaction)
#define DUE_SIZE sizeof(Due)
#define RECEIPT_PAYMENT_SIZE sizeof(ReceiptPayment)

typedef unsigned char byte;
typedef unsigned int uint;
typedef unsigned long ulong;

typedef void Action();
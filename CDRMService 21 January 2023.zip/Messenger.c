#include "Messenger.h"

int sendString(SOCKET s, char* str) {
	int length = strlen(str) + 1;
	int sent = 0, offset = 0;
	do {
		sent = send(s, &str[offset], length, 0);
		if (sent == SOCKET_ERROR) return SOCKET_ERROR;
		length -= sent;
		offset += sent;
	} while (length > 0);
	return 0;
}
int sendByte(SOCKET s, byte val) {
	int sent = send(s, &val, 1, 0);
	if (sent == SOCKET_ERROR) return SOCKET_ERROR;
	return 0;
}
int sendInt(SOCKET s, int val) {
	char* ptr = &val;
	int length = sizeof(int);
	int sent = 0, offset = 0;
	do {
		sent = send(s, &ptr[offset], length, 0);
		if (sent == SOCKET_ERROR) return SOCKET_ERROR;
		length -= sent;
		offset += sent;
	} while (length > 0);
	return 0;
}
int sendDouble(SOCKET s, double val) {
	char* ptr = &val;
	int length = sizeof(double);
	int sent = 0, offset = 0;
	do {
		sent = send(s, &ptr[offset], length, 0);
		if (sent == SOCKET_ERROR) return SOCKET_ERROR;
		length -= sent;
		offset += sent;
	} while (length > 0);
	return 0;
}
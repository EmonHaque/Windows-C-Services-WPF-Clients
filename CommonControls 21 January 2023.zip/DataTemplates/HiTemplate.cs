﻿public class HiTemplate : DataTemplate
{
    public HiTemplate(string property, string query, object viewModel) {
        var block = new FrameworkElementFactory(typeof(HiBlock));
        block.SetBinding(HiBlock.TextProperty, new Binding(property));
        block.SetBinding(HiBlock.QueryProperty, new Binding(query) { Source = viewModel, IsAsync = true });
        VisualTree = block;
    }
}

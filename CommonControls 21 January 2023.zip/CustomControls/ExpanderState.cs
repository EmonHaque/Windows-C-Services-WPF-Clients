﻿public class ExpanderState : Border
{
    Path icon;
    SolidColorBrush brush;
    Color normalColor, highlightColor, downColor;
    ColorAnimation anim;
    Geometry trueGeo, falseGeo;

    public string TrueIcon { get; set; }
    public string FalseIcon { get; set; }

    public ExpanderState() {
        normalColor = Colors.LightGray;
        highlightColor = Colors.CornflowerBlue;
        downColor = Colors.LightGreen;
        brush = new SolidColorBrush(normalColor);
        icon = new Path() {
            Stretch = Stretch.Uniform,
            Fill = brush,
            VerticalAlignment = VerticalAlignment.Center
        };
        Child = icon;
        anim = new ColorAnimation() {
            Duration = TimeSpan.FromMilliseconds(250),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        Background = Brushes.Transparent;
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        if (TrueIcon == null) TrueIcon = Icons.Plus;
        if (FalseIcon == null) FalseIcon = Icons.Minus;
        trueGeo = Geometry.Parse(TrueIcon);
        falseGeo = Geometry.Parse(FalseIcon);
        icon.Data = IsTrue ? trueGeo : falseGeo;
        if (double.IsNaN(Width)) icon.Width = icon.Height = 12; 
    }
    void animateBrush(Color c) {
        anim.To = c;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
    }
    protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) => IsTrue = !IsTrue;
    protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);
    protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);

    public bool IsTrue {
        get { return (bool)GetValue(IsTrueProperty); }
        set { SetValue(IsTrueProperty, value); }
    }
    public static readonly DependencyProperty IsTrueProperty =
        DependencyProperty.Register("IsTrue", typeof(bool), typeof(ExpanderState), new PropertyMetadata() {
            PropertyChangedCallback = (s, e) => {
                var o = (ExpanderState)s;
                o.icon.Data = (bool)e.NewValue ? o.trueGeo : o.falseGeo;
            }
        });
}

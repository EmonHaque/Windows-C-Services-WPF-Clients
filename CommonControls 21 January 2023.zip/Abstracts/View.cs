﻿public abstract class View : FrameworkElement, IHaveIcon
{
    public bool IsFirstSight { get; set; } = true;
    public virtual string Icon { get; }
    public abstract FrameworkElement container { get; }
    public virtual void OnFirstSight() { 
        IsFirstSight = false;
        SetCard();
    }
    protected virtual void SetCard() { }
    protected override Size MeasureOverride(Size availableSize) {
        if (container is null) return availableSize;
        container.Measure(availableSize);
        return container.DesiredSize;
    }
    protected override Size ArrangeOverride(Size finalSize) {
        if(container is not null)
            container.Arrange(new Rect(container.DesiredSize));
        return finalSize;
    }
    protected override Visual GetVisualChild(int index) => container;
    protected override int VisualChildrenCount => 1;
}

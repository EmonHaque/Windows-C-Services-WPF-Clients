﻿public class ActionButton : Border
{
    string icon;
    public string Icon {
        get { return icon; }
        set { icon = value; ((Path)Child).Data = Geometry.Parse(value); }
    }
    public Action Command { get; set; }
    protected SolidColorBrush brush;
    protected ColorAnimation anim;
    protected Color normalColor, highlightColor, downColor, disabledColor;
    public ActionButton() {
        normalColor = Colors.LightGray;
        disabledColor = Colors.Gray;
        highlightColor = Colors.CornflowerBlue;
        downColor = Colors.Coral;
        brush = new SolidColorBrush(normalColor);

        FocusVisualStyle = null;
        Background = Brushes.Transparent;
        Width = Height = 12;
        VerticalAlignment = VerticalAlignment.Center;
        Child = new Path() {
            Fill = brush,
            Stretch = Stretch.Uniform
        };
        anim = new ColorAnimation() {
            Duration = TimeSpan.FromSeconds(0.5),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        IsEnabledChanged += onEnabledChanged;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        IsEnabledChanged -= onEnabledChanged;
        Unloaded -= onUnloaded;
    }
    void onEnabledChanged(object sender, DependencyPropertyChangedEventArgs e) {
        if (!Application.Current.MainWindow.IsEnabled) return;
        if (IsEnabled) {
            Dispatcher.InvokeAsync(() => animateBrush(normalColor), DispatcherPriority.Background);
        }
        else {
            Dispatcher.InvokeAsync(() => animateBrush(disabledColor), DispatcherPriority.Background);
        }
    }

    protected void animateBrush(Color color) {
        anim.To = color;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
    }
    protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
    protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);
    protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
        if (IsMouseOver) animateBrush(highlightColor);
        Command.Invoke();
    }
}

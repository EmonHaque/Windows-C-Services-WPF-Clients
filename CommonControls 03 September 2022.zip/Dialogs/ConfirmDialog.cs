﻿public class ConfirmDialog : Window
{
    TextBlock titleText, messageText;
    Grid content;
    DoubleAnimation anim;
    string title;
    public new string Title {
        get { return title; }
        set { title = value; titleText.Text = value; }
    }
    string message;
    public string Message {
        get { return message; }
        set { message = value; messageText.Text = value; }
    }
    public static bool IsOk { get; set; }

    ConfirmDialog() {
        Owner = Application.Current.MainWindow;
        Width = Owner.ActualWidth;
        Height = Owner.ActualHeight;
        ResizeMode = ResizeMode.NoResize;
        WindowStyle = WindowStyle.None;
        WindowState = Owner.WindowState == WindowState.Maximized ? WindowState.Maximized : WindowState.Normal;
        AllowsTransparency = true;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        ShowInTaskbar = false;
        Background = new SolidColorBrush(Color.FromArgb(127, 0, 0, 0));

        var titleBar = new Border() {
            Background = new SolidColorBrush(Color.FromRgb(60, 60, 60)),
            Child = new TextBlock() {
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 32,
                Margin = new Thickness(10, 0, 0, 0),
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.White
            }
        };
        titleText = (TextBlock)titleBar.Child;

        var okButton = new ActionButton() {
            Width = 24,
            Height = 24,
            Margin = new Thickness(10),
            Icon = Icons.Checked,
            HorizontalAlignment = HorizontalAlignment.Left,
            Command = () => {
                scaleDown();
                IsOk = true;
            }
        };
        var cancelButton = new ActionButton() {
            Width = 24,
            Height = 24,
            Margin = new Thickness(10),
            Icon = Icons.CloseCircle,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = () => {
                scaleDown();
                IsOk = false;
            }
        };
        Grid.SetRow(okButton, 1);
        Grid.SetRow(cancelButton, 1);

        messageText = new TextBlock() {
            VerticalAlignment = VerticalAlignment.Center,
            FontSize = 16,
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(10)
        };

        content = new Grid() {
            Background = new SolidColorBrush(Color.FromRgb(50, 50, 50)),
            RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition(){Height = GridLength.Auto}
                },
            Children = { messageText, okButton, cancelButton }
        };
        Grid.SetRow(content, 1);
        var contentGrid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
            Children = { titleBar, content }
        };
        Grid.SetRow(contentGrid, 1);
        Content = new Grid() {
            Effect = new DropShadowEffect() { BlurRadius = 30, ShadowDepth = 0, RenderingBias = RenderingBias.Quality },
            RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
            Children = { contentGrid }
        };
        anim = new DoubleAnimation() {
            Duration = TimeSpan.FromSeconds(0.5),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };

        Loaded += scaleUp;
    }
    public static void Activate(string title, string message) {
        var window = new ConfirmDialog() {
            Title = title,
            Message = message
        };
        window.ShowDialog();
    }
    void scaleDown() {
        anim.Completed += onAnimationCompleted;
        anim.To = 0;
        anim.From = ActualHeight;
        BeginAnimation(HeightProperty, anim);
    }

    void onAnimationCompleted(object sender, EventArgs e) {
        anim.Completed -= onAnimationCompleted;
        DialogResult = IsOk;
    }

    void scaleUp(object sender, RoutedEventArgs e) {
        RenderTransform = new ScaleTransform();
        anim.From = 0;
        RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
    }
    protected override void OnClosed(EventArgs e) {
        Loaded -= scaleUp;
    }
}

﻿public abstract class CardView : View
{
    public virtual string Header { get; }
    public override FrameworkElement container => card;
    protected Card card;

    protected override void SetCard() {
        card = new Card() { Header = Header };
        AddVisualChild(card);
        KeyboardNavigation.SetTabNavigation(this, KeyboardNavigationMode.Cycle);
        FocusManager.SetIsFocusScope(this, true);

        InvalidateMeasure();
        InvalidateArrange();
    }
    protected void setContent(FrameworkElement element) => card.Content = element;
    protected void addActions(ActionButton action) => card.AddActions(action);
    protected void addActions(UIElement[] actions) => card.AddActions(actions);
}

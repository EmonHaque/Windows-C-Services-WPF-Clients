#pragma once
#include <WS2tcpip.h>
#include "Structures.h"
#include "BlockingQueue.h"

extern int maxAttemptId;
extern BlockingQueue attempts, logouts;

void initializeDatabase();
int mallocate(char*, char**);
Login* getLogin(char*, char*);
int getAppId(char*);
int getAddressId(char*);
Client* getClient(SOCKET);
char* getTime();
char* getDate();

﻿class EditTenantVM : EditBase<Tenant>
{
    bool isEqual;
    string filterName;
    public string FilterName {
        get { return filterName; }
        set {
            if (filterName != value) {
                filterName = value?.Trim().ToLower();
                Editables.Refresh();
            }
        }
    }
    byte filterState;
    public byte FilterState {
        get { return filterState; }
        set {
            if (filterState != value) {
                filterState = value;
                Editables.Refresh();
            }
        }
    }
    DateTime? leftOn;
    public DateTime? LeftOn {
        get { return leftOn; }
        set {
            if (leftOn != value) {
                leftOn = value;
                validateLeftOn();
            }
        }
    }

    public string ErrorName { get; set; }
    public string ErrorFather { get; set; }
    public string ErrorAddress { get; set; }
    public string ErrorContactNo { get; set; }
    public string ErrorLeftOn { get; set; }
    public bool IsValid { get; set; }
    public ICollectionView Leases { get; set; }
    
    public EditTenantVM() {
        Editables = new CollectionViewSource() {
            Source = AppData.tenants,
            IsLiveFilteringRequested = true,
            LiveFilteringProperties = { nameof(Tenant.HasLeft) },
            IsLiveSortingRequested = true,
            LiveSortingProperties = { nameof(Tenant.Name) }
        }.View;
        Leases = new CollectionViewSource() { Source = AppData.leases }.View;
        Editables.SortDescriptions.Add(new SortDescription(nameof(Tenant.Name), ListSortDirection.Ascending));
        Editables.Filter = filterTenants;
        Leases.Filter = (o) => Selected == null ? false : (o as Lease).TenantId == Selected.Id;
        FilterState = 0;
    }

    #region validation rules
    void validateName() {
        ErrorName = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Name))
            ErrorName = "Name is required";
        else {
            if (!string.Equals(Selected.Name, Edited.Name, StringComparison.OrdinalIgnoreCase)) {
                for (int i = 0; i < AppData.tenants.Count; i++) {
                    if (string.Equals(AppData.tenants[i].Name, Edited.Name, StringComparison.OrdinalIgnoreCase))
                        ErrorName = "Name exists";
                }
            }
        }
        OnPropertyChanged(nameof(ErrorName));
    }
    void validateFather() {
        ErrorFather = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Father))
            ErrorFather = "Father is required";
        OnPropertyChanged(nameof(ErrorFather));
    }
    void validateAddress() {
        ErrorAddress = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Address))
            ErrorAddress = "Address is required";
        OnPropertyChanged(nameof(ErrorAddress));
    }
    void validateContactNo() {
        ErrorContactNo = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.ContactNo))
            ErrorContactNo = "phone is required";
        OnPropertyChanged(nameof(ErrorContactNo));
    }
    void validateLeftOn() {
        ErrorLeftOn = string.Empty;
        if (Edited.HasLeft) {
            if (LeftOn == null)
                ErrorLeftOn = " is required";
            else {
                var leases = AppData.leases.Where(x => x.TenantId == Edited.Id && !x.IsExpired).ToList();
                if (leases.Count > 0) {
                    foreach (var lease in leases) {
                        if (Nullable.Compare(LeftOn, lease.DateStart) <= 0) {
                            ErrorLeftOn = " must be later than Lease start date";
                        }
                    }
                }
            }
        }
        OnPropertyChanged(nameof(ErrorLeftOn));
        checkValidity();
    }
    void checkValidity() {
        IsValid =
            !isEqual &&
            ErrorName == string.Empty &&
            ErrorFather == string.Empty &&
            ErrorAddress == string.Empty &&
            ErrorContactNo == string.Empty &&
            ErrorLeftOn == string.Empty;
        OnPropertyChanged(nameof(IsValid));
    }
    #endregion

    bool filterTenants(object o) {
        if (AppData.tenants.Count > 0) {
            var tenant = (o as Tenant);
            switch (FilterState) {
                case 0:
                    return string.IsNullOrWhiteSpace(FilterName) ? true && !tenant.HasLeft : tenant.Name.ToLower().Contains(FilterName) && !tenant.HasLeft;
                case 1:
                    return string.IsNullOrWhiteSpace(FilterName) ? true && tenant.HasLeft : tenant.Name.ToLower().Contains(FilterName) && tenant.HasLeft;
                default:
                    return string.IsNullOrWhiteSpace(FilterName) ? true : tenant.Name.ToLower().Contains(FilterName);
            }
        }
        return false;
    }

    #region base implementation  
    protected override string errorTitle => "Tenant";
    protected override Function function => Function.EditTenant;
    protected override List<ArraySegment<byte>> bytes {
        get {
            string leftOn = "";
            if (Edited.HasLeft && !Selected.HasLeft) {
                leftOn = LeftOn.Value.ToString("yyyy-MM-dd");
            }
            return Edited.ToBytes(leftOn);
        }
    }
    protected override Tenant clone() {
        return new Tenant() {
            Id = Selected.Id,
            Name = Selected.Name,
            Father = Selected.Father,
            Mother = Selected.Mother,
            Husband = Selected.Husband,
            Address = Selected.Address,
            NID = Selected.NID,
            ContactNo = Selected.ContactNo,
            HasLeft = Selected.HasLeft
        };
    }
    protected override void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Tenant.Name): validateName(); break;
            case nameof(Tenant.Father): validateFather(); break;
            case nameof(Tenant.Address): validateAddress(); break;
            case nameof(Tenant.ContactNo): validateContactNo(); break;
            case nameof(Tenant.HasLeft): validateLeftOn(); break;
        }
        isEqual =
            string.Equals(Selected.Name, Edited.Name, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.Father, Edited.Father, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.Mother, Edited.Mother, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.Husband, Edited.Husband, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.Address, Edited.Address, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.NID, Edited.NID, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.ContactNo, Edited.ContactNo, StringComparison.OrdinalIgnoreCase) &&
            Selected.HasLeft == Edited.HasLeft;
        checkValidity();
    }
    protected override void setValidationProperties() {
        isEqual = true;
        IsValid = false;
        ErrorName =
        ErrorFather =
        ErrorAddress =
        ErrorContactNo =
        ErrorLeftOn = string.Empty;
        OnPropertyChanged(nameof(ErrorName));
        OnPropertyChanged(nameof(ErrorFather));
        OnPropertyChanged(nameof(ErrorAddress));
        OnPropertyChanged(nameof(ErrorContactNo));
        OnPropertyChanged(nameof(ErrorLeftOn));
        OnPropertyChanged(nameof(IsValid));
    }
    #endregion
}

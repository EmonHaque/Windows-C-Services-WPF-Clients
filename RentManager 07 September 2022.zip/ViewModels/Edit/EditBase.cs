﻿using static System.Windows.Forms.VisualStyles.VisualStyleElement;

abstract class EditBase<T> : Notifiable where T : Notifiable, new()
{
    bool isOnEdit;
    public bool IsOnEdit {
        get { return isOnEdit; }
        set { isOnEdit = value; OnPropertyChanged(nameof(IsOnEdit)); }
    }
    T selected;
    public T Selected {
        get { return selected; }
        set {
            selected = value;
            OnPropertyChanged(nameof(Selected));
            if (IsOnEdit) resetIsOnEdit();
        }
    }
    T edited;
    public T Edited {
        get { return edited; }
        set { edited = value; OnPropertyChanged(nameof(Edited)); }
    }
    public ICollectionView Editables { get; set; }
    public Action SetIsOnEdit { get; set; }
    public Action ResetIsOnEdit { get; set; }
    public Action Save { get; set; }

    public EditBase() {
        SetIsOnEdit = setOnEdit;
        ResetIsOnEdit = resetIsOnEdit;
        Save = saveAndUpdate;
    }
    protected abstract Function function { get; }
    protected abstract List<ArraySegment<byte>> bytes { get; }
    protected abstract string errorTitle { get; }
    protected abstract T clone();
    protected abstract void validate(object sender, PropertyChangedEventArgs e);
    protected abstract void setValidationProperties();
    protected virtual void setStatesOnClone() { }
    void setOnEdit() {
        if (Selected != null) {
            Edited = clone();
            setStatesOnClone();
            setValidationProperties();
            Edited.PropertyChanged += validate;
            IsOnEdit = true;
        }
    }
    protected void resetIsOnEdit() {
        Edited.PropertyChanged -= validate;
        setValidationProperties();
        IsOnEdit = false;
    }
    async void saveAndUpdate() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)function,
            Bytes = bytes
        };
        var response = await App.service.GetResponse(request); // real response will be handled by Receiver
        handleResponse(response, errorTitle);
        resetIsOnEdit();
    }

    protected void handleResponse(Response response, string header) {
        if (response.IsSuccess) {
            var isSuccess = BitConverter.ToBoolean(response.Packet);
            if (!isSuccess) {
                var message = Encoding.ASCII.GetString(response.Packet.Skip(1).ToArray());
                InfoDialog.Activate(header, message);
            }
        }
        else {
            InfoDialog.Activate("Service", "Couldn't connect to service, try restrating the Application");
        }
    }
}

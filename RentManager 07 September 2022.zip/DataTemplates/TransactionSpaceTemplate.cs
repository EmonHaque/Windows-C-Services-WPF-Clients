﻿class TransactionSpaceTemplate : DataTemplate
{
    public TransactionSpaceTemplate(string queryProperty, object viewModel) {
        var panel = new FrameworkElementFactory(typeof(DockPanel));
        var space = new FrameworkElementFactory(typeof(HiBlock));
        var date = new FrameworkElementFactory(typeof(TextBlock));

        panel.SetValue(DockPanel.BackgroundProperty, Brushes.Transparent);
        panel.SetValue(DockPanel.ToolTipProperty, new LeaseTip());
        date.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        date.SetBinding(TextBlock.TextProperty, new Binding(nameof(Lease.DateStart)) { StringFormat = "dd MMM yyyy" });
        space.SetBinding(HiBlock.TextProperty, new Binding(nameof(Lease.SpaceName)));
        space.SetBinding(HiBlock.QueryProperty, new Binding(queryProperty) { Source = viewModel, IsAsync = true });
        panel.AppendChild(space);
        panel.AppendChild(date);

        Triggers.Add(new DataTrigger() {
            Binding = new Binding(nameof(Lease.IsExpired)),
            Value = true,
            Setters = {
                    new Setter(TextElement.FontStyleProperty, FontStyles.Italic),
                    new Setter(TextElement.ForegroundProperty, Brushes.Gray)
                }
        });

        VisualTree = panel;
    }
}

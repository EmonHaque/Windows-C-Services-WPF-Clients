﻿class LeaseTip : ToolTip
{
    public LeaseTip() {

        ShowsToolTipOnKeyboardFocus = false;
        var header = new TextBlock() {
            Text = "Receivable(s)",
            FontSize = 16,
            Foreground = Brushes.LightGray
        };
        var divider = new Separator() { Background = Brushes.LightGray };
        var receivables = new ItemsControl() {
            Margin = new Thickness(2, 0, 2, 0),
            ItemTemplate = new ReceivableTemplate()
        };
        receivables.SetBinding(ItemsControl.ItemsSourceProperty, new Binding(nameof(Lease.FixedReceivables)));
        Grid.SetRow(divider, 1);
        Grid.SetRow(receivables, 2);
        Content = new Grid() {
            MinWidth = 175,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { header, divider, receivables }
        };
    }
}

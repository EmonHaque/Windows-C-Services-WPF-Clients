﻿static class ConvertFromBytes
{
    public static Plot ToPlot(this ReadOnlySpan<byte> array) {
        int start = 0;
        int read = 0;
        int id = BitConverter.ToInt32(array.Slice(start, 4));
        read += 4;
        start = read;

        while (array[read] != 0) read++;
        var name = Encoding.ASCII.GetString(array.Slice(start, read - start));

        start = ++read;
        while (array[read] != 0) read++;
        var description = Encoding.ASCII.GetString(array.Slice(start, read - start));

        return new Plot() {
            Id = id,
            Name = name,
            Description = description
        };
    }
    public static Space ToSpace(this ReadOnlySpan<byte> array) {
        int read = 8;
        int start = 8;
        int index = 0;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new Space() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            PlotId = BitConverter.ToInt32(array.Slice(4, 4)),
            Name = segments[0],
            Description = segments[1],
            IsVacant = BitConverter.ToBoolean(array.Slice(read, 1))
        };
    }
    public static Tenant ToTenant(this ReadOnlySpan<byte> array) {
        int read = 4;
        int start = 4;
        int index = 0;
        var segments = new string[7];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new Tenant() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = segments[0],
            Father = segments[1],
            Mother = segments[2],
            Husband = segments[3],
            Address = segments[4],
            NID = segments[5],
            ContactNo = segments[6],
            HasLeft = BitConverter.ToBoolean(array.Slice(read, 1))
        };
    }
    public static Head ToHead(this ReadOnlySpan<byte> array) {
        int read = 0;
        int start = 0;
        int id = BitConverter.ToInt32(array.Slice(start, 4));
        int controlId = BitConverter.ToInt32(array.Slice(start + 4, 4));
        read += 8;
        start = read;
        while (array[read] != 0) read++;
        var name = Encoding.ASCII.GetString(array.Slice(start, read - start));

        start = ++read;
        while (array[read] != 0) read++;
        var description = Encoding.ASCII.GetString(array.Slice(start, read - start));

        return new Head() {
            Id = id,
            ControlId = controlId,
            Name = name,
            Description = description
        };
    }
    public static Receivable ToReceivable(this ReadOnlySpan<byte> array) {
        return new Receivable() {
            LeaseId = BitConverter.ToInt32(array.Slice(0, 4)),
            HeadId = BitConverter.ToInt32(array.Slice(4, 4)),
            Amount = BitConverter.ToInt32(array.Slice(8, 4)),
        };
    }
    public static Lease ToLease(this ReadOnlySpan<byte> array) {
        var lease = new Lease() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            PlotId = BitConverter.ToInt32(array.Slice(4, 4)),
            SpaceId = BitConverter.ToInt32(array.Slice(8, 4)),
            TenantId = BitConverter.ToInt32(array.Slice(12, 4)),
        };
        int index = 0;
        int read = 16;
        int start = 16;
        var segments = new string[3];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        lease.DateStart = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);
        lease.DateEnd = string.IsNullOrWhiteSpace(segments[1]) ? null : DateTime.ParseExact(segments[1], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);
        lease.Business = segments[2];
        lease.IsExpired = BitConverter.ToBoolean(array.Slice(read, 1));
        read++;

        var balance = array.Length - read;
        var numReceivable = balance / 12;

        ObservableCollection<Receivable> receivables = null;
        App.Current.Dispatcher.Invoke(() => {
            receivables = new();
            BindingOperations.EnableCollectionSynchronization(receivables, receivables);
        });
       
        for (int i = 0; i < numReceivable; i++) {
            receivables.Add(array.Slice(read, 12).ToReceivable());
            read += 12;
        }
        lease.FixedReceivables = receivables;
        return lease;
    }
    public static Transaction ToTransaction(this ReadOnlySpan<byte> array) {
        var transaction = new Transaction() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            PlotId = BitConverter.ToInt32(array.Slice(4, 4)),
            SpaceId = BitConverter.ToInt32(array.Slice(8, 4)),
            TenantId = BitConverter.ToInt32(array.Slice(12, 4)),
            ControlId = BitConverter.ToInt32(array.Slice(16, 4)),
            HeadId = BitConverter.ToInt32(array.Slice(20, 4)),
            Amount = BitConverter.ToInt32(array.Slice(24, 4)),
            IsCash = array.Slice(28, 1)[0],
        };
        int read = 29;
        int start = 29;
        while (array[read] != 0) read++;
        var date = Encoding.ASCII.GetString(array.Slice(start, read - start));
        transaction.Date = DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);

        start = ++read;
        while (array[read] != 0) read++;
        transaction.Narration = Encoding.ASCII.GetString(array.Slice(start, read - start));
        return transaction;
    }
    public static List<PlotwiseDue> ToPlotwiseDues(this byte[] array) {
        var list = new List<PlotwiseDue>();
        var span = new ReadOnlySpan<byte>(array);
        int read = 0;
        int start = 0;
        while (read < span.Length) {
            while (span[read] != 0) read++;
            var month = Encoding.ASCII.GetString(span.Slice(start, read - start));
            start = ++read;
            while (span[read] != 0) read++;
            var tenant = Encoding.ASCII.GetString(span.Slice(start, read - start));
            read++;
            list.Add(new PlotwiseDue() {
                Tenant = tenant,
                Month = month,
                Due = BitConverter.ToInt32(span.Slice(read, 4)),
            });
            read += 4;
            start = read;
        }
        return list;
    }
    public static List<PlotwiseRent> ToPlotwiseRents(this byte[] array) {
        var list = new List<PlotwiseRent>();
        var span = new ReadOnlySpan<byte>(array);
        int read, start, index; ;
        read = index = start = 0;

        while (read < span.Length) {
            var segments = new string[3];
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            list.Add(new PlotwiseRent() {
                Plot = segments[0],
                Tenant = segments[1],
                Month = segments[2],
                Rent = BitConverter.ToInt32(span.Slice(start, 4)),
                Cash = BitConverter.ToInt32(span.Slice(start + 4, 4)),
                Mobile = BitConverter.ToInt32(span.Slice(start + 8, 4)),
                Kind = BitConverter.ToInt32(span.Slice(start + 12, 4)),
                Total = BitConverter.ToInt32(span.Slice(start + 16, 4)),
                PlotId = BitConverter.ToInt32(span.Slice(start + 20, 4)),
            });
            read += 24;
            start = read;
            index = 0;
        }
        return list;
    }
    public static List<DepositDueRent> ToDepositDueRents(this byte[] array) {
        var span = new ReadOnlySpan<byte>(array);
        var list = new List<DepositDueRent>();
        int read = 0;
        while (read < span.Length) {
            list.Add(new DepositDueRent() {
                State = (DepositDueRentState)span.Slice(read, 1)[0],
                PlotId = BitConverter.ToInt32(span.Slice(read + 1, 4)),
                SpaceId = BitConverter.ToInt32(span.Slice(read + 5, 4)),
                TenantId = BitConverter.ToInt32(span.Slice(read + 9, 4)),
                Amount = BitConverter.ToInt32(span.Slice(read + 13, 4))
            });
            read += 17;
        }
        return list;
    }
    public static List<RentPayment> ToRentPayments(this byte[] array) {
        var span = new ReadOnlySpan<byte>(array);
        var list = new List<RentPayment>();
        int read, start, index; ;
        read = start = 4;
        index = 0;
        while (read < span.Length) {
            var segments = new string[4];
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            list.Add(new RentPayment() {
                Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                Plot = segments[1],
                Space = segments[2],
                Tenant = segments[3],
                Due = BitConverter.ToInt32(span.Slice(start, 4)),
                Cash = BitConverter.ToInt32(span.Slice(start + 4, 4)),
                Mobile = BitConverter.ToInt32(span.Slice(start + 8, 4)),
                Kind = BitConverter.ToInt32(span.Slice(start + 12, 4)),
                TotalPaid = BitConverter.ToInt32(span.Slice(start + 16, 4))
            });
            read += 20;
            start = read;
            index = 0;
        }
        return list;
    }
    public static List<Balance> ToBalances(this byte[] array) {
        var list = new List<Balance>();
        var span = new ReadOnlySpan<byte>(array);
        int start, index, read;
        start = read = index = 0;
        var segments = new string[4];

        while (read < span.Length) {
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            list.Add(new Balance() {
                Space = segments[0],
                Tenant = segments[1],
                DateStart = segments[2],
                DateEnd = segments[3],
                Security = BitConverter.ToInt32(span.Slice(read)),
                Rent = BitConverter.ToInt32(span.Slice(read + 4)),
                Due = BitConverter.ToInt32(span.Slice(read + 8)),
                Count = BitConverter.ToInt32(span.Slice(read + 12)),
                IsExpired = BitConverter.ToBoolean(span.Slice(read + 16))
            });
            index = 0;
            read += 17;
            start = read;
        }
        return list;
    }
    public static void ToMonthlyBalances(this byte[] array, ObservableCollection<MonthlyBalance> balances) {
        var span = new ReadOnlySpan<byte>(array);
        int start, index, read;
        start = read = index = 0;
        var segments = new string[3];

        while (read < span.Length) {
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            int lastDue = BitConverter.ToInt32(span.Slice(start + 4));
            int payment = BitConverter.ToInt32(span.Slice(start + 8));
            balances.Add(new MonthlyBalance() {
                Date = segments[0],
                Plot = segments[1],
                Tenant = segments[2],
                Due = BitConverter.ToInt32(span.Slice(start)),
                LastMonthDue = lastDue,
                Payment = payment,
                ShortOrLong = lastDue - payment
            });
            index = 0;
            read += 12;
            start = read;
        }
    }
    public static List<ReportEntry> ToReportEntries(this byte[] array, ref int entries, ref int receivable, ref int receipt) {
        var reserved = new List<ReportEntry>();
        var span = new ReadOnlySpan<byte>(array);
        int read = 0;
        int start = 0;
        int balance = 0;
        while (read < span.Length) {
            while (span[read] != 0) read++;
            var date = Encoding.ASCII.GetString(span.Slice(start, read - start));
            start = ++read;

            while (span[read] != 0) read++;
            var particulars = Encoding.ASCII.GetString(span.Slice(start, read - start));
            read++;
            int amount = BitConverter.ToInt32(span.Slice(read));
            int control = BitConverter.ToInt32(span.Slice(read + 4));
            read += 8;
            start = read;

            var entry = new ReportEntry() {
                Date = DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                Particulars = particulars
            };
            entries++;
            if (control == AppData.controlIdOfReceivable || control == AppData.controlIdOfPayment) {
                receivable += amount;
                balance -= amount;
                entry.Receivable = amount;
            }
            else {
                receipt += amount;
                balance += amount;
                entry.Receipt = amount;
            }
            entry.Balance = balance;
            reserved.Add(entry);
        }
        return reserved;
    }
    public static List<ReceiptPayment> ToReceiptPayments(this byte[] array) {
        var list = new List<ReceiptPayment>();
        var span = new ReadOnlySpan<byte>(array);
        int start, index, read;
        start = read = index = 0;
        var segments = new string[5];

        while (read < span.Length) {
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            list.Add(new ReceiptPayment() {
                Control = segments[0],
                Head = segments[1],
                Plot = segments[2],
                Tenant = segments[3],
                Space = segments[4],
                Cash = BitConverter.ToInt32(span.Slice(read)),
                Mobile = BitConverter.ToInt32(span.Slice(read + 4)),
                Kind = BitConverter.ToInt32(span.Slice(read + 8)),
                Total = BitConverter.ToInt32(span.Slice(read + 12)),
            });
            index = 0;
            read += 16;
            start = read;
        }
        return list;
    }
}

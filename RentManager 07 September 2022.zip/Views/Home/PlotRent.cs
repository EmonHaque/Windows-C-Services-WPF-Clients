﻿class PlotRent : CardView
{
    public override string Header => "Charge & Collections";

    MultiLineChart chart;
    ActionButton refresh;
    BiState state;
    TextBlock status;
    PlotRentVM viewModel;

    public override void OnFirstSight() {
        base.OnFirstSight();
        viewModel = new PlotRentVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }
    void refreshCommand() {
        if (BusyWindow.IsOpened) return;
        var position = PointToScreen(new Point(0, 0));
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin;
        position.Y += Constants.CardMargin;
        var width = ActualWidth - 2 * Constants.CardMargin;
        var height = ActualHeight - 2 * Constants.CardMargin;

        BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
        viewModel.Refresh();
        BusyWindow.Terminate();
    }
    void initializeUI() {
        status = new TextBlock() {
            Margin = new Thickness(0, 0, 10, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        state = new BiState() {
            IsTrue = true,
            Text = "All",
            Margin = new Thickness(0, 0, 5, 0)
        };
        refresh = new ActionButton() {
            Command = refreshCommand,
            Icon = Icons.Refresh,
            ToolTip = "Reload"
        };
        addActions(new UIElement[] { status, state, refresh });
        chart = new MultiLineChart();
        setContent(chart);
    }
    void bind() {
        status.SetBinding(TextBlock.TextProperty, new Binding(nameof(viewModel.Status)));
        chart.SetBinding(MultiLineChart.ItemsSourceProperty, new Binding(nameof(viewModel.Data)));
        state.SetBinding(BiState.IsTrueProperty, new Binding(nameof(viewModel.State)));
    }
}

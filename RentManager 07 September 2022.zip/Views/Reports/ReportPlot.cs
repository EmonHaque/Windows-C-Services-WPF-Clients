﻿class ReportPlot : LedgerView
{
    public override string Icon => Icons.Plot;
    public override string Header => "Plot";
    ReportPlotVM vm;
    protected override ReportBase viewModel => vm;
    protected override string display => "Name";
    protected override void initialize() {
        vm = new ReportPlotVM();
    }
}

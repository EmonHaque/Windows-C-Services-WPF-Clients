﻿public class NotificationView : CardView, INotify
{
    public override string Icon => Icons.Accounts;
    public override string Header => "Notifications";

    int unreadCount;
    ListBox list;
    NotificationVM vm;

    public event Action<int> CountChanged;
    public Action DecreaseCount;
    public NotificationView() {
        DecreaseCount = decreaseCount;
        ((App)Application.Current).appData.NotificationAdded += onNotificationAdded;
    }
    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new NotificationVM();
        DataContext = vm;
        initializeUI();
        bind();
    }
    void decreaseCount() => CountChanged?.Invoke(--unreadCount);
    
    void onNotificationAdded() {
        unreadCount = AppData.notifications.Count(x => !x.IsRead);
        CountChanged?.Invoke(unreadCount);
    }

    void initializeUI() {
        list = new ListBox() {
            ItemTemplate = new NotificationTemplate(DecreaseCount)
        };
        var grid = new Grid() {
            Children = { list }
        };
        setContent(grid);
    }
    void bind() {
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Entries)));
    }
}

﻿class EditSpace : CardView
{
    public override string Icon => Icons.Space;
    public override string Header => "Space";

    SelectItem nonEditablePlots;
    ListBox spaceList;
    ComboSelect plots;
    ComboText name, description;
    ComboButton buttons;
    ComboBiState isVacant;
    DayPicker vaccatedOn;
    EditText search;
    //TriState filter;
    MultiState filter;
    CountBlock counter;
    EditSpaceVM viewModel;

    public override void OnFirstSight() {
        base.OnFirstSight();
        viewModel = new EditSpaceVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }
    void initializeUI() {
        nonEditablePlots = new SelectItem() {
            Hint = "Plot",
            IsRequired = true,
            Icon = Icons.Plot,
            SelectedValuePath = nameof(Plot.Id),
            DisplayPath = nameof(Plot.Name),
            FilterParameter = SelectQuery.NonEditable,
            FilterCommand = viewModel.FilterCommand
        };
        search = new EditText() {
            Icon = Icons.SearchSpace,
            Hint = "Space",
            IsTrimBottomRequested = true
        };
        filter = new MultiState() {
            Icons = new string[] { Icons.Existing, Icons.LeftOrExpired, Icons.All },
            Tips = new string[] { "Vacant", "Occupied", "All" },
            VerticalAlignment = VerticalAlignment.Center
        };
        counter = new CountBlock() {
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 0, 0, 0)
        };
        Grid.SetColumn(filter, 1);
        Grid.SetColumn(counter, 2);
        var searchGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                },
            Children = { search, filter, counter }
        };
        Grid.SetRow(searchGrid, 1);
        spaceList = new ListBox() {
            BorderBrush = Brushes.LightGray,
            BorderThickness = new Thickness(0, 0, 1, 0),
            ItemTemplate = new SpaceTemplate(nameof(viewModel.SpaceQuery), viewModel)
        };
        Grid.SetRow(spaceList, 2);

        plots = new ComboSelect() {
            Hint = "Plot",
            Icon = Icons.Plot,
            IsRequired = true,
            SelectedValuePath = nameof(Plot.Id),
            DisplayPath = nameof(Plot.Name),
            ItemsSource = nameof(viewModel.Plots),
            Error = nameof(viewModel.ErrorPlotId),
            Query = nameof(viewModel.PlotQuery),
            FilterParameter = SelectQuery.Plot,
            FilterCommand = viewModel.FilterCommand,
            SelectedValue = $"{nameof(viewModel.Edited)}.{nameof(Space.PlotId)}",
            NonEditable = new Binding($"{nameof(viewModel.Selected)}.{nameof(Space.PlotId)}") { Converter = Converters.plotId2plotName }
        };
        name = new ComboText() {
            Hint = "Name",
            Icon = Icons.Space,
            IsRequired = true,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Space.Name)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Space.Name)}",
            Error = nameof(viewModel.ErrorName)
        };
        description = new ComboText() {
            Hint = "Description",
            Icon = Icons.Description,
            IsRequired = true,
            IsMultiline = true,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Space.Description)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Space.Description)}",
            Error = nameof(viewModel.ErrorDescription)
        };
        isVacant = new ComboBiState() {
            Text = "Is Vacant?",
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Space.IsVacant)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Space.IsVacant)}",
            VerticalAlignment = VerticalAlignment.Center
        };
        vaccatedOn = new DayPicker() {
            Hint = "From",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true,
            Visibility = Visibility.Hidden
        };
        Grid.SetColumn(vaccatedOn, 1);
        var vacantGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(1, GridUnitType.Star) },
                    new ColumnDefinition(){ Width = new GridLength(3, GridUnitType.Star) },
                },
            Children = { isVacant, vaccatedOn }
        };

        buttons = new ComboButton() {
            EditCommand = viewModel.SetIsOnEdit,
            CancelCommand = viewModel.ResetIsOnEdit,
            SaveCommand = viewModel.Save,
            IsValid = nameof(viewModel.IsValid)
        };
        Grid.SetRow(name, 1);
        Grid.SetRow(description, 2);
        Grid.SetRow(vacantGrid, 3);
        Grid.SetRow(buttons, 4);
        var editableGrid = new Grid() {
            Margin = new Thickness(10, 10, 0, 0),
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                },
            Children = { plots, name, description, vacantGrid, buttons }
        };
        Grid.SetRow(editableGrid, 2);
        Grid.SetColumn(editableGrid, 1);

        var grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                },
            Children = { nonEditablePlots, searchGrid, spaceList, editableGrid }
        };
        setContent(grid);
    }

    void bind() {
        nonEditablePlots.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.NonEditablePlots)));
        nonEditablePlots.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(viewModel.SelectedPlot)));
        //nonEditablePlots.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorPlotId)));
        nonEditablePlots.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.NonEditablePlotQuery)) { Mode = BindingMode.OneWayToSource });

        spaceList.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(viewModel.Editables)));
        spaceList.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(viewModel.Selected)));

        var binding = new Binding(nameof(viewModel.IsOnEdit));
        plots.SetBinding(ComboSelect.IsOnEditProperty, binding);
        name.SetBinding(ComboText.IsOnEditProperty, binding);
        description.SetBinding(ComboText.IsOnEditProperty, binding);
        buttons.SetBinding(ComboButton.IsOnEditProperty, binding);
        isVacant.SetBinding(ComboBiState.IsOnEditProperty, binding);

        isVacant.Resources.Add(typeof(ComboBiState), new Style() {
            Triggers = {
                    new MultiDataTrigger() {
                        Conditions = {
                            new Condition() {
                                Binding = new Binding($"{nameof(viewModel.Selected)}.{nameof(Space.IsVacant)}"),
                                Value = true
                            },
                            new Condition() {
                                Binding = new Binding($"{nameof(viewModel.Edited)}.{nameof(Space.IsVacant)}"),
                                Value = true
                            }
                        },
                        Setters = { new Setter(IsEnabledProperty, false) }
                    }
                }
        });
        vaccatedOn.SetBinding(DayPicker.VisibilityProperty, new MultiBinding() {
            Bindings = {
                    binding,
                    new Binding($"{nameof(viewModel.Selected)}.{nameof(Space.IsVacant)}"),
                    new Binding($"{nameof(viewModel.Edited)}.{nameof(Space.IsVacant)}")
                },
            Converter = Converters.leaseExpiryDate
        });
        vaccatedOn.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(viewModel.VaccatedOn)));
        vaccatedOn.SetBinding(DayPicker.ErrorProperty, new Binding(nameof(viewModel.ErrorVacantDate)));

        filter.SetBinding(MultiState.StateProperty, new Binding(nameof(viewModel.FilterState)));
        search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.SpaceQuery)) { Mode = BindingMode.OneWayToSource });
        counter.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Source = spaceList });
    }
}

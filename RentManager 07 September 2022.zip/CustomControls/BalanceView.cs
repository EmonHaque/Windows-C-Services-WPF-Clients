﻿class BalanceView : Grid
{
    Border header, footer;
    TextBlock title, totalSecurity, totalRent, totalDue;
    ListBox content;
    public BalanceView(ReportBalanceVM viewModel) {
        title = new TextBlock() {
            Text = "as at " + DateTime.Today.ToString("dd MMM yyyy"),
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 0, 0, 5),
            FontSize = 14,
            FontWeight = FontWeights.Bold
        };
        initializeHeader();
        content = new ListBox() {
            Margin = new Thickness(5, 3, 0, 3),
            ItemTemplate = new BalanceTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new GroupedRPTemplate(nameof(viewModel.TenantQuery), viewModel))
                        }
                    }
                }
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false))
                        }
                    }
                }
            }
        };
        initializeFooter();
        SetRow(header, 1);
        SetRow(content, 2);
        SetRow(footer, 3);
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        Children.Add(title);
        Children.Add(header);
        Children.Add(content);
        Children.Add(footer);
    }

    void initializeHeader() {
        var particulars = new TextBlock() { Text = "Tenant and Space" };
        var from = new TextBlock() { Text = "From", HorizontalAlignment = HorizontalAlignment.Center };
        var security = new TextBlock() { Text = "Security", HorizontalAlignment = HorizontalAlignment.Right };
        var rent = new TextBlock() { Text = "Rent", HorizontalAlignment = HorizontalAlignment.Right };
        var due = new TextBlock() { Text = "Due", HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(from, 1);
        Grid.SetColumn(security, 2);
        Grid.SetColumn(rent, 3);
        Grid.SetColumn(due, 4);

        var grid = new Grid() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness + Constants.ScrollPresenterMargin, 0),
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(150) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { particulars, from, security, rent, due }
        };

        header = new Border() {
            Padding = new Thickness(8, 2, 5, 2),
            //Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
        header.Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                    new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                }
        });
    }
    void initializeFooter() {
        var total = new TextBlock() { Text = "Total" };
        totalSecurity = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalRent = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalDue = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalSecurity, 1);
        Grid.SetColumn(totalRent, 2);
        Grid.SetColumn(totalDue, 3);
        var grid = new Grid() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness + Constants.ScrollPresenterMargin, 0),
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { total, totalSecurity, totalRent, totalDue }
        };
        footer = new Border() {
            
            Padding = new Thickness(8, 2, 5, 2),
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
        footer.Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                    new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                }
        });
    }

    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public Tuple<int, int, int> Summary {
        get { return (Tuple<int, int, int>)GetValue(SummaryProperty); }
        set { SetValue(SummaryProperty, value); }
    }

    public static readonly DependencyProperty SummaryProperty =
        DependencyProperty.Register("Summary", typeof(Tuple<int, int, int>), typeof(BalanceView), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = (s, e) => {
                var o = (BalanceView)s;
                var values = (Tuple<int, int, int>)e.NewValue;
                o.totalSecurity.Text = values.Item1.ToString(Constants.NumberFormat);
                o.totalRent.Text = values.Item2.ToString(Constants.NumberFormat);
                o.totalDue.Text = values.Item3.ToString(Constants.NumberFormat);
            }
        });

    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(BalanceView), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = (s, e) => ((BalanceView)s).content.ItemsSource = (ICollectionView)e.NewValue //(List<object>)e.NewValue
        });
}

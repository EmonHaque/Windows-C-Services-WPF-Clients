echo "[Unit]
Description=Rent Manager Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
Restart=on-failure
RestartSec=10
KillMode=process
ExecStart=/mnt/HDD/Code/RentManagerService/RentManagerService #change location

[Install]
WantedBy=multi-user.target" >> /etc/systemd/system/RentManager.service

systemctl daemon-reload
systemctl start RentManager

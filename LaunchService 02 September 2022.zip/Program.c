#pragma comment (lib, "Ws2_32.lib")
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#include "Messenger.h"
#include "Structures.h"
#include "List.h"
#include "Service.h"

#pragma region variables
static SOCKET server;
static CRITICAL_SECTION criticalClient;
static byte isRunning;
static List clients, apps;
#pragma endregion

#pragma region protos
void initialize();
void acceptClient();
void cleanup();
#pragma endregion

int main() {
	SetActions(initialize, acceptClient, cleanup);
#ifdef _DEBUG
	RunServiceDebug();
#else
	RunServiceRelease();
#endif
	return 0;
}

static ulong handleRequest(void* p) {
	SOCKET client = p;
	char header[4];
	int packetSize, read, newRead;
	char* packet = { 0 };

	read = recv(client, header, 4, 0);
	if (read < 0) goto onDisconnect;
	while (read < 4) {
		newRead = recv(client, &header[read], 4 - read, 0);
		if (newRead <= 0) goto onDisconnect;
		read += newRead;
	}
	memcpy_s(&packetSize, 4, header, 4);

	packet = malloc(packetSize);
	read = newRead = 0;
	while (read < packetSize) {
		newRead = recv(client, packet, packetSize - read, 0);
		if (newRead <= 0) goto onDisconnect;
		read += newRead;
	}
	char* app = packet;
	char* version = packet + strlen(app) + 1;

	byte hasUpdate = 0;
	AppInfo** infos = apps.data;
	AppInfo* info = { 0 };
	for (uint i = 0; i < apps.count; i++) {
		if (strcmp(infos[i]->appName, app) == 0) {
			if (strcmp(infos[i]->version, version) != 0) {
				hasUpdate = 1;
				info = infos[i];
				break;
			}
		}
	}
	if (hasUpdate) {
		sendByte(client, hasUpdate);
		sendInt(client, info->totalSize);
		AppFile** fileList = info->fileList.data;
		for (uint i = 0; i < info->fileList.count; i++) {
			int size = fileList[i]->fileLength + strlen(fileList[i]->fileName) + 1;
			sendInt(client, size);
			sendString(client, fileList[i]->fileName);

			char fileBuffer[1024];
			int read = 0;
			FILE* f; 
			fopen_s(&f, fileList[i]->filePath, "rb");
			while ((read = fread(fileBuffer, 1, sizeof(fileBuffer), f)) > 0) {
				int sent = 0;
				do {
					sent = send(client, fileBuffer, read, 0);
					if (sent == SOCKET_ERROR) break;
					read -= sent;
				} while (read > 0);
				if (sent == SOCKET_ERROR) break;
			}
			fclose(f);
		}
	}

onDisconnect:
	if (packet) free(packet);

	EnterCriticalSection(&criticalClient);
	Client** list = clients.data;
	Client* c = 0;
	for (uint i = 0; i < clients.count; i++) {
		if (list[i]->socket == client) {
			c = list[i];
			break;
		}
	}
	shutdown(client, SD_BOTH);
	closesocket(client);

	CloseHandle(c->thread); // do you've to CloseHandle when it exits?
	//HANDLE thisThread = GetCurrentThread();
	//CloseHandle(thisThread) // this has no effect? if it's you don't have to maintain a client list and critical section
	removeFromList(&clients, c);
	free(c);
	LeaveCriticalSection(&criticalClient);

	return 0;
}
static int mallocate(char* src, char** dst) {
	int length = strlen(src);
	int extendedLength = length + 1;
	*dst = malloc(extendedLength);
	memcpy_s(*dst, length, src, length);
	(*dst)[length] = 0;
	return extendedLength;
}
static void populateAppList() {
	FILE* fp;
	fopen_s(&fp, "C:/Users/Emon/Desktop/AppRepo/applist.txt", "r");
	char line[500];
	int index;
	char* token, *nextToken;
	char* tokens[3];
	char* delimiter = " ,\r\n";
	while (fgets(line, sizeof line, fp) != 0) {
		index = 0;
		token = strtok_s(line, delimiter, &nextToken);
		while (token != 0) {
			tokens[index] = token;
			index++;
			token = strtok_s(0, delimiter, &nextToken);
		}
		AppInfo* info = malloc(APP_INFO_SIZE);
		mallocate(tokens[0], &info->appName);
		mallocate(tokens[1], &info->version);
		mallocate(tokens[2], &info->repository);
		List fileList = { 0, 10, malloc(10 * POINTER_SIZE) };

		WIN32_FIND_DATAA fdFile;
		HANDLE hFind = NULL;
		char sPath[2048];
		sprintf_s(sPath, sizeof(sPath), "%s/*.*", info->repository);
		hFind = FindFirstFileA(sPath, &fdFile);
		info->totalSize = 0;
		do {
			if (strcmp(fdFile.cFileName, ".") != 0
				&& strcmp(fdFile.cFileName, "..") != 0) {
				info->totalSize += fdFile.nFileSizeLow + strlen(fdFile.cFileName) + 1 + 4;
				sprintf_s(sPath, sizeof(sPath), "%s/%s", info->repository, fdFile.cFileName);

				AppFile* file = malloc(APP_FILE_SIZE);
				mallocate(fdFile.cFileName, &file->fileName);
				mallocate(sPath, &file->filePath);
				file->fileLength = fdFile.nFileSizeLow;
				addToList(&fileList, file);
			}
		} while (FindNextFileA(hFind, &fdFile));
		FindClose(hFind);

		info->fileList = fileList;
		addToList(&apps, info);
	}
	fclose(fp);
}
static void initialize() {
	const wchar_t* IP = L"127.0.0.1";
	int PORT = 5555;

	WSADATA w;
	WSAStartup(MAKEWORD(2, 2), &w);
	SOCKADDR_IN address = { AF_INET, htons(PORT) };
	InetPton(AF_INET, IP, &address.sin_addr.s_addr);
	server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	bind(server, &address, sizeof(address));
	listen(server, SOMAXCONN);
	isRunning = 1;

	clients.capacity = 5;
	clients.count = 0;
	clients.data = malloc(clients.capacity * CLIENT_SIZE);

	apps.capacity = 5;
	apps.count = 0;
	apps.data = malloc(apps.capacity * APP_INFO_SIZE);
	populateAppList();
	InitializeCriticalSection(&criticalClient);
}
static void acceptClient() {
	while (isRunning) {
		SOCKADDR_IN from;
		int length = sizeof(from);
		SOCKET client = accept(server, &from, &length);
		//char ipv4[INET_ADDRSTRLEN];
		//inet_ntop(AF_INET, &(from.sin_addr), ipv4, INET_ADDRSTRLEN);
		BOOL b = TRUE;
		setsockopt(client, IPPROTO_TCP, TCP_NODELAY, &b, sizeof(BOOL));

		EnterCriticalSection(&criticalClient);
		HANDLE requestThread = CreateThread(NULL, 0, handleRequest, client, 0, NULL);
		Client* c = malloc(CLIENT_SIZE);
		c->socket = client;
		c->thread = requestThread;
		addToList(&clients, c);
		LeaveCriticalSection(&criticalClient);
	}
}
static void cleanup() {
	isRunning = 0;
	closesocket(server);
	WSACleanup();
}
#include "Messenger.h"

int sendString(SOCKET s, char* str) {
	int length = strlen(str) + 1;
	int sent = 0;
	do {
		sent = send(s, str, length, 0);
		if (sent == SOCKET_ERROR) return SOCKET_ERROR;
		length -= sent;
	} while (length > 0);
	return 0;
}
int sendNonNullString(SOCKET s, char* str) {
	int length = strlen(str);
	int sent = 0;
	do {
		sent = send(s, str, length, 0);
		if (sent == SOCKET_ERROR) return SOCKET_ERROR;
		length -= sent;
	} while (length > 0);
	return 0;
}
int sendByte(SOCKET s, byte val) {
	int sent = send(s, &val, 1, 0);
	if (sent == SOCKET_ERROR) return SOCKET_ERROR;
	return 0;
}
int sendInt(SOCKET s, int val) {
	char* ptr = &val;
	int length = 4;
	int sent = 0;
	do {
		sent = send(s, ptr, length, 0);
		if (sent == SOCKET_ERROR) return SOCKET_ERROR;
		length -= sent;
	} while (length > 0);
	return 0;
}
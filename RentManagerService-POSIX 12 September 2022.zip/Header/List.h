#pragma once
#include <malloc.h>

typedef struct {
	unsigned int count;
	unsigned int capacity;
	void* data;
} List;

void addToList(List*, void*);
void removeFromList(List*, void*);
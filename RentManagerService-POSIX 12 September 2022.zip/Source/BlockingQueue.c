#include "BlockingQueue.h"
#include <malloc.h>
#include <unistd.h>

void putInto(BlockingQueue *queue, void *item) {
    pthread_mutex_lock(&queue->lock);
    void **items = queue->data;
    items[queue->count++] = item;
    if (queue->count == queue->capacity) {
        queue->capacity *= 2;
        queue->data = realloc(queue->data, queue->capacity * sizeof(void *));
    }
    if (queue->isWaiting) {
        pthread_cond_signal(&queue->condition);
    }
    pthread_mutex_unlock(&queue->lock);
}

void *takeOutFrom(BlockingQueue *queue) {
    void *item = 0;
    pthread_mutex_lock(&queue->lock);
    if (queue->count > 0) {
        void **items = queue->data;
        item = items[0];
    } else {
        queue->isWaiting = 1;
        pthread_cond_wait(&queue->condition, &queue->lock);
        queue->isWaiting = 0;
        if (queue->count > 0) {
            void **items = queue->data;
            item = items[0];
        }
    }
    queue->count--;
    pthread_mutex_unlock(&queue->lock);
    return item;
}
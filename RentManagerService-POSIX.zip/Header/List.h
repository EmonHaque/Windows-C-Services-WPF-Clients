#pragma once
#include <malloc.h>

typedef struct {
	unsigned int count;
	unsigned int capacity;
	void* data;
} List;

void addToList(List* list, void* item);
void removeFromList(List* list, void* item);
﻿class GroupedRTSingleTemplate : ControlTemplate
{
    public GroupedRTSingleTemplate() {
        TargetType = typeof(GroupItem);
        var totals = new FrameworkElementFactory(typeof(ContentControl));
        totals.SetValue(ContentControl.ContentTemplateProperty, new RPSummarySingleTemplate());
        totals.SetBinding(ContentControl.ContentProperty, new Binding() {
            Converter = Converters.rpGroupSingle2Summary,
            Mode = BindingMode.OneWay
        });
        VisualTree = totals;
    }
}

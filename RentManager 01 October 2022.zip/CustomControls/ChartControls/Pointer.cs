﻿class Pointer : UIElement
{
    Pen pen;
    Point start, end;
    public static event Action<double> Moved;
    public Pointer() {
        pen = new Pen(Brushes.White, 1) { DashStyle = DashStyles.DashDotDot, DashCap = PenLineCap.Round };
        start = new Point();
        end = new Point();
        IsHitTestVisible = false;
    }
    public void SetPoint(double x1, double y2, double labelWidth) {
        start.X = end.X = x1;
        start.Y = labelWidth;
        end.Y = y2;
        InvalidateVisual();
        Moved(x1);
    }
    protected override void OnRender(DrawingContext drawingContext) => drawingContext.DrawLine(pen, start, end);
}

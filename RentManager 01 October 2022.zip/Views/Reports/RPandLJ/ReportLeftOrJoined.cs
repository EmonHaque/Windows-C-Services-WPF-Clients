﻿using System.Security.Policy;

class ReportLeftOrJoined : CardView
{
    public override string Header => "Left or Joined";

    DayPicker from, to;
    CommandButton refresh;
    ListBox entries;
    TextBlock status;
    Grid entryGrid;
    ExpanderState expandState;
    DependencyPropertyDescriptor expandStateDescriptor;
    ReportLeftJoinVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new ReportLeftJoinVM();
        DataContext = vm;
        initializeUI();
        bind();

        expandStateDescriptor = DependencyPropertyDescriptor.FromProperty(ExpanderState.IsTrueProperty, typeof(ExpanderState));
        expandStateDescriptor.AddValueChanged(expandState, onExpandedChanged);
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Unloaded -= onUnloaded;
        expandStateDescriptor.RemoveValueChanged(expandState, onExpandedChanged);
    }

    void onExpandedChanged(object? sender, EventArgs e) {
        var items = Helper.FindVisualChildren<GroupItem>(entries);
        if (expandState.IsTrue) {
            foreach (GroupItem item in items) item.Tag = true;
            expandState.ToolTip = "Collapse";
        }
        else {
            foreach (GroupItem item in items) item.Tag = false;
            expandState.ToolTip = "Expand";
        }
    }

    void initializeUI() {
        from = new DayPicker() {
            Hint = "From",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true,
        };
        to = new DayPicker() {
            Hint = "To",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true,
        };
        refresh = new CommandButton() {
            Icon = Icons.Refresh,
            ToolTip = "Refresh",
            Command = vm.Refresh,
            Margin = new Thickness(5, 0, 0, 0)
        };
        Grid.SetColumn(to, 1);
        Grid.SetColumn(refresh, 2);
        var topRow = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
            },
            Children = { from, to, refresh }
        };
        initializeEntryGrid();
        Grid.SetRow(entryGrid, 1);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { topRow, entryGrid }
        };
        status = new TextBlock() { Margin = new Thickness(0, 0, 5, 0) };
        addActions(new UIElement[] { status });
        setContent(grid);
    }
    void initializeEntryGrid() {
        expandState = new ExpanderState() {
            Margin = new Thickness(0, 0, 5, 0),
            VerticalAlignment = VerticalAlignment.Center,
            ToolTip = "Expand"
        };
        var particulars = new TextBlock() { Text = "Particulars", HorizontalAlignment = HorizontalAlignment.Left };
        var start = new TextBlock() { Text = "Start", HorizontalAlignment = HorizontalAlignment.Center };
        var end = new TextBlock() { Text = "End", HorizontalAlignment = HorizontalAlignment.Center };
        var receivable = new TextBlock() { Text = "Receivable", HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(particulars, 1);
        Grid.SetColumn(start, 2);
        Grid.SetColumn(end, 3);
        Grid.SetColumn(receivable, 4);
        var grid = new Grid() {
            Margin = new Thickness(2, 0, 5, 0),
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) }
             },
            Children = { expandState, particulars, start, end, receivable },
            Resources = {{
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                            }
                        }
                    }
                }
        };
        var header = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 2, 0, 2),
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };

        entries = new ListBox() {
            ItemTemplate = new LJTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new GroupedLJTemplate())
                        }
                    }
                }
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false)),
                        }
                    }
                }
            }
        };
        Grid.SetRow(entries, 1);
        entryGrid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
            Children = { header, entries }
        };
    }
    void bind() {
        status.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.Status)));
        from.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.From)));
        //from.SetBinding(DayPicker.ErrorProperty, new Binding(nameof(vm.ErrorFrom)));
        to.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.To)));
        //to.SetBinding(DayPicker.ErrorProperty, new Binding(nameof(vm.ErrorTo)));
        entries.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Data)));
    }
}

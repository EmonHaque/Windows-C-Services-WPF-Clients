﻿class LJHeaderTemplate : DataTemplate
{
    public LJHeaderTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid" };
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var groupName = new FrameworkElementFactory(typeof(TextBlock));
        var count = new FrameworkElementFactory(typeof(TextBlock));
        var total = new FrameworkElementFactory(typeof(TextBlock));

        col1.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        count.SetValue(Grid.ColumnProperty, 1);
        total.SetValue(Grid.ColumnProperty, 2);
        count.SetValue(TextBlock.MarginProperty, new Thickness(5, 0, 0, 0));
        total.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

        var source = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1);
        groupName.SetBinding(TextBlock.TextProperty, new Binding("DataContext." + nameof(GroupItem.Name)) {
            Mode = BindingMode.OneWay,
            RelativeSource = source
        });
        count.SetBinding(TextBlock.TextProperty, new Binding("DataContext") {
            RelativeSource = source,
            Converter = Converters.ljGroup2Count,
            Mode = BindingMode.OneWay
        });
        total.SetBinding(TextBlock.TextProperty, new Binding("DataContext") {
            RelativeSource = source,
            Converter = Converters.ljGroup2Summary,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(groupName);
        grid.AppendChild(count);
        grid.AppendChild(total);

        VisualTree = grid;

        Triggers.Add(new Trigger() {
            Property = Grid.IsMouseOverProperty,
            Value = true,
            Setters = {
                new Setter(Grid.BackgroundProperty, Constants.BackgroundDark, "grid")
            }
        });
    }
}

﻿class SpaceTemplate : DataTemplate
{
    public SpaceTemplate(string query, object viewModel) {
        var panel = new FrameworkElementFactory(typeof(StackPanel));
        var space = new FrameworkElementFactory(typeof(HiBlock)) { Name = "space" };
        var tenantBlock = new FrameworkElementFactory(typeof(TextBlock)) { Name = "tenant" };
        var hyphen = new FrameworkElementFactory(typeof(Run));
        var tenant = new FrameworkElementFactory(typeof(Run));

        panel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);
        space.SetValue(HiBlock.FontWeightProperty, FontWeights.Bold);
        tenantBlock.SetValue(TextBlock.FontStyleProperty, FontStyles.Italic);
        hyphen.SetValue(Run.TextProperty, " - ");
        space.SetBinding(HiBlock.TextProperty, new Binding(nameof(Space.Name)));
        space.SetBinding(HiBlock.QueryProperty, new Binding(query) { Source = viewModel, IsAsync = true });
        tenant.SetBinding(Run.TextProperty, new MultiBinding() {
            Bindings = {
                    new Binding(nameof(Space.IsVacant)),
                    new Binding(nameof(Space.Id))
                },
            Converter = Converters.spaceId2TenantName
        });
        tenantBlock.AppendChild(hyphen);
        tenantBlock.AppendChild(tenant);
        panel.AppendChild(space);
        panel.AppendChild(tenantBlock);
        VisualTree = panel;

        Triggers.Add(new MultiDataTrigger() {
            Conditions = {
                    new Condition(new Binding("FilterState"){ Source = viewModel }, null),
                    new Condition(new Binding(nameof(Space.IsVacant)), true),
                },
            Setters = {
                    new Setter(HiBlock.ForegroundProperty, Brushes.Gray),
                    new Setter(HiBlock.FontStyleProperty, FontStyles.Italic),
                }
        });
    }
}

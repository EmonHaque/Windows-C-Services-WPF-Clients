﻿class AddPlotVM : AddBase<Plot>
{
    public string ErrorName { get; set; }
    public string ErrorDescription { get; set; }
    public bool IsValid { get; set; }

    public AddPlotVM() {
        initializeValidationProperties();
        TObject.PropertyChanged += validate;
    }

    void initializeValidationProperties() {
        IsValid = false;
        ErrorName = "Name is required";
        ErrorDescription = "Description is required";
        OnPropertyChanged(nameof(ErrorName));
        OnPropertyChanged(nameof(ErrorDescription));
        OnPropertyChanged(nameof(IsValid));
    }

    #region validation rules
    void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Plot.Name): validateName(); break;
            case nameof(Plot.Description): validateDescription(); break;
        }
        IsValid = ErrorName == string.Empty && ErrorDescription == string.Empty;
        OnPropertyChanged(nameof(IsValid));
    }
    void validateName() {
        ErrorName = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Name)) {
            ErrorName = "Name is required";
        }
        else {
            for (int i = 0; i < AppData.plots.Count; i++) {
                if (string.Equals(AppData.plots[i].Name, TObject.Name.Trim(), StringComparison.OrdinalIgnoreCase)) {
                    ErrorName = "Name exits";
                    break;
                }
            }
        }
        OnPropertyChanged(nameof(ErrorName));
    }
    void validateDescription() {
        ErrorDescription = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Description)) {
            ErrorDescription = "Description is required";
        }
        OnPropertyChanged(nameof(ErrorDescription));
    }
    #endregion

    #region base implementation
    protected override ObservableCollection<Plot> collection => AppData.plots;
    protected override string errorTitle => "Plot";
    protected override List<ArraySegment<byte>> bytes => TObject.ToBytes();
    protected override Function function => Function.AddPlot;
    protected override void renewTObject() {
        TObject.PropertyChanged -= validate;

        TObject = new Plot();
        OnPropertyChanged(nameof(TObject));
        TObject.PropertyChanged += validate;
        initializeValidationProperties();
    }
    #endregion
}

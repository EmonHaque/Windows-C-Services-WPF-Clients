#include <time.h>
#include <stdio.h>
#include "List.h"
#include "BlockingQueue.h"
#include "Messenger.h"
#include "Structures.h"
#include "sqlite3.h"
#include <stdint.h>

#pragma region variables
extern byte isRunning;
extern BlockingQueue requests;

BlockingQueue personalResponses, publicResponses;

static sqlite3* db;
static sqlite3_stmt* command;
static Totals total;
static List plots, spaces, tenants, leases, receivables, controlHeads, heads;
static BlockingQueue garbageRequests;
static HANDLE requestProcessThread, freeRequestThread;
#pragma endregion

static void initializeList() {
	int size = 50;
	int initialSize = size * POINTER_SIZE;

	plots.capacity =
		spaces.capacity =
		tenants.capacity =
		leases.capacity =
		receivables.capacity =
		controlHeads.capacity =
		heads.capacity = size;

	plots.count =
		spaces.count =
		tenants.count =
		leases.count =
		receivables.count =
		controlHeads.count =
		heads.count = 0;

	plots.data = malloc(initialSize);
	spaces.data = malloc(initialSize);
	tenants.data = malloc(initialSize);
	leases.data = malloc(initialSize);
	receivables.data = malloc(initialSize);
	controlHeads.data = malloc(initialSize);
	heads.data = malloc(initialSize);
}
static void initializeQueue() {
	personalResponses.count = 0;
	personalResponses.capacity = 10;
	personalResponses.data = malloc(personalResponses.capacity * POINTER_SIZE);
	personalResponses.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&personalResponses.section);

	publicResponses.count = 0;
	publicResponses.capacity = 10;
	publicResponses.data = malloc(publicResponses.capacity * POINTER_SIZE);
	publicResponses.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&publicResponses.section);
}
static void addShortPersonalResponse(Request* r, ShortMessage* s, int size) {
	ResponsePersonal* response = malloc(RESPONSE_PERSONAL_SIZE);
	response->sender = r->sender;
	response->function = r->function;
	response->data = s;
	response->size = 1 + size + 1; // 1 for byte size for string and last 1 for '\0'
	putInto(&personalResponses, response);
}
static void addLongPersonalResponse(Request* r, List l, int size) {
	ResponsePersonal* response = malloc(RESPONSE_PERSONAL_SIZE);
	response->sender = r->sender;
	response->function = r->function;
	response->size = size;
	response->data = l.data;
	response->count = l.count;
	putInto(&personalResponses, response);
}
static void addPublicResponse(Request* r, void* d, int size) {
	ResponsePublic* pr = malloc(RESPONSE_PUBLIC_SIZE);
	pr->function = r->function;
	pr->userId = r->userId;
	pr->data = d;
	pr->size = size;
	putInto(&publicResponses, pr);
}
static int mallocate(char* src, char** dst) {
	int length = src ? strlen(src) : 0;
	int extendedLength = length + 1;
	*dst = malloc(extendedLength);
	memcpy_s(*dst, length, src, length);
	(*dst)[length] = 0;
	return extendedLength;
}
static void sendStartupPackets(SOCKET s) {
	sendInt(s, total.plot);
	Plot** pp = plots.data;
	for (uint i = 0; i < plots.count; i++) {
		if (sendInt(s, pp[i]->id) < 0) break;
		sendString(s, pp[i]->name);
		sendString(s, pp[i]->description);
	}
	sendInt(s, total.space);
	Space** sp = spaces.data;
	for (uint i = 0; i < spaces.count; i++) {
		if (sendInt(s, sp[i]->id) < 0) break;
		sendInt(s, sp[i]->plotId);
		sendString(s, sp[i]->name);
		sendString(s, sp[i]->description);
		sendByte(s, sp[i]->isVacant);
	}
	sendInt(s, total.tenant);
	Tenant** tp = tenants.data;
	for (uint i = 0; i < tenants.count; i++) {
		if (sendInt(s, tp[i]->id) < 0) break;
		sendString(s, tp[i]->name);
		sendString(s, tp[i]->father);
		sendString(s, tp[i]->mother);
		sendString(s, tp[i]->husband);
		sendString(s, tp[i]->address);
		sendString(s, tp[i]->NID);
		sendString(s, tp[i]->contactNo);
		sendByte(s, tp[i]->hasLeft);
	}
	sendInt(s, total.lease);
	Lease** lp = leases.data;
	for (uint i = 0; i < leases.count; i++) {
		if (sendInt(s, lp[i]->id) < 0) break;
		sendInt(s, lp[i]->plotId);
		sendInt(s, lp[i]->spaceId);
		sendInt(s, lp[i]->tenantId);
		sendString(s, lp[i]->dateStart);
		sendString(s, lp[i]->dateEnd);
		sendString(s, lp[i]->business);
		sendByte(s, lp[i]->isExpired);
	}
	sendInt(s, total.receivable);
	Receivable** rp = receivables.data;
	for (uint i = 0; i < receivables.count; i++) {
		if (sendInt(s, rp[i]->leaseId) < 0) break;
		sendInt(s, rp[i]->headId);
		sendInt(s, rp[i]->amount);
	}
	sendInt(s, total.controlHead);
	ControlHead** cp = controlHeads.data;
	for (uint i = 0; i < controlHeads.count; i++) {
		if (sendInt(s, cp[i]->id) < 0) break;
		sendString(s, cp[i]->name);
	}
	sendInt(s, total.head);
	Head** hp = heads.data;
	for (uint i = 0; i < heads.count; i++) {
		if (sendInt(s, hp[i]->id) < 0) break;
		sendInt(s, hp[i]->controlId);
		sendString(s, hp[i]->name);
		sendString(s, hp[i]->description);
	}
}

static void addPlot(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	int size = 0;
	char* name, * description;
	name = strtok_s(&r->packet[12], "", &description), description++;
	Plot** pp = plots.data;
	for (uint i = 0; i < plots.count; i++) {
		if (_stricmp(pp[i]->name, name) == 0) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Plot exists");
			break;
		}
	}
	if (message->isSuccess) {
		char* sql = "INSERT INTO Plots (Name, Description) VALUES(?, ?)";
		sqlite3_prepare_v2(db, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 2, description, -1, SQLITE_STATIC);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to insert plot");
		}
		else {
			total.plot += r->length - 8;
			Plot* p = malloc(PLOT_SIZE);
			p->id = plots.count ? pp[plots.count - 1]->id + 1 : 1;
			mallocate(name, &p->name);
			mallocate(description, &p->description);
			addToList(&plots, p);
			addPublicResponse(r, p, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addSpace(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int plotId, size = 0;
	char* name, * description;
	memcpy(&plotId, &r->packet[12], 4);
	name = strtok_s(&r->packet[16], "", &description), description++;
	Space** sp = spaces.data;
	for (uint i = 0; i < spaces.count; i++) {
		if (sp[i]->plotId != plotId) continue;
		if (_stricmp(sp[i]->name, name) == 0) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Space exists");
			break;
		}
	}
	if (message->isSuccess) {
		char* sql = "INSERT INTO Spaces (PlotId, Name, Description, IsVacant) VALUES(?, ?, ?, 1)";
		sqlite3_prepare_v2(db, sql, -1, &command, 0);
		sqlite3_bind_int(command, 1, plotId);
		sqlite3_bind_text(command, 2, name, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 3, description, -1, SQLITE_STATIC);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to insert space");
		}
		else {
			total.space += r->length - 8;
			Space* s = malloc(SPACE_SIZE);
			s->id = spaces.count ? sp[spaces.count - 1]->id + 1 : 1;
			s->plotId = plotId;
			s->isVacant = 1;
			mallocate(name, &s->name);
			mallocate(description, &s->description);
			addToList(&spaces, s);
			addPublicResponse(r, s, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addTenant(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int size = 0;
	char* cursor, * name;
	name = strtok_s(&r->packet[12], "", &cursor), cursor++;
	Tenant** tp = tenants.data;
	for (uint i = 0; i < plots.count; i++) {
		if (_stricmp(tp[i]->name, name) == 0) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Tenant exists");
			break;
		}
	}
	if (message->isSuccess) {
		char* father, * mother, * husband, * address, * nid, * contactNo, * sql;
		father = strtok_s(0, "", &cursor), cursor++;
		mother = strtok_s(0, "", &cursor), cursor++;
		husband = strtok_s(0, "", &cursor), cursor++;
		address = strtok_s(0, "", &cursor), cursor++;
		nid = strtok_s(0, "", &cursor), cursor++;
		contactNo = cursor;

		sql = "INSERT INTO Tenants (Name, Father, Mother, Husband, Address, NID, ContactNo, HasLeft) VALUES(?, ?, ?, ?, ?, ?, ?, 0)";
		sqlite3_prepare_v2(db, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 2, father, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 5, address, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 7, contactNo, -1, SQLITE_STATIC);

		if (mother) sqlite3_bind_text(command, 3, mother, -1, SQLITE_STATIC);
		else sqlite3_bind_null(command, 3);
		if (husband) sqlite3_bind_text(command, 4, husband, -1, SQLITE_STATIC);
		else sqlite3_bind_null(command, 4);
		if (nid) sqlite3_bind_text(command, 6, nid, -1, SQLITE_STATIC);
		else sqlite3_bind_null(command, 6);

		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to insert tenant");
		}
		else {
			total.tenant += r->length - 8;
			Tenant* t = malloc(TENANT_SIZE);
			t->id = tenants.count ? tp[tenants.count - 1]->id + 1 : 1;
			mallocate(name, &t->name);
			mallocate(father, &t->father);
			mallocate(mother, &t->mother);
			mallocate(husband, &t->husband);
			mallocate(address, &t->address);
			mallocate(nid, &t->NID);
			mallocate(contactNo, &t->contactNo);
			t->hasLeft = 0;
			addToList(&tenants, t);
			addPublicResponse(r, t, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addHead(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int controlId, size = 0;
	char* name, * description;
	memcpy(&controlId, &r->packet[12], 4);
	name = strtok_s(&r->packet[16], "", &description), description++;
	Head** hp = heads.data;
	for (uint i = 0; i < heads.count; i++) {
		if (hp[i]->controlId != controlId) continue;
		if (_stricmp(hp[i]->name, name) == 0) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Head exists");
			break;
		}
	}
	if (message->isSuccess) {
		char* sql = "INSERT INTO Heads (ControlId, Name, Description) VALUES(?, ?, ?)";
		sqlite3_prepare_v2(db, sql, -1, &command, 0);
		sqlite3_bind_int(command, 1, controlId);
		sqlite3_bind_text(command, 2, name, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 3, description, -1, SQLITE_STATIC);

		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to insert head");
		}
		else {
			total.head += r->length - 8;
			Head* h = malloc(HEAD_SIZE);
			h->id = heads.count ? hp[heads.count - 1]->id + 1 : 1;
			h->controlId = controlId;
			mallocate(name, &h->name);
			mallocate(description, &h->description);
			addToList(&heads, h);
			addPublicResponse(r, h, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addLease(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int spaceId, size = 0;
	memcpy(&spaceId, &r->packet[16], 4);
	Space** sp = spaces.data;
	Space* space = { 0 };
	for (uint i = 0; i < spaces.count; i++) {
		if (sp[i]->id != spaceId) continue;
		if (!sp[i]->isVacant) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Space is letout");
		}
		space = sp[i];
		break;
	}
	if (message->isSuccess) {
		int plotId, tenantId, leaseId, result;
		char* cursor, * dateStart, * dateEnd, * business, * end, * sql;

		memcpy(&plotId, &r->packet[12], 4);
		memcpy(&tenantId, &r->packet[20], 4);
		dateStart = strtok_s(&r->packet[24], "", &cursor), cursor++;
		dateEnd = strtok_s(0, "", &cursor), cursor++;
		business = strtok_s(0, "", &cursor), cursor += 2;
		end = r->packet + r->length;
		leaseId = leases.count ? ((Lease**)leases.data)[leases.count - 1]->id + 1 : 1;

		List receivabelList = { 0, 5, malloc(receivabelList.capacity * RECEIVABLE_SIZE) };
		do {
			Receivable* r = malloc(RECEIVABLE_SIZE);
			r->leaseId = leaseId;
			memcpy(&r->headId, cursor + 4, 4);
			memcpy(&r->amount, cursor + 8, 4);
			addToList(&receivabelList, r);
			cursor += 12;
		} while (cursor < end);

		Receivable** rp = receivabelList.data;
		sqlite3_exec(db, "BEGIN", 0, 0, 0);
		for (uint i = 0; i < receivabelList.count; i++) {
			Receivable* r = rp[i];
			sql = "INSERT INTO Receivables VALUES(?, ?, ?)";
			sqlite3_prepare(db, sql, -1, &command, 0);
			sqlite3_bind_int(command, 1, r->leaseId);
			sqlite3_bind_int(command, 2, r->headId);
			sqlite3_bind_int(command, 3, r->amount);
			result = sqlite3_step(command);
			sqlite3_finalize(command);
			if (result != SQLITE_DONE) {
				message->isSuccess = 0;
				size = sprintf_s(message->text, sizeof(message->text), "Failed to add receivables");
				break;
			}
		}
		if (result == SQLITE_DONE) {
			sql = "UPDATE Spaces SET IsVacant = 0 WHERE Id = ?";
			sqlite3_prepare(db, sql, -1, &command, 0);
			sqlite3_bind_int(command, 1, spaceId);
			result = sqlite3_step(command);
			sqlite3_finalize(command);
			if (result != SQLITE_DONE) {
				message->isSuccess = 0;
				size = sprintf_s(message->text, sizeof(message->text), "Failed to update space");
			}
		}
		if (result == SQLITE_DONE) {
			sql = "INSERT INTO Leases(PlotId, SpaceId, TenantId, DateStart, Business, IsExpired) "
				"VALUES(@PlotId, @SpaceId, @TenantId, @Date, @Business, 0)";
			sqlite3_prepare(db, sql, -1, &command, 0);
			sqlite3_bind_int(command, 1, plotId);
			sqlite3_bind_int(command, 2, spaceId);
			sqlite3_bind_int(command, 3, tenantId);
			sqlite3_bind_text(command, 4, dateStart, -1, SQLITE_STATIC);
			sqlite3_bind_text(command, 5, business, -1, SQLITE_STATIC);
			result = sqlite3_step(command);
			sqlite3_finalize(command);
			if (result != SQLITE_DONE) {
				message->isSuccess = 0;
				size = sprintf_s(message->text, sizeof(message->text), "Failed to add lease");
			}
		}
		if (result == SQLITE_DONE) {
			sqlite3_exec(db, "COMMIT", 0, 0, 0);
			space->isVacant = 0;

			int newLeaseSize = 4 * 4 + 1;
			Lease* l = malloc(LEASE_SIZE);
			l->id = leaseId;
			l->plotId = plotId;
			l->spaceId = spaceId;
			l->tenantId = tenantId;
			l->isExpired = 0;
			newLeaseSize += mallocate(dateStart, &l->dateStart);
			newLeaseSize += mallocate(dateEnd, &l->dateEnd);
			newLeaseSize += mallocate(business, &l->business);

			int newReceivableSize = receivabelList.count * 12;
			total.lease += newLeaseSize;
			total.receivable += newReceivableSize;
			addToList(&leases, l);
			for (uint i = 0; i < receivabelList.count; i++) {
				addToList(&receivables, rp[i]);
			}
			NewLease* nl = malloc(NEW_LEASE_SIZE);
			nl->lease = l;
			nl->receivables = receivabelList;
			addPublicResponse(r, nl, newLeaseSize + newReceivableSize + 8);
		}
		else {
			sqlite3_exec(db, "ROLLBACK", 0, 0, 0);
			for (uint i = 0; i < receivabelList.count; i++) {
				free(rp[i]);
			}
			free(receivabelList.data);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void addTransactions(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int result, size = 0;
	char* cursor = &r->packet[8];
	char* end = r->packet + r->length;
	sqlite3_exec(db, "BEGIN", NULL, NULL, NULL);
	do {
		cursor += 4; //skip the TransactionId
		Transaction t;
		memcpy(&t.plotId, cursor, 4);
		memcpy(&t.spaceId, cursor + 4, 4);
		memcpy(&t.tenantId, cursor + 8, 4);
		memcpy(&t.controlId, cursor + 12, 4);
		memcpy(&t.headId, cursor + 16, 4);
		memcpy(&t.amount, cursor + 20, 4);
		memcpy(&t.isCash, cursor + 24, 1);
		cursor += 25;
		char* token, * sql;
		t.date = strtok_s(cursor, "", &token), token++;
		t.narration = strtok_s(0, "", &token), token++;
		cursor = token;

		sql = "INSERT INTO Transactions(Date, PlotId, SpaceId, TenantId, ControlId, HeadId, Amount, IsCash, Narration) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		sqlite3_prepare_v2(db, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, t.date, -1, SQLITE_STATIC);
		sqlite3_bind_int(command, 2, t.plotId);
		sqlite3_bind_int(command, 3, t.spaceId);
		sqlite3_bind_int(command, 4, t.tenantId);
		sqlite3_bind_int(command, 5, t.controlId);
		sqlite3_bind_int(command, 6, t.headId);
		sqlite3_bind_int(command, 7, t.amount);
		sqlite3_bind_int(command, 8, t.isCash);
		sqlite3_bind_text(command, 9, t.narration, -1, SQLITE_STATIC);

		result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			sqlite3_exec(db, "ROLLBACK", NULL, NULL, NULL);
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Error inserting record");
			break;
		}
	} while (cursor < end);

	if (result == SQLITE_DONE) sqlite3_exec(db, "COMMIT", NULL, NULL, NULL);
	addShortPersonalResponse(r, message, size);
}

static void editPlot(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int id, size = 0;
	char* name, * description;
	memcpy(&id, &r->packet[8], 4);
	name = strtok_s(&r->packet[12], "", &description), description++;

	Plot** pp = plots.data;
	Plot* p = { 0 };
	for (uint i = 0; i < plots.count; i++) {
		if (pp[i]->id == id) p = pp[i];
		if (_stricmp(pp[i]->name, name) == 0
			&& _stricmp(pp[i]->description, description) == 0) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Plot exists");
			break;
		}
	}
	if (message->isSuccess) {
		char* sql = "UPDATE Plots SET Name = ?, Description = ? WHERE Id = ?";
		sqlite3_prepare_v2(db, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 2, description, -1, SQLITE_STATIC);
		sqlite3_bind_int(command, 3, id);

		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result != SQLITE_DONE) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to update plot");
		}
		else {
			total.plot -= strlen(p->name) + strlen(p->description) + 2;
			free(p->name);
			free(p->description);
			total.plot += mallocate(name, &p->name);
			total.plot += mallocate(description, &p->description);
			addPublicResponse(r, p, r->length);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void editSpace(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int id, plotId, size = 0;
	byte isVacant;
	char* cursor, * vacatedOn, * name, * description;

	vacatedOn = strtok_s(&r->packet[8], "", &cursor), cursor++;
	memcpy(&id, cursor, 4), cursor += 4;
	memcpy(&plotId, cursor, 4), cursor += 4;

	name = strtok_s(cursor, "", &cursor), cursor++;
	description = cursor, cursor = r->packet + r->length - 1;
	memcpy(&isVacant, cursor, 1);
	if (!vacatedOn) vacatedOn = "";

	Space** sp = spaces.data;
	Space* s = { 0 };
	for (uint i = 0; i < spaces.count; i++) {
		if (sp[i]->plotId != plotId) continue;
		if (_stricmp(sp[i]->name, name) == 0
			&& _stricmp(sp[i]->description, description) == 0
			&& sp[i]->isVacant == isVacant) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Space exists and already is vacant");
			break;
		}
		if (sp[i]->id == id) s = sp[i];
	}
	if (message->isSuccess) {
		char* sql;
		char* description = name + strlen(name) + 1;
		int leaseId = 0, result = SQLITE_DONE;
		Lease* l = { 0 };
		sqlite3_exec(db, "BEGIN", 0, 0, 0);
		if (s->isVacant != isVacant) {
			Lease** lp = leases.data;
			for (uint i = 0; i < leases.count; i++) {
				if (lp[i]->isExpired) continue;
				if (lp[i]->spaceId == id) {
					l = lp[i];
					break;
				}
			}
			leaseId = l->id;
			sql = "UPDATE Leases SET DateEnd = ?, IsExpired = 1 WHERE Id = ?";
			sqlite3_prepare_v2(db, sql, -1, &command, 0);
			sqlite3_bind_text(command, 1, vacatedOn, -1, SQLITE_STATIC);
			sqlite3_bind_int(command, 2, leaseId);
			result = sqlite3_step(command);
			sqlite3_finalize(command);
			if (result != SQLITE_DONE) {
				message->isSuccess = 0;
				size = sprintf_s(message->text, sizeof(message->text), "Failed to update lease");
			}
		}
		if (result == SQLITE_DONE) {
			sql = "UPDATE Spaces SET PlotId = ?, Name = ?, Description = ?, IsVacant = ? WHERE Id = ?";
			sqlite3_prepare_v2(db, sql, -1, &command, 0);
			sqlite3_bind_int(command, 1, plotId);
			sqlite3_bind_text(command, 2, name, -1, SQLITE_STATIC);
			sqlite3_bind_text(command, 3, description, -1, SQLITE_STATIC);
			sqlite3_bind_int(command, 4, isVacant);
			sqlite3_bind_int(command, 5, id);
			result = sqlite3_step(command);
			sqlite3_finalize(command);
			if (result != SQLITE_DONE) {
				message->isSuccess = 0;
				size = sprintf_s(message->text, sizeof(message->text), "Failed to update space");
			}
		}
		if (result == SQLITE_DONE) {
			sqlite3_exec(db, "COMMIT", 0, 0, 0);
			if (l) {
				total.lease -= 1;
				total.lease += mallocate(vacatedOn, &l->dateEnd);
				l->isExpired = 1;
			}
			s->isVacant = isVacant;
			total.space -= strlen(s->name) + 1;
			total.space -= strlen(s->description) + 1;
			free(s->name);
			free(s->description);
			int broadcastSize = mallocate(name, &s->name);
			broadcastSize += mallocate(description, &s->description);
			total.space += broadcastSize;


			broadcastSize += (4 * 5 + 1);
			broadcastSize += strlen(vacatedOn) + 1;
			EditedSpace* ep = malloc(EDITED_SPACE_SIZE);
			ep->leaseId = leaseId;
			mallocate(vacatedOn, &ep->vaccatedOn);
			ep->space = s;
			addPublicResponse(r, ep, broadcastSize);
		}
		else sqlite3_exec(db, "ROLLBACK", 0, 0, 0);
	}
	addShortPersonalResponse(r, message, size);
}
static void editTenant(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int id, size = 0;
	byte hasLeft;
	char* cursor, * leftOn, * name, * father, * mother, * husband, * address, * nid, * contactNo;
	leftOn = strtok_s(&r->packet[8], "", &cursor), cursor++;
	memcpy_s(&id, 4, cursor, 4), cursor += 4;
	name = strtok_s(cursor, "", &cursor), cursor++;
	father = strtok_s(0, "", &cursor), cursor++;
	mother = strtok_s(0, "", &cursor), cursor++;
	husband = strtok_s(0, "", &cursor), cursor++;
	address = strtok_s(0, "", &cursor), cursor++;
	nid = strtok_s(0, "", &cursor), cursor++;
	contactNo = strtok_s(0, "", &cursor), cursor++;
	memcpy_s(&hasLeft, 1, cursor, 1);

	if (!mother) mother = "";
	if (!husband) husband = "";
	if (!nid) nid = "";

	Tenant** tp = tenants.data;
	Tenant* original = { 0 };
	for (uint i = 0; i < tenants.count; i++) {
		if (tp[i]->id == id) {
			original = tp[i];
			break;
		}
	}
	byte isEqual = 0;
	if (_stricmp(original->name, name) == 0
		&& _stricmp(original->father, father) == 0
		&& _stricmp(original->mother, mother) == 0
		&& _stricmp(original->husband, husband) == 0
		&& _stricmp(original->address, address) == 0
		&& _stricmp(original->NID, nid) == 0
		&& _stricmp(original->contactNo, contactNo) == 0
		&& original->hasLeft == hasLeft) {
		isEqual = 1;
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Tenant exists");
	}
	if (!isEqual) {
		int result;
		char* sql;
		List leaseList = { 0, 5, malloc(leaseList.capacity * POINTER_SIZE) };
		List spaceList = { 0, 5, malloc(spaceList.capacity * POINTER_SIZE) };
		Lease** lp = { 0 };
		sqlite3_exec(db, "BEGIN", 0, 0, 0);
		result = SQLITE_DONE;
		if (hasLeft && !original->hasLeft) {
			lp = leases.data;
			for (uint i = 0; i < leases.count; i++) {
				if (lp[i]->isExpired) continue;
				if (lp[i]->tenantId == id) addToList(&leaseList, lp[i]);
			}
			lp = leaseList.data;
			if (leaseList.count) {
				Space** sp = spaces.data;
				for (uint i = 0; i < leaseList.count; i++) {
					Space* s = { 0 };
					for (uint j = 0; j < spaces.count; j++) {
						if (sp[j]->id == lp[i]->spaceId) {
							s = sp[j];
							addToList(&spaceList, sp[j]);
							break;
						}
					}
					sql = "UPDATE Leases SET DateEnd = ?, IsExpired = 1 WHERE Id = ?";
					sqlite3_prepare_v2(db, sql, -1, &command, 0);
					sqlite3_bind_text(command, 1, leftOn, -1, SQLITE_STATIC);
					sqlite3_bind_int(command, 2, lp[i]->id);
					sqlite3_step(command);
					sqlite3_finalize(command);

					sql = "UPDATE Spaces SET IsVacant = 1 WHERE Id = ?";
					sqlite3_prepare_v2(db, sql, -1, &command, 0);
					sqlite3_bind_int(command, 2, s->id);
					result = sqlite3_step(command);
					sqlite3_finalize(command);
					if (result != SQLITE_DONE) {
						message->isSuccess = 0;
						size = sprintf_s(message->text, sizeof(message->text), "Failed to update space and lease");
						break;
					}
				}
			}
		}
		if (result == SQLITE_DONE) {
			sql = "UPDATE Tenants SET Name= ?, Father= ?, Mother= ?, Husband= ?, Address= ?, NID= ?, ContactNo= ?, HasLeft= ? WHERE Id= ?";
			sqlite3_prepare_v2(db, sql, -1, &command, 0);
			sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
			sqlite3_bind_text(command, 2, father, -1, SQLITE_STATIC);
			sqlite3_bind_text(command, 5, address, -1, SQLITE_STATIC);
			sqlite3_bind_text(command, 7, contactNo, -1, SQLITE_STATIC);
			sqlite3_bind_int(command, 8, hasLeft);
			sqlite3_bind_int(command, 9, id);
			if (mother) sqlite3_bind_text(command, 3, mother, -1, SQLITE_STATIC);
			else sqlite3_bind_null(command, 3);
			if (husband) sqlite3_bind_text(command, 4, husband, -1, SQLITE_STATIC);
			else sqlite3_bind_null(command, 4);
			if (nid) sqlite3_bind_text(command, 6, nid, -1, SQLITE_STATIC);
			else sqlite3_bind_null(command, 6);

			result = sqlite3_step(command);
			sqlite3_finalize(command);
			if (result != SQLITE_DONE) {
				message->isSuccess = 0;
				size = sprintf_s(message->text, sizeof(message->text), "Failed to update tenant");
			}
		}
		if (result == SQLITE_DONE) {
			sqlite3_exec(db, "COMMIT", 0, 0, 0);
			for (uint i = 0; i < leaseList.count; i++) {
				lp[i]->isExpired = 1;
				total.lease += mallocate(leftOn, &lp[i]->dateEnd) - 1;
			}
			Space** sp = spaceList.data;
			for (uint i = 0; i < spaceList.count; i++) {
				sp[i]->isVacant = 1;
			}
			total.tenant -=
				strlen(original->name)
				+ strlen(original->father)
				+ strlen(original->mother)
				+ strlen(original->husband)
				+ strlen(original->address)
				+ strlen(original->NID)
				+ strlen(original->contactNo) + 7;

			free(original->name);
			free(original->father);
			free(original->mother);
			free(original->husband);
			free(original->address);
			free(original->contactNo);
			free(original->NID);

			int newSize = mallocate(name, &original->name);
			newSize += mallocate(father, &original->father);
			newSize += mallocate(mother, &original->mother);
			newSize += mallocate(husband, &original->husband);
			newSize += mallocate(address, &original->address);
			newSize += mallocate(nid, &original->NID);
			newSize += mallocate(contactNo, &original->contactNo);
			total.tenant += newSize;
			original->hasLeft = hasLeft;

			EditedTenant* et = malloc(EDITED_TENANT_SIZE);
			newSize += mallocate(leftOn, &et->leftOn);
			et->tenant = original;
			newSize += (4 + 1 + 8);
			addPublicResponse(r, et, newSize);
		}
		else sqlite3_exec(db, "ROLLBACK", 0, 0, 0);

		free(leaseList.data);
		free(spaceList.data);
	}
	addShortPersonalResponse(r, message, size);
}
static void editHead(Request* r) {
	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;

	int id, controlId, size = 0;
	char* name, * description;
	memcpy(&id, &r->packet[8], 4);
	memcpy(&controlId, &r->packet[12], 4);
	name = strtok_s(&r->packet[16], "", &description), description++;
	Head** hp = heads.data;
	Head* h = { 0 };
	for (uint i = 0; i < heads.count; i++) {
		if (hp[i]->id == id) h = hp[i];
		if (hp[i]->controlId != controlId) continue;
		if (_stricmp(hp[i]->name, name) == 0) {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Plot exists");
			break;
		}
	}
	if (message->isSuccess) {
		char* sql = "UPDATE Heads SET ControlId = ?, Name = ?, Description = ? WHERE Id = ?";
		sqlite3_prepare_v2(db, sql, -1, &command, 0);
		sqlite3_bind_int(command, 1, controlId);
		sqlite3_bind_text(command, 2, name, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 3, description, -1, SQLITE_STATIC);
		sqlite3_bind_int(command, 4, id);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		if (result == SQLITE_DONE) {
			total.head -= strlen(h->name) + strlen(h->description) + 2;
			free(h->name);
			free(h->description);
			h->controlId = controlId;
			total.head += mallocate(name, &h->name);
			total.head += mallocate(description, &h->description);
			addPublicResponse(r, h, r->length);
		}
		else {
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to update head");
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void editLease(Request* r) {
	Lease* original = { 0 };
	List editedReceivables = { 0, 5, malloc(5 * RECEIVABLE_SIZE) };
	List originalReceivables = { 0, 5, malloc(5 * RECEIVABLE_SIZE) };

	byte isExpired;
	int id, plotId, spaceId, tenantId, size = 0;
	char* cursor, * dateStart, * dateEnd, * business, * end = r->packet + r->length;

	memcpy(&id, &r->packet[8], 4);
	memcpy(&plotId, &r->packet[12], 4);
	memcpy(&spaceId, &r->packet[16], 4);
	memcpy(&tenantId, &r->packet[20], 4);
	dateStart = strtok_s(&r->packet[24], "", &cursor), cursor++;
	dateEnd = strtok_s(0, "", &cursor), cursor++;
	business = strtok_s(0, "", &cursor), cursor++;
	memcpy(&isExpired, cursor, 1), cursor++;
	if (!dateEnd) dateEnd = "";

	do {
		Receivable* r = malloc(RECEIVABLE_SIZE);
		memcpy(&r->leaseId, cursor, 4);
		memcpy(&r->headId, cursor + 4, 4);
		memcpy(&r->amount, cursor + 8, 4);
		addToList(&editedReceivables, r);
		cursor += 12;
	} while (cursor < end);

	int originalIndex = 0;
	Lease** lp = leases.data;
	Receivable** rl = receivables.data;
	for (uint i = 0; i < leases.count; i++) {
		if (lp[i]->id != id) continue;
		original = lp[i];
		originalIndex = i;
		break;
	}
	for (uint i = 0; i < receivables.count; i++) {
		if (rl[i]->leaseId != original->id) continue;
		addToList(&originalReceivables, rl[i]);
	}
	byte isLeaseEqual = 0;
	byte areReceivablesEqual = 1;
	if (plotId == original->plotId
		&& spaceId == original->spaceId
		&& tenantId == original->tenantId
		&& isExpired == original->isExpired
		&& _stricmp(dateStart, original->dateStart) == 0
		&& _stricmp(dateEnd, original->dateEnd) == 0
		&& _stricmp(business, original->business) == 0) isLeaseEqual = 1;

	rl = originalReceivables.data;
	Receivable** erl = editedReceivables.data;
	if (originalReceivables.count != editedReceivables.count) areReceivablesEqual = 0;
	else {
		for (uint i = 0; i < editedReceivables.count; i++) {
			int headId = 0;
			int amount = 0;
			for (uint j = 0; j < originalReceivables.count; j++) {
				if (rl[j]->headId == erl[i]->headId) {
					headId = rl[j]->headId;
					amount = rl[j]->amount;
					break;
				}
			}
			if (headId == 0) {
				areReceivablesEqual = 0;
				break;
			}
			else if (amount != erl[i]->amount) {
				areReceivablesEqual = 0;
				break;
			}
		}
	}

	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	if (isLeaseEqual && areReceivablesEqual) {
		for (uint i = 0; i < editedReceivables.count; i++) {
			free(erl[i]);
		}
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Already been edited");
	}
	else {
		char* sql;
		int result = SQLITE_DONE;
		sqlite3_exec(db, "BEGIN", 0, 0, 0);
		if (!areReceivablesEqual) {
			sql = "DELETE FROM Receivables WHERE LeaseId = ?";
			sqlite3_prepare_v2(db, sql, -1, &command, 0);
			sqlite3_bind_int(command, 1, id);
			result = sqlite3_step(command);
			sqlite3_finalize(command);
			if (result == SQLITE_DONE) {
				for (uint i = 0; i < editedReceivables.count; i++) {
					sql = "INSERT INTO Receivables VALUES(?, ?, ?)";
					sqlite3_prepare_v2(db, sql, -1, &command, 0);
					sqlite3_bind_int(command, 1, erl[i]->leaseId);
					sqlite3_bind_int(command, 2, erl[i]->headId);
					sqlite3_bind_int(command, 3, erl[i]->amount);
					result = sqlite3_step(command);
					sqlite3_finalize(command);
					if (result != SQLITE_DONE) break;
				}
			}
		}
		if (result == SQLITE_DONE) {
			if (!isLeaseEqual) {
				if (isExpired && !original->isExpired) {
					sql = "UPDATE Spaces SET IsVacant = 1 WHERE Id = ?";;
					sqlite3_prepare_v2(db, sql, -1, &command, 0);
					sqlite3_bind_int(command, 1, spaceId);
					result = sqlite3_step(command);
					sqlite3_finalize(command);
				}
				if (spaceId != original->spaceId) {
					sql = "UPDATE Spaces SET IsVacant = 1 WHERE Id = ?";
					sqlite3_prepare_v2(db, sql, -1, &command, 0);
					sqlite3_bind_int(command, 1, original->spaceId);
					result = sqlite3_step(command);
					sqlite3_finalize(command);

					sql = "UPDATE Spaces SET IsVacant = 0 WHERE Id = ?";
					sqlite3_prepare_v2(db, sql, -1, &command, 0);
					sqlite3_bind_int(command, 1, spaceId);
					result = sqlite3_step(command);
					sqlite3_finalize(command);
				}
				if (result == SQLITE_DONE) {
					sql = "UPDATE Leases SET PlotId =?, SpaceId =?, TenantId =?, DateStart =?, DateEnd =?, Business =?, IsExpired =? WHERE Id =?";
					sqlite3_prepare_v2(db, sql, -1, &command, 0);
					sqlite3_bind_int(command, 1, plotId);
					sqlite3_bind_int(command, 2, spaceId);
					sqlite3_bind_int(command, 3, tenantId);
					sqlite3_bind_text(command, 4, dateStart, -1, SQLITE_STATIC);
					sqlite3_bind_text(command, 6, business, -1, SQLITE_STATIC);
					sqlite3_bind_int(command, 7, isExpired);
					sqlite3_bind_int(command, 8, id);

					if (strlen(dateEnd)) sqlite3_bind_text(command, 5, dateEnd, -1, SQLITE_STATIC);
					else sqlite3_bind_null(command, 5);

					result = sqlite3_step(command);
					sqlite3_finalize(command);
				}
			}
		}
		if (result != SQLITE_DONE) {
			sqlite3_exec(db, "ROLLBACK", 0, 0, 0);
			for (uint i = 0; i < editedReceivables.count; i++) {
				free(erl[i]);
			}
			free(editedReceivables.data);
			free(originalReceivables.data);
			message->isSuccess = 0;
			size = sprintf_s(message->text, sizeof(message->text), "Failed to update lease");
		}
		else {
			sqlite3_exec(db, "COMMIT", 0, 0, 0);
			NewLease* nl = malloc(NEW_LEASE_SIZE);
			int length = 0;
			if (!areReceivablesEqual) {
				length = editedReceivables.count * 12;
				total.receivable -= originalReceivables.count * 12;
				total.receivable += length;
				for (uint i = 0; i < originalReceivables.count; i++) {
					removeFromList(&receivables, rl[i]);
					free(rl[i]);
				}
				for (uint i = 0; i < editedReceivables.count; i++) {
					addToList(&receivables, erl[i]);
				}
				free(originalReceivables.data);
				nl->receivables = editedReceivables;
			}
			else {
				length = originalReceivables.count * 12;
				for (uint i = 0; i < editedReceivables.count; i++) {
					free(erl[i]);
				}
				free(editedReceivables.data);
				nl->receivables = originalReceivables;
			}
			if (!isLeaseEqual) {
				original->plotId = plotId;
				original->spaceId = spaceId;
				original->tenantId = tenantId;
				original->isExpired = isExpired;
				int newLength = 0;
				if (strcmp(original->dateStart, dateStart) != 0) {
					total.lease -= strlen(original->dateStart) + 1;
					free(original->dateStart);
					int length = mallocate(dateStart, &original->dateStart);
					total.lease += length;
					newLength += length;
				}
				else newLength += strlen(original->dateStart) + 1;
				if (strcmp(original->dateEnd, dateEnd) != 0) {
					total.lease -= strlen(original->dateEnd) + 1;
					free(original->dateEnd);
					int length = mallocate(dateEnd, &original->dateEnd);
					total.lease += length;
					newLength += length;
				}
				else newLength += strlen(original->dateEnd) + 1;
				if (strcmp(original->business, business) != 0) {
					total.lease -= strlen(original->business) + 1;
					free(original->business);
					int length = mallocate(business, &original->business);
					total.lease += length;
					newLength += length;
				}
				else newLength += strlen(original->business) + 1;
				length += newLength + 4 * 4 + 1;
				
				if (isExpired && !original->isExpired) {
					Space** sp = spaces.data;
					for (uint i = 0; i < spaces.count; i++) {
						if (sp[i]->id == spaceId) {
							sp[i]->isVacant = 1;
							break;
						}
					}
				}
				if (spaceId != original->spaceId) {
					Space** sp = spaces.data;
					int count = 0;
					for (uint i = 0; i < spaces.count; i++) {
						if (sp[i]->id == spaceId) {
							sp[i]->isVacant = 0;
							count++;
						}
						if (sp[i]->id == original->spaceId) {
							sp[i]->isVacant = 1;
							count++;
						}
						if (count == 2) break;
					}
				}
			}
			else {
				length += 4 * 4 + 1 + strlen(original->dateStart)
					+ strlen(original->dateEnd)
					+ strlen(original->business)
					+ 3;
			}
			nl->lease = original;
			addPublicResponse(r, nl, length + 8);
		}
	}
	addShortPersonalResponse(r, message, size);
}
static void editTransaction(Request* r) {
	int id, plotId, spaceId, tenantId, controlId, headId, amount;
	byte isCash;
	char* date, * narration;
	memcpy_s(&id, 4, &r->packet[8], 4);
	memcpy_s(&plotId, 4, &r->packet[12], 4);
	memcpy_s(&spaceId, 4, &r->packet[16], 4);
	memcpy_s(&tenantId, 4, &r->packet[20], 4);
	memcpy_s(&controlId, 4, &r->packet[24], 4);
	memcpy_s(&headId, 4, &r->packet[28], 4);
	memcpy_s(&amount, 4, &r->packet[32], 4);
	memcpy_s(&isCash, 1, &r->packet[36], 1);
	date = strtok_s(&r->packet[37], "", &narration), narration++;

	char* sql = "UPDATE Transactions SET Date=?, PlotId=?, SpaceId=?, TenantId=?, ControlId=?, HeadId=?, IsCash=?, Narration=?, Amount=? WHERE Id=?";
	sqlite3_prepare_v2(db, sql, -1, &command, 0);
	sqlite3_bind_text(command, 1, date, -1, SQLITE_STATIC);
	sqlite3_bind_int(command, 2, plotId);
	sqlite3_bind_int(command, 3, spaceId);
	sqlite3_bind_int(command, 4, tenantId);
	sqlite3_bind_int(command, 5, controlId);
	sqlite3_bind_int(command, 6, headId);
	sqlite3_bind_int(command, 7, isCash);
	sqlite3_bind_int(command, 9, amount);
	sqlite3_bind_int(command, 10, id);
	if (narration) sqlite3_bind_text(command, 8, narration, -1, SQLITE_STATIC);
	else sqlite3_bind_null(command, 8);

	int result = sqlite3_step(command);
	sqlite3_finalize(command);

	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	int size = 0;
	if (result == SQLITE_DONE) {
		if (!narration) narration = "";
		int length = 29;
		Transaction* t = malloc(TRANSACTION_SIZE);
		t->id = id;
		t->plotId = plotId;
		t->spaceId = spaceId;
		t->tenantId = tenantId;
		t->controlId = controlId;
		t->headId = headId;
		t->amount = amount;
		t->isCash = isCash;
		length += mallocate(date, &t->date);
		length += mallocate(narration, &t->narration);
		addPublicResponse(r, t, length + 8);
	}
	else {
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Failed to update tranaction");
	}
	addShortPersonalResponse(r, message, size);
}
static void deleteTransaction(Request* r) {
	char* cursor = r->packet + 8;
	int id;
	memcpy(&id, cursor, 4);
	char* sql = "DELETE FROM Transactions WHERE Id = ?";
	sqlite3_prepare_v2(db, sql, -1, &command, 0);
	sqlite3_bind_int(command, 1, id);

	int result = sqlite3_step(command);
	sqlite3_finalize(command);

	ShortMessage* message = malloc(SHORT_MESSAGE_SIZE);
	message->isSuccess = 1;
	int size = 0;
	if (result == SQLITE_DONE) {
		int length = 29;
		Transaction* t = malloc(TRANSACTION_SIZE);
		t->id = id;
		memcpy(&t->plotId, cursor + 4, 4);
		memcpy(&t->spaceId, cursor + 8, 4);
		memcpy(&t->tenantId, cursor + 12, 4);
		memcpy(&t->controlId, cursor + 16, 4);
		memcpy(&t->headId, cursor + 20, 4);
		memcpy(&t->amount, cursor + 24, 4);
		memcpy(&t->isCash, cursor + 28, 1);
		cursor += 29;
		length += mallocate(cursor, &t->date);
		cursor += length;
		length += mallocate(cursor, &t->narration);
		addPublicResponse(r, t, length + 8);
	}
	else {
		message->isSuccess = 0;
		size = sprintf_s(message->text, sizeof(message->text), "Failed to delete tranaction");
	}
	addShortPersonalResponse(r, message, size);
}

static void getTransactions(Request* r) {
	char* date = &r->packet[8];
	char query[55];
	sprintf_s(query, sizeof(query), "SELECT * FROM Transactions WHERE Date = '%s'", date);

	int size = 0;
	List list = { 0, 50, malloc(list.capacity * POINTER_SIZE) };
	sqlite3_prepare_v2(db, query, -1, &command, NULL);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Transaction* t = malloc(TRANSACTION_SIZE);
		t->id = sqlite3_column_int(command, 0);
		t->plotId = sqlite3_column_int(command, 2);
		t->spaceId = sqlite3_column_int(command, 3);
		t->tenantId = sqlite3_column_int(command, 4);
		t->controlId = sqlite3_column_int(command, 5);
		t->headId = sqlite3_column_int(command, 6);
		t->amount = sqlite3_column_int(command, 7);
		t->isCash = sqlite3_column_int(command, 8);
		size += (29
			+ mallocate(sqlite3_column_text(command, 1), &t->date)
			+ mallocate(sqlite3_column_text(command, 9), &t->narration)
			);
		addToList(&list, t);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getPlotDueChart(Request* r) {
	int id;
	memcpy_s(&id, 4, &r->packet[8], 4);
	char* date = &r->packet[12];
	char* month = "strftime('%m', Date)";
	char* year = "strftime('%Y', Date)";
	char* monthYear1 = "strftime('%m - %Y', Date)";
	char* monthYear2 = "strftime('%m-%Y', Date)";
	char where1[60];
	char where2[100];
	char query[1100];

	if (id == 0) {
		sprintf_s(where1, sizeof(where1), "WHERE Date < '%s'", date);
		sprintf_s(where2, sizeof(where2), "WHERE Date >= '%s'", date);
	}
	else {
		sprintf_s(where1, sizeof(where1), "WHERE PlotId = %d AND Date < '%s'", id, date);
		sprintf_s(where2, sizeof(where2), "WHERE PlotId = %d AND Date >= '%s'", id, date);
	}
	sprintf_s(query, sizeof(query), "WITH t0(Date, Month, TenantId, Amount) AS( "
		"SELECT '' Date, '' Month, TenantId, "
		"SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) - "
		"SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount "
		"FROM Transactions %s GROUP BY TenantId "
		"), "
		"t1 AS( "
		"SELECT Date, %s Month, TenantId, "
		"SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) - "
		"SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount "
		"FROM Transactions tn %s GROUP BY TenantId, %s "
		"ORDER BY %s, %s "
		"), "
		"t3 AS(SELECT * FROM t0 UNION ALL SELECT * FROM t1), "
		"t4 AS( "
		"SELECT Date, Month, TenantId, t.Name, Amount, ROW_NUMBER() OVER(PARTITION BY TenantId) RowNum "
		"FROM t3 "
		"LEFT JOIN Tenants t ON t.Id = TenantId "
		"), "
		"t5 AS(SELECT Month, Name, SUM(Amount) OVER(PARTITION BY TenantId ORDER BY RowNum) Due, Date FROM t4) "
		"SELECT * FROM t5 WHERE Month <> '' "
		"ORDER BY %s, %s", where1, monthYear1, where2, monthYear2, year, month, year, month);

	int size = 0;
	List list = { 0, 50, malloc(list.capacity * POINTER_SIZE) };
	sqlite3_prepare_v2(db, query, -1, &command, NULL);
	while (sqlite3_step(command) == SQLITE_ROW) {
		PlotwiseDue* p = malloc(PLOTWISE_DUE_SIZE);
		p->due = sqlite3_column_int(command, 2);
		size += (4
			+ mallocate(sqlite3_column_text(command, 0), &p->month)
			+ mallocate(sqlite3_column_text(command, 1), &p->tenant)
			);
		addToList(&list, p);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getPlotWiseRent(Request* r) {
	int id;
	memcpy_s(&id, 4, &r->packet[8], 4);
	char* date = &r->packet[12];
	char* month = "strftime('%m', Date)";
	char* year = "strftime('%Y', Date)";
	char* monthYear1 = "strftime('%m - %Y', Date)";
	char* monthYear2 = "strftime('%m-%Y', Date)";
	char query[1000];

	if (id == 0) sprintf_s(query, sizeof(query), "SELECT 'All plots', t.Name, %s Month, "
		"coalesce(SUM(CASE WHEN ControlId = 1 THEN Amount END), 0) Rent, "
		"coalesce(SUM(CASE WHEN ControlId = 2 AND HeadId = 5 AND IsCash = 0 THEN Amount END), 0) Cash, "
		"coalesce(SUM(CASE WHEN ControlId = 2 AND HeadId = 5 AND IsCash = 2 THEN Amount END), 0) Mobile, "
		"coalesce(SUM(CASE WHEN ControlId = 2 AND HeadId = 5 AND IsCash = 1 THEN Amount END), 0) Kind, "
		"tn.PlotId "
		"From Transactions tn "
		"LEFT JOIN Tenants t ON t.Id = tn.TenantId "
		"WHERE Date > '%s' "
		"GROUP BY TenantId, %s "
		"ORDER BY %s, %s", monthYear1, date, monthYear2, year, month);
	else sprintf_s(query, sizeof(query), "SELECT p.Name, t.Name, %s Month, "
		"coalesce(SUM(CASE WHEN ControlId = 1 THEN Amount END), 0) Rent, "
		"coalesce(SUM(CASE WHEN ControlId = 2 AND HeadId = 5 AND IsCash = 0 THEN Amount END), 0) Cash, "
		"coalesce(SUM(CASE WHEN ControlId = 2 AND HeadId = 5 AND IsCash = 2 THEN Amount END), 0) Mobile, "
		"coalesce(SUM(CASE WHEN ControlId = 2 AND HeadId = 5 AND IsCash = 1 THEN Amount END), 0) Kind, "
		"tn.PlotId "
		"From Transactions tn "
		"LEFT JOIN Plots p ON p.Id = tn.PlotId "
		"LEFT JOIN Tenants t ON t.Id = tn.TenantId "
		"WHERE PlotId = %d AND Date > '%s' "
		"GROUP BY TenantId, %s "
		"ORDER BY %s, %s", monthYear1, id, date, monthYear2, year, month);

	int size = 0;
	List list = { 0, 50, malloc(list.capacity * POINTER_SIZE) };
	sqlite3_prepare_v2(db, query, -1, &command, NULL);
	while (sqlite3_step(command) == SQLITE_ROW) {
		PlotwiseRent* pr = malloc(PLOTWISE_RENT_SIZE);
		pr->rent = sqlite3_column_int(command, 3);
		pr->cash = sqlite3_column_int(command, 4);
		pr->mobile = sqlite3_column_int(command, 5);
		pr->kind = sqlite3_column_int(command, 6);
		pr->plotId = sqlite3_column_int(command, 7);
		pr->total = (pr->cash + pr->kind + pr->mobile);
		size += (4 * 6
			+ mallocate(sqlite3_column_text(command, 0), &pr->plot)
			+ mallocate(sqlite3_column_text(command, 1), &pr->tenant)
			+ mallocate(sqlite3_column_text(command, 2), &pr->month)
			);
		addToList(&list, pr);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getTenantDetail(Request* r) {
	int id;
	char date[11];
	memcpy_s(&id, 4, &r->packet[8], 4);
	Tenant* tenant = { 0 };
	Tenant** tp = tenants.data;
	for (size_t i = 0; i < tenants.count; i++) {
		if (tp[i]->id == id) {
			tenant = tp[i];
			break;
		}
	}
	if (tenant->hasLeft) {
		char* sql1 = "SELECT MAX(Date) FROM Transactions WHERE TenantId = ?";
		sqlite3_prepare_v2(db, sql1, -1, &command, NULL);
		sqlite3_bind_int(command, 1, id);
		sqlite3_step(command);
		char* lastDate = (char*)sqlite3_column_text(command, 0);
		char year[4];
		memcpy_s(&year, 4, lastDate, 4);
		sprintf_s(date, sizeof(date), "%d-%s", atoi(year) - 1, &lastDate[5]);
		sqlite3_finalize(command);
	}
	else {
		time_t ti = time(0);
		struct tm lt;
		localtime_s(&lt, &ti);
		char year[5], month[3], day[3];
		sprintf_s(year, sizeof(year), "%d", 1900 + lt.tm_year - 1);
		if (lt.tm_mon < 10) sprintf_s(month, sizeof(month), "0%d", lt.tm_mon);
		else sprintf_s(month, sizeof(month), "%d", lt.tm_mon);
		if (lt.tm_mday < 10) sprintf_s(day, sizeof(day), "0%d", lt.tm_mday);
		else sprintf_s(day, sizeof(day), "%d", lt.tm_mday);
		sprintf_s(date, sizeof(date), "%s-%s-%s", year, month, day);
	}
	TenantDetail* details = malloc(TENANT_DETAIL_SIZE);
	details->deposit = 0;

	char* sql2 =
		"SELECT coalesce(SUM(CASE WHEN HeadId = 4 THEN Amount ELSE -Amount END), 0) Deposit "
		"FROM Transactions WHERE TenantId = ? AND HeadId IN(4, 6)";
	sqlite3_prepare_v2(db, sql2, -1, &command, NULL);
	sqlite3_bind_int(command, 1, id);
	sqlite3_step(command);
	details->deposit = sqlite3_column_int(command, 0);
	sqlite3_finalize(command);

	char sql3[1500];
	sprintf_s(sql3, sizeof(sql3), "WITH t0(Date, Plot, Space, Tenant, Control, Due, Cash, Mobile, Kind) AS("
		"SELECT '' Date, '' Plot, '' Space, '' Tenant, tn.ControlId, "
		"SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) - "
		"SUM(CASE WHEN ControlId <> 1 THEN Amount ELSE 0 END) Due, "
		"0 Cash, 0 Mobile, 0 Kind FROM Transactions tn "
		"WHERE TenantId = %d AND ControlId <> 3 AND HeadId <> 4 AND Date < '%s' "
		"GROUP BY Plot, Space "
		"), "
		"t1 AS("
		"SELECT Date, p.Name Plot, s.Name Space, t.Name Tenant, tn.ControlId, "
		"SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) Due, "
		"SUM(CASE WHEN ControlId <> 1 AND IsCash = 0 THEN Amount ELSE 0 END) Cash, "
		"SUM(CASE WHEN ControlId <> 1 AND IsCash = 2 THEN Amount ELSE 0 END) Mobile, "
		"SUM(CASE WHEN ControlId <> 1 AND IsCash = 1 THEN Amount ELSE 0 END) Kind "
		"FROM Transactions tn "
		"LEFT JOIN Plots p ON p.Id = tn.PlotId "
		"LEFT JOIN Spaces s ON s.Id = tn.SpaceId "
		"LEFT JOIN Tenants t ON t.Id = tn.TenantId "
		"WHERE TenantId = %d AND ControlId <> 3 AND HeadId <> 4 AND Date >= '%s' "
		"GROUP BY Plot, Space, HeadId, Date "
		"ORDER BY Date, ControlId DESC "
		"), "
		"t2 AS(SELECT * FROM t0 UNION ALL SELECT * FROM t1), "
		"t3 AS(SELECT *, ROW_NUMBER() OVER(ORDER BY(SELECT 1)) RowNum FROM t2), "
		"t4 AS(SELECT *, SUM(Due - Cash - Mobile - Kind) OVER(ORDER BY RowNum) Balance FROM t3), "
		"t5 AS(SELECT *, LAG(Balance, 1, 0) OVER(ORDER BY RowNum) Pos FROM t4) "
		"SELECT Date, Plot, Space, Tenant, Cash, Mobile, Kind, Pos AS Due FROM t5 "
		"WHERE Cash > 0 OR Mobile > 0 OR Kind > 0 "
		"ORDER BY Date", id, date, id, date);

	int size = 4;
	List list = { 0, 15, malloc(list.capacity * POINTER_SIZE) };
	sqlite3_prepare_v2(db, sql3, -1, &command, NULL);
	while (sqlite3_step(command) == SQLITE_ROW) {
		RentPayment* p = malloc(RENT_PAYMENT_SIZE);
		p->cash = sqlite3_column_int(command, 4);
		p->mobile = sqlite3_column_int(command, 5);
		p->kind = sqlite3_column_int(command, 6);
		p->due = sqlite3_column_int(command, 7);
		p->totalPaid = p->cash + p->mobile + p->kind;
		size += (4 * 5
			+ mallocate(sqlite3_column_text(command, 0), &p->date)
			+ mallocate(sqlite3_column_text(command, 1), &p->plot)
			+ mallocate(sqlite3_column_text(command, 2), &p->space)
			+ mallocate(sqlite3_column_text(command, 3), &p->tenant)
			);
		addToList(&list, p);
	}
	sqlite3_finalize(command);

	details->payments = list.data;
	ResponsePersonal* response = malloc(RESPONSE_PERSONAL_SIZE);
	response->sender = r->sender;
	response->function = r->function;
	response->size = size;
	response->data = details;
	response->count = list.count;
	putInto(&personalResponses, response);
}
static void getDepositDueRent(Request* r) {
	byte state;
	memcpy_s(&state, 1, &r->packet[8], 1);
	char query[300];
	if (state == 1) sprintf_s(query, sizeof(query), "SELECT PlotId, SpaceId, TenantId, "
		"SUM(CASE WHEN ControlId = 2 THEN 1 ELSE - 1 END * Amount) Amount "
		"FROM Transactions "
		"LEFT JOIN Tenants t ON t.Id = TenantId "
		"WHERE HeadId IN(4, 6) AND t.HasLeft = 0 "
		"GROUP BY PlotId, SpaceId, TenantId");
	else sprintf_s(query, sizeof(query), "SELECT PlotId, SpaceId, TenantId, "
		"SUM(CASE WHEN ControlId = 1 THEN 1 ELSE - 1 END * Amount) Amount "
		"FROM Transactions "
		"LEFT JOIN Tenants t ON t.Id = TenantId "
		"WHERE ControlId IN(1, 2) AND HeadId <> 4 AND t.HasLeft = 0 "
		"GROUP BY PlotId, SpaceId, TenantId");

	int size = 0;
	List list = { 0, 50, malloc(list.capacity * POINTER_SIZE) };
	sqlite3_prepare_v2(db, query, -1, &command, NULL);
	while (sqlite3_step(command) == SQLITE_ROW) {
		DepositDueRent* r = malloc(DEPOSIT_DUE_RENT_SIZE);
		r->state = state;
		r->plotId = sqlite3_column_int(command, 0);
		r->spaceId = sqlite3_column_int(command, 1);
		r->tenantId = sqlite3_column_int(command, 2);
		r->amount = sqlite3_column_int(command, 3);
		size += (1 + 4 * 4);
		addToList(&list, r);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getBalance(Request* r) {
	int plotId;
	byte hasLeft;
	memcpy_s(&plotId, 4, &r->packet[8], 4);
	memcpy_s(&hasLeft, 1, &r->packet[12], 1);
	char* sql = "WITH t0(Space, Tenant, Amount, ControlId, HeadId, TenantId, SpaceId) AS("
		"SELECT s.Name, t.Name, SUM(tn.Amount), tn.ControlId, tn.HeadId, tn.TenantId, tn.SpaceId FROM Transactions tn "
		"LEFT JOIN Plots p ON p.Id = tn.PlotId "
		"LEFT JOIN Spaces s ON s.Id = tn.SpaceId "
		"LEFT JOIN Tenants t ON t.Id = tn.TenantId "
		"WHERE tn.PlotId = ? AND TenantId IN(SELECT Id FROM Tenants WHERE HasLeft = ?) "
		"GROUP BY t.Name, s.Name, tn.HeadId "
		"ORDER BY s.Name "
		"), "
		"t1(Space, Tenant, Security, Receivable, Receipt, TenantId, SpaceId) AS("
		"SELECT Space, Tenant, "
		"SUM(CASE HeadId WHEN 4 THEN 1 WHEN 6 THEN - 1 ELSE 0 END * Amount) Security, "
		"SUM(CASE ControlId WHEN 1 THEN Amount ELSE 0 END) Receivable, "
		"SUM(CASE WHEN HeadId = 5 THEN Amount ELSE 0 END) Receipt, "
		"TenantId, SpaceId FROM t0 "
		"GROUP BY Tenant, Space "
		"), "
		"t2(Space, Tenant, Security, Due, TenantId, SpaceId) AS("
		"SELECT Space, Tenant, Security, (Receivable - Receipt) Due, TenantId, SpaceId FROM t1 "
		"), "
		"t3(Space, Tenant, Security, Due, LeaseId, DateStart, DateEnd, IsExpired) AS("
		"SELECT Space, Tenant, Security, Due, l.Id, l.DateStart, l.DateEnd, l.IsExpired FROM t2 tn "
		"LEFT JOIN Leases l ON l.TenantId = tn.TenantId AND l.SpaceId = tn.SpaceId "
		"), "
		"t4(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired) AS("
		"SELECT Space, Tenant, Security, COALESCE(SUM(r.Amount), 0), Due, DateStart, DateEnd, IsExpired FROM t3 tn "
		"LEFT JOIN Receivables r ON r.LeaseId = tn.LeaseId "
		"GROUP BY tn.Tenant, tn.LeaseId "
		"), "
		"t5(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired, Counts) AS("
		"SELECT*, COUNT(Tenant) "
		"FROM t4 GROUP BY Tenant "
		"), "
		"t6(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired, Counts, SCount) AS("
		"SELECT t1.Space, t1.Tenant, t1.Security, t1.Rent, t1.Due, t1.DateStart, t1.DateEnd, t1.IsExpired, t2.Counts, "
		"COUNT(t1.Space) OVER(PARTITION BY t1.Tenant, t1.Space) SCount FROM t4 t1 "
		"LEFT JOIN t5 t2 ON t1.Tenant = t2.Tenant "
		"ORDER BY t2.Counts DESC, t1.Tenant ASC "
		") "
		"SELECT Space, Tenant, Security, Rent, "
		"CASE WHEN SCount > 1 AND IsExpired = 1 THEN 0 ELSE Due END AS Due, "
		"COALESCE(DateStart, ''), COALESCE(DateEnd, ''), Counts, COALESCE(IsExpired, 0) FROM t6";

	sqlite3_prepare_v2(db, sql, -1, &command, NULL);
	sqlite3_bind_int(command, 1, plotId);
	sqlite3_bind_int(command, 2, hasLeft);

	int size = 0;
	List list = { 0, 50, malloc(list.capacity * POINTER_SIZE) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		Balance* b = malloc(BALANCE_SIZE);
		b->security = sqlite3_column_int(command, 2);
		b->rent = sqlite3_column_int(command, 3);
		b->due = sqlite3_column_int(command, 4);
		b->count = sqlite3_column_int(command, 7);
		b->isExpired = sqlite3_column_int(command, 8) == 1;
		size += (4 * 4 + 1
			+ mallocate(sqlite3_column_text(command, 0), &b->space)
			+ mallocate(sqlite3_column_text(command, 1), &b->tenant)
			+ mallocate(sqlite3_column_text(command, 5), &b->dateStart)
			+ mallocate(sqlite3_column_text(command, 6), &b->dateEnd)
			);
		addToList(&list, b);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getLedger(Request* r) {
	int id;
	memcpy_s(&id, 4, &r->packet[8], 4);
	char* where = &r->packet[12];
	char particulars[50], join[100], query[500];
	if (strcmp(where, "PlotId") == 0) {
		sprintf_s(particulars, sizeof(particulars), "s.Name || ' -> ' || t.Name");
		sprintf_s(join, sizeof(join), "LEFT JOIN Spaces s ON s.Id = tn.SpaceId "
			"LEFT JOIN Tenants t ON t.Id = tn.TenantId");
	}
	else if (strcmp(where, "SpaceId") == 0) {
		sprintf_s(particulars, sizeof(particulars), "p.Name || ' -> ' || t.Name");
		sprintf_s(join, sizeof(join), "LEFT JOIN Plots p ON p.Id = tn.PlotId "
			"LEFT JOIN Tenants t ON t.Id = tn.TenantId");
	}
	else {
		sprintf_s(particulars, sizeof(particulars), "p.Name || ' -> ' || s.Name");
		sprintf_s(join, sizeof(join), "LEFT JOIN Plots p ON p.Id = tn.PlotId "
			"LEFT JOIN Spaces s ON s.Id = tn.SpaceId");
	}
	sprintf_s(query, sizeof(query), "SELECT tn.Date, %s || ' -> ' || c.Name || ' - ' || h.Name || ' - ' || tn.Narration, "
		"tn.Amount, tn.ControlId FROM Transactions tn %s "
		"LEFT JOIN Heads h ON h.Id = tn.HeadId "
		"LEFT JOIN ControlHeads c ON c.Id = tn.ControlId "
		"WHERE tn.%s = %d ORDER by tn.Date", particulars, join, where, id);

	int size = 0;
	List list = { 0, 50, malloc(list.capacity * POINTER_SIZE) };
	sqlite3_prepare_v2(db, query, -1, &command, 0);
	while (sqlite3_step(command) == SQLITE_ROW) {
		ReportEntry* e = malloc(REPORT_ENTRY_SIZE);
		e->amount = sqlite3_column_int(command, 2);
		e->controlId = sqlite3_column_int(command, 3);
		size += (2 * 4 +
			+mallocate(sqlite3_column_text(command, 0), &e->date)
			+ mallocate(sqlite3_column_text(command, 1), &e->particulars)
			);
		addToList(&list, e);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getMonthlyBalance(Request* r) {
	char* cursor, * firstDayOfPreviousMonth, * lastDayOfPreviousMonth, * lastDayOfSelectedMonth;
	firstDayOfPreviousMonth = strtok_s(&r->packet[8], "", &cursor), cursor++;
	lastDayOfPreviousMonth = strtok_s(0, "", &cursor), cursor++;
	lastDayOfSelectedMonth = cursor;

	char* sql = "WITH t1 AS("
		"SELECT PlotId, SpaceId, TenantId, SUM(Amount) Amount FROM Transactions "
		"WHERE Date BETWEEN ? AND ? AND ControlId = 1 "
		"GROUP BY PlotId, TenantId, SpaceId "
		"), "
		"t2 AS("
		"SELECT Date, Transactions.PlotId, Transactions.TenantId, SUM(t1.Amount) CurrentDue, SUM(Transactions.Amount) Paid FROM Transactions "
		"LEFT JOIN t1 ON t1.SpaceId = Transactions.SpaceId AND t1.TenantId = Transactions.TenantId "
		"WHERE ControlId = 2 AND HeadId = 5 "
		"AND(Date > ? AND Date <= ?) "
		"GROUP BY Transactions.PlotId, Transactions.TenantId "
		"), "
		"t3 AS("
		"SELECT PlotId, SpaceId, TenantId, "
		"SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) - "
		"SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount "
		"FROM Transactions "
		"WHERE Date <= ? AND TenantId IN(SELECT TenantId FROM t1) "
		"GROUP BY PlotId, TenantId "
		"), "
		"t4 AS("
		"SELECT PlotId, SpaceId, TenantId, SUM(Amount) CurrentDue FROM t1 GROUP BY PlotId, TenantId "
		") "
		"SELECT COALESCE(t2.Date, ''), Plots.Name, Tenants.Name, t3.Amount Due, COALESCE(t4.CurrentDue, 0), COALESCE(t2.Paid, 0) Paid FROM t3 "
		"LEFT JOIN t2 ON t2.PlotId = t3.PlotId AND t2.TenantId = t3.TenantId "
		"LEFT JOIN t4 ON t4.PlotId = t3.PlotId AND t4.TenantId = t3.TenantId "
		"LEFT JOIN Plots ON Plots.Id = t3.PlotId "
		"LEFT JOIN Tenants ON Tenants.Id = t3.TenantId "
		"WHERE Due <> 0 OR t4.CurrentDue <> 0 OR Paid <> 0";

	sqlite3_prepare_v2(db, sql, -1, &command, NULL);
	sqlite3_bind_text(command, 1, firstDayOfPreviousMonth, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 2, lastDayOfPreviousMonth, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 3, lastDayOfPreviousMonth, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 4, lastDayOfSelectedMonth, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 5, lastDayOfPreviousMonth, -1, SQLITE_STATIC);

	int size = 0;
	List list = { 0, 50, malloc(list.capacity * POINTER_SIZE) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		MonthlyBalance* b = malloc(MONTHY_BALANCE_SIZE);
		b->due = sqlite3_column_int(command, 3);
		b->lastMonthDue = sqlite3_column_int(command, 4);
		b->payment = sqlite3_column_int(command, 5);
		size += (3 * 4 +
			+mallocate(sqlite3_column_text(command, 0), &b->date)
			+ mallocate(sqlite3_column_text(command, 1), &b->plot)
			+ mallocate(sqlite3_column_text(command, 2), &b->tenant)
			);
		addToList(&list, b);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}
static void getReceiptPayment(Request* r) {
	char* from, * to;
	from = strtok_s(&r->packet[8], "", &to), to++;
	char* sql =
		"WITH t0(Plot, Space, Tenant, Control, Head, InCash, Mobile, InKind) AS("
		"SELECT PlotId, SpaceId, TenantId, ControlId, HeadId, "
		"SUM(coalesce(CASE WHEN IsCash = 0 THEN Amount END, 0)), "
		"SUM(coalesce(CASE WHEN IsCash = 2 THEN Amount END, 0)), "
		"SUM(coalesce(CASE WHEN IsCash = 1 THEN Amount END, 0)) "
		"FROM Transactions "
		"WHERE ControlId <> 1 AND Date BETWEEN ? AND ? "
		"GROUP BY SpaceId, TenantId, HeadId "
		") "
		"SELECT p.Name, s.Name, t.Name, c.Name, h.Name, InCash, Mobile, InKind, (InCash + Mobile + InKind) Total "
		"from t0 as tn "
		"LEFT JOIN Plots p ON p.Id = tn.Plot "
		"LEFT JOIN Spaces s ON s.Id = tn.Space "
		"LEFT JOIN Tenants t ON t.Id = tn.Tenant "
		"LEFT JOIN ControlHeads c ON c.Id = tn.Control "
		"LEFT JOIN Heads h ON h.Id = tn.Head";

	sqlite3_prepare_v2(db, sql, -1, &command, NULL);
	sqlite3_bind_text(command, 1, from, -1, SQLITE_STATIC);
	sqlite3_bind_text(command, 2, to, -1, SQLITE_STATIC);

	int size = 0;
	List list = { 0, 50, malloc(list.capacity * POINTER_SIZE) };
	while (sqlite3_step(command) == SQLITE_ROW) {
		ReceiptPayment* r = malloc(RECEIPT_PAYMENT_SIZE);
		r->cash = sqlite3_column_int(command, 5);
		r->mobile = sqlite3_column_int(command, 6);
		r->kind = sqlite3_column_int(command, 7);
		r->total = sqlite3_column_int(command, 8);
		size += (4 * 4 +
			+mallocate(sqlite3_column_text(command, 0), &r->plot)
			+ mallocate(sqlite3_column_text(command, 1), &r->space)
			+ mallocate(sqlite3_column_text(command, 2), &r->tenant)
			+ mallocate(sqlite3_column_text(command, 3), &r->control)
			+ mallocate(sqlite3_column_text(command, 4), &r->head)
			);
		addToList(&list, r);
	}
	sqlite3_finalize(command);
	addLongPersonalResponse(r, list, size);
}

static ulong ProcessRequest(void* p) {
	while (isRunning) {
		Request* r = takeOutFrom(&requests);
		switch (r->function) {
			case GetInitialData: sendStartupPackets(r->sender); break;

			case AddPlot: addPlot(r); break;
			case AddSpace: addSpace(r); break;
			case AddTenant: addTenant(r); break;
			case AddHead: addHead(r); break;
			case AddLease: addLease(r); break;
			case AddTransactionsRegular:
			case AddTransactionsIrregular:
			case AddBulkRent: addTransactions(r); break;

			case EditPlot: editPlot(r); break;
			case EditSpace: editSpace(r); break;
			case EditTenant: editTenant(r); break;
			case EditHead: editHead(r); break;
			case EditLease: editLease(r); break;
			case EditTransaction: editTransaction(r); break;
			case DeleteTransaction: deleteTransaction(r); break;

			case GetTransactions: getTransactions(r); break;
			case GetPlotDueChart: getPlotDueChart(r); break;
			case GetPlotwiseRent: getPlotWiseRent(r); break;
			case GetTenantDetail: getTenantDetail(r); break;
			case GetDepositDueRent: getDepositDueRent(r); break;
			case GetBalance: getBalance(r); break;
			case GetLedger:  getLedger(r); break;
			case GetMonthlyBalance: getMonthlyBalance(r); break;
			case GetReceiptPayment: getReceiptPayment(r); break;
		}
		putInto(&garbageRequests, r);
	}
	return 0;
}
static ulong FreeRequest(void* p) {
	while (isRunning) {
		Request* r = takeOutFrom(&garbageRequests);
		free(r->packet);
		free(r);
	}
	return 0;
}

void InitializeDatabase() {
	garbageRequests.count = 0;
	garbageRequests.capacity = 5;
	garbageRequests.data = malloc(garbageRequests.capacity * POINTER_SIZE);
	garbageRequests.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&garbageRequests.section);

	freeRequestThread = CreateThread(NULL, 0, FreeRequest, NULL, 0, NULL);
	requestProcessThread = CreateThread(NULL, 0, ProcessRequest, NULL, 0, NULL);

	initializeList();
	initializeQueue();

	char* database = "C:/Users/Emon/Desktop/data.db";
	sqlite3_config(SQLITE_CONFIG_SINGLETHREAD); // since requests are processed one by one on ProcessRequest thread
	sqlite3_open(database, &db);
	
	char* query =
		"SELECT * FROM Plots; "
		"SELECT * FROM Spaces; "
		"SELECT Id, Name, Father, coalesce(Mother, ''), coalesce(Husband, ''), Address, coalesce(NID, ''), ContactNo, HasLeft FROM Tenants; "
		"SELECT Id, PlotId, SpaceId, TenantId, DateStart, coalesce(DateEnd, ''), Business, IsExpired FROM Leases; "
		"SELECT* FROM Receivables; "
		"SELECT* FROM ControlHeads; "
		"SELECT* FROM Heads";

	char* pzTail;
	sqlite3_prepare_v2(db, query, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Plot* p = malloc(PLOT_SIZE);
		p->id = sqlite3_column_int(command, 0);
		total.plot += (
			4
			+ mallocate(sqlite3_column_text(command, 1), &p->name)
			+ mallocate(sqlite3_column_text(command, 2), &p->description)
			);
		addToList(&plots, p);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(db, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Space* s = malloc(SPACE_SIZE);
		s->id = sqlite3_column_int(command, 0);
		s->plotId = sqlite3_column_int(command, 1);
		s->isVacant = sqlite3_column_int(command, 4);
		total.space += (
			8 + 1
			+ mallocate(sqlite3_column_text(command, 2), &s->name)
			+ mallocate(sqlite3_column_text(command, 3), &s->description)
			);
		addToList(&spaces, s);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(db, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Tenant* t = malloc(TENANT_SIZE);
		t->id = sqlite3_column_int(command, 0);
		t->hasLeft = sqlite3_column_int(command, 8);
		total.tenant += (
			4 + 1
			+ mallocate(sqlite3_column_text(command, 1), &t->name)
			+ mallocate(sqlite3_column_text(command, 2), &t->father)
			+ mallocate(sqlite3_column_text(command, 3), &t->mother)
			+ mallocate(sqlite3_column_text(command, 4), &t->husband)
			+ mallocate(sqlite3_column_text(command, 5), &t->address)
			+ mallocate(sqlite3_column_text(command, 6), &t->NID)
			+ mallocate(sqlite3_column_text(command, 7), &t->contactNo)
			);
		addToList(&tenants, t);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(db, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Lease* l = malloc(LEASE_SIZE);
		l->id = sqlite3_column_int(command, 0);
		l->plotId = sqlite3_column_int(command, 1);
		l->spaceId = sqlite3_column_int(command, 2);
		l->tenantId = sqlite3_column_int(command, 3);
		l->isExpired = sqlite3_column_int(command, 7);
		total.lease += (
			16 + 1
			+ mallocate(sqlite3_column_text(command, 4), &l->dateStart)
			+ mallocate(sqlite3_column_text(command, 5), &l->dateEnd)
			+ mallocate(sqlite3_column_text(command, 6), &l->business)
			);
		addToList(&leases, l);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(db, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Receivable* r = malloc(RECEIVABLE_SIZE);
		r->leaseId = sqlite3_column_int(command, 0);
		r->headId = sqlite3_column_int(command, 1);
		r->amount = sqlite3_column_int(command, 2);
		total.receivable += 12;
		addToList(&receivables, r);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(db, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		ControlHead* c = malloc(CONTROL_HEAD_SIZE);
		c->id = sqlite3_column_int(command, 0);
		total.controlHead += (4 + mallocate(sqlite3_column_text(command, 1), &c->name));
		addToList(&controlHeads, c);
	}

	sqlite3_finalize(command);
	sqlite3_prepare_v2(db, pzTail, -1, &command, &pzTail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Head* h = malloc(HEAD_SIZE);
		h->id = sqlite3_column_int(command, 0);
		h->controlId = sqlite3_column_int(command, 1);
		total.head += (
			8
			+ mallocate(sqlite3_column_text(command, 2), &h->name)
			+ mallocate(sqlite3_column_text(command, 3), &h->description)
			);
		addToList(&heads, h);
	}
	sqlite3_finalize(command);
}
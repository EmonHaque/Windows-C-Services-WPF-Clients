#include <winsock2.h>
#include "Structures.h"
#include "List.h"
#include "BlockingQueue.h"
#include "Messenger.h"

#pragma region variables
extern byte isRunning;
extern List receivers;
extern BlockingQueue publicResponses;
extern CRITICAL_SECTION criticalReceiver;

static HANDLE broadcastThread;
static List disconnectedReceivers;
#pragma endregion

static void sendPlot(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	Plot* plot = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], plot->id);
		sendString(list[i], plot->name);
		sendString(list[i], plot->description);
	}
}
static void sendSpace(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	Space* space = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], space->id);
		sendInt(list[i], space->plotId);
		sendString(list[i], space->name);
		sendString(list[i], space->description);
		sendByte(list[i], space->isVacant);
	}
}
static void sendEditedSpace(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	EditedSpace* ep = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], ep->leaseId);
		sendString(list[i], ep->vaccatedOn);
		sendInt(list[i], ep->space->id);
		sendInt(list[i], ep->space->plotId);
		sendString(list[i], ep->space->name);
		sendString(list[i], ep->space->description);
		sendByte(list[i], ep->space->isVacant);
	}
	free(ep->vaccatedOn);
	free(ep);
}
static void sendTenant(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	Tenant* tenant = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], tenant->id);
		sendString(list[i], tenant->name);
		sendString(list[i], tenant->father);
		sendString(list[i], tenant->mother);
		sendString(list[i], tenant->husband);
		sendString(list[i], tenant->address);
		sendString(list[i], tenant->NID);
		sendString(list[i], tenant->contactNo);
		sendByte(list[i], tenant->hasLeft);
	}
}
static void sendEditedTenant(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	EditedTenant* et = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendString(list[i], et->leftOn);
		sendInt(list[i], et->tenant->id);
		sendString(list[i], et->tenant->name);
		sendString(list[i], et->tenant->father);
		sendString(list[i], et->tenant->mother);
		sendString(list[i], et->tenant->husband);
		sendString(list[i], et->tenant->address);
		sendString(list[i], et->tenant->NID);
		sendString(list[i], et->tenant->contactNo);
		sendByte(list[i], et->tenant->hasLeft);
	}
	free(et->leftOn);
	free(et);
}
static void sendHead(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	Head* head = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], head->id);
		sendInt(list[i], head->controlId);
		sendString(list[i], head->name);
		sendString(list[i], head->description);
	}
}
static void sendLease(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	NewLease* nl = r->data;
	int count = nl->receivables.count;
	Receivable** receivables = nl->receivables.data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], nl->lease->id);
		sendInt(list[i], nl->lease->plotId);
		sendInt(list[i], nl->lease->spaceId);
		sendInt(list[i], nl->lease->tenantId);
		sendString(list[i], nl->lease->dateStart);
		sendString(list[i], nl->lease->dateEnd);
		sendString(list[i], nl->lease->business);
		sendByte(list[i], nl->lease->isExpired);
		for (int j = 0; j < count; j++) {
			sendInt(list[i], receivables[j]->leaseId);
			sendInt(list[i], receivables[j]->headId);
			sendInt(list[i], receivables[j]->amount);
		}
	}
	free(receivables);
	free(nl);
}
static void sendTransaction(ResponsePublic* r) {
	SOCKET* list = receivers.data;
	Transaction* action = r->data;
	for (int i = 0; i < receivers.count; i++) {
		if (sendInt(list[i], r->size) < 0) {
			addToList(&disconnectedReceivers, list[i]);
			continue;
		}
		sendInt(list[i], r->function);
		sendInt(list[i], r->userId);

		sendInt(list[i], action->id);
		sendInt(list[i], action->plotId);
		sendInt(list[i], action->spaceId);
		sendInt(list[i], action->tenantId);
		sendInt(list[i], action->controlId);
		sendInt(list[i], action->headId);
		sendInt(list[i], action->amount);
		sendByte(list[i], action->isCash);
		sendString(list[i], action->date);
		sendString(list[i], action->narration);
	}
	free(action->date);
	free(action->narration);
	free(action);
}
static ulong BroadcastResponse(void* p) {
	while (isRunning) {
		ResponsePublic* r = takeOutFrom(&publicResponses);
		EnterCriticalSection(&criticalReceiver);
		switch (r->function) {
			case AddPlot:
			case EditPlot: sendPlot(r); break;
			case AddSpace: sendSpace(r); break;
			case EditSpace: sendEditedSpace(r); break;
			case AddTenant: sendTenant(r); break;
			case EditTenant: sendEditedTenant(r); break;
			case AddLease:
			case EditLease: sendLease(r); break;
			case AddHead:
			case EditHead: sendHead(r); break;
			case EditTransaction:
			case DeleteTransaction: sendTransaction(r); break;
		}
		LeaveCriticalSection(&criticalReceiver);
		free(r);

		if (disconnectedReceivers.count > 0) {
			EnterCriticalSection(&criticalReceiver);
			SOCKET* list = disconnectedReceivers.data;
			for (int i = 0; i < disconnectedReceivers.count; i++) {
				closesocket(list[i]);
				removeFromList(&receivers, list[i]);
			}
			LeaveCriticalSection(&criticalReceiver);
			disconnectedReceivers.count = 0;
			if (disconnectedReceivers.capacity > 5) {
				disconnectedReceivers.capacity = 5;
				disconnectedReceivers.data = realloc(disconnectedReceivers.data, 5 * POINTER_SIZE);
			}
		}
	}
	CloseHandle(broadcastThread);
	return 0;
}

void InitializeBroadcaster() {
	disconnectedReceivers.count = 0;
	disconnectedReceivers.capacity = 5;
	disconnectedReceivers.data = malloc(5 * POINTER_SIZE);
	broadcastThread = CreateThread(NULL, 0, BroadcastResponse, NULL, 0, NULL);
}
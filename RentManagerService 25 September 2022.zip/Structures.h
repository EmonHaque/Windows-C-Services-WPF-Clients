#pragma once
#include <WinSock2.h>
#include "Defined.h"
#include "List.h"

typedef struct {
	SOCKADDR_IN from;
	SOCKET socket;
} NewClient;

typedef struct {
	SOCKET socket;
	HANDLE thread;
} Sender;

typedef struct {
	int id;
	char* name;
	char* description;
} Plot;

typedef struct {
	int id;
	int plotId;
	char* name;
	char* description;
	byte isVacant;
} Space;

typedef struct {
	int leaseId;
	char* vaccatedOn;
	Space* space;
} EditedSpace;

typedef struct {
	int id;
	char* name;
	char* father;
	char* mother;
	char* husband;
	char* address;
	char* NID;
	char* contactNo;
	byte hasLeft;
} Tenant;

typedef struct {
	char* leftOn;
	Tenant* tenant;
} EditedTenant;

typedef struct {
	int id;
	int plotId;
	int spaceId;
	int tenantId;
	char* dateStart;
	char* dateEnd;
	char* business;
	byte isExpired;
} Lease;

typedef struct {
	int leaseId;
	int headId;
	int amount;
} Receivable;

typedef struct {
	Lease *lease;
	List receivables;
} NewLease;

typedef struct {
	int id;
	char* name;
} ControlHead;

typedef struct {
	int id;
	int controlId;
	char* name;
	char* description;
} Head;

typedef struct {
	char* month;
	char* tenant;
	int due;
} PlotwiseDue;

typedef struct {
	char* plot;
	char* tenant;
	char* month;
	int rent;
	int cash;
	int mobile;
	int kind;
	int plotId;
	int total;
} PlotwiseRent;

typedef struct {
	unsigned char state;
	int plotId;
	int spaceId;
	int tenantId;
	int amount;
} DepositDueRent;

typedef struct {
	char* date;
	char* plot;
	char* space;
	char* tenant;
	int cash;
	int mobile;
	int kind;
	int due;
	int totalPaid;
} RentPayment;

typedef struct {
	int deposit;
	void* payments;
} TenantDetail;

typedef struct  {
	int plot;
	int space;
	int tenant;
	int lease;
	int receivable;
	int controlHead;
	int head;
} Totals;

typedef struct {
	char* space;
	char* tenant;
	int security;
	int rent;
	int due;
	char* dateStart;
	char* dateEnd;
	int count;
	byte isExpired;
} Balance;

typedef struct  {
	char* date;
	char* particulars;
	int amount;
	int controlId;
} ReportEntry;

typedef struct  {
	char* date;
	char* plot;
	char* tenant;
	int due;
	int lastMonthDue;
	int payment;
} MonthlyBalance;

typedef struct {
	char* plot;
	char* space;
	char* tenant;
	char* control;
	char* head;
	int cash;
	int mobile;
	int kind;
	int total;
} ReceiptPayment;

typedef struct {
	int id;
	int plotId;
	int spaceId;
	int tenantId;
	int controlId;
	int headId;
	int amount;
	byte isCash;
	char *date;
	char *narration;
} Transaction;

typedef enum {
	AddPlot,
	AddSpace,
	AddTenant,
	AddHead,
	AddLease,
	AddTransactionsRegular,
	AddTransactionsIrregular,
	AddBulkRent,

	EditPlot,
	EditSpace,
	EditTenant,
	EditHead,
	EditLease,
	GetTransactions,
	EditTransaction,
	DeleteTransaction,

	GetInitialData,
	GetBalance,
	GetMonthlyBalance,
	GetLedger,
	GetReceiptPayment,
	GetPlotDueChart,
	GetPlotwiseRent,
	GetTenantDetail,
	GetDepositDueRent
} Function;

typedef struct {
	SOCKET sender;
	int length;
	char* packet;
	int userId;
	Function function;
} Request;

typedef struct {
	SOCKET sender;
	Function function;
	int size;
	void* data;
	uint count;
} ResponsePersonal;

typedef struct {
	int size;
	Function function;
	int userId;
	void* data;
} ResponsePublic;

typedef struct {
	byte isSuccess;
	char text[50];
} ShortMessage;
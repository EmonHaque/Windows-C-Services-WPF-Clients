﻿class AppData : AppDataBase
{
    public static ObservableCollection<Plot> plots;
    public static ObservableCollection<Space> spaces;
    public static ObservableCollection<Tenant> tenants;
    public static ObservableCollection<Lease> leases;
    public static ObservableCollection<ControlHead> controlHeads;
    public static ObservableCollection<Head> heads;
    public static ObservableCollection<Notification> notifications;
    public static int? controlIdOfReceivable, controlIdOfPayment;

    public event Action<Plot> PlotAdded, PlotEdited;
    public event Action<Space> SpaceAdded;
    public event Action<Tenant> TenantAdded, TenantEdited;
    public event Action<Head> HeadAdded;
    public event Action<string> LeaseExpired;
    public event Action RegularTransactionAdded, IrregularTransactionAdded;
    public event Action<Transaction> TransactionEdited, TransactionDeleted;
    public event Action NotificationAdded;

    override protected void initializeCollections() {
        plots = new ObservableCollection<Plot>();
        spaces = new ObservableCollection<Space>();
        tenants = new ObservableCollection<Tenant>();
        leases = new ObservableCollection<Lease>();
        controlHeads = new ObservableCollection<ControlHead>();
        heads = new ObservableCollection<Head>();
        notifications = new ObservableCollection<Notification>();
        BindingOperations.EnableCollectionSynchronization(plots, plots);
        BindingOperations.EnableCollectionSynchronization(spaces, spaces);
        BindingOperations.EnableCollectionSynchronization(tenants, tenants);
        BindingOperations.EnableCollectionSynchronization(leases, leases);
        BindingOperations.EnableCollectionSynchronization(controlHeads, controlHeads);
        BindingOperations.EnableCollectionSynchronization(heads, heads);
        BindingOperations.EnableCollectionSynchronization(notifications, notifications);
    }
    override protected void populateCollections() {
        var receivables = new List<Receivable>();
        ReadOnlySpan<byte> plotSpan, spaceSpan, tenantSpan, leaseSpan, receivableSpan, controlHeadSpan, headSpan;

        try {
            plotSpan = new ReadOnlySpan<byte>(getPacket());
            spaceSpan = new ReadOnlySpan<byte>(getPacket());
            tenantSpan = new ReadOnlySpan<byte>(getPacket());
            leaseSpan = new ReadOnlySpan<byte>(getPacket());
            receivableSpan = new ReadOnlySpan<byte>(getPacket());
            controlHeadSpan = new ReadOnlySpan<byte>(getPacket());
            headSpan = new ReadOnlySpan<byte>(getPacket());
        }
        catch {
            patch.Invoke(() => { window.Text = "service down"; });
            Thread.Sleep(2000);
            patch.Invoke(() => { window.Text = "quitting"; });
            Thread.Sleep(2000);
            patch.Invoke(() => {
                window.Close();
                App.Current.Shutdown();
            });
            return;
        }
        patch.Invoke(() => { window.Text = "listing plot"; });
        Thread.Sleep(250);
        #region Plot
        int read = 0;
        int start = 0;
        while (read < plotSpan.Length) {
            int id = BitConverter.ToInt32(plotSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (plotSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(plotSpan.Slice(start, read - start));

            start = ++read;
            while (plotSpan[read] != 0) read++;
            var description = Encoding.ASCII.GetString(plotSpan.Slice(start, read - start));
            patch.Invoke(() => {
                plots.Add(new Plot() {
                    Id = id,
                    Name = name,
                    Description = description
                });
            });

            start = ++read;
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing space"; });
        Thread.Sleep(250);
        #region Space
        start = read = 0;
        while (read < spaceSpan.Length) {
            int id = BitConverter.ToInt32(spaceSpan.Slice(start, 4));
            int plotId = BitConverter.ToInt32(spaceSpan.Slice(start + 4, 4));
            read += 8;
            start = read;
            while (spaceSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(spaceSpan.Slice(start, read - start));

            start = ++read;
            while (spaceSpan[read] != 0) read++;
            var description = Encoding.ASCII.GetString(spaceSpan.Slice(start, read - start));
            read++;
            var isVacant = BitConverter.ToBoolean(spaceSpan.Slice(read, 1));
            App.Current.Dispatcher.Invoke(() => {
                spaces.Add(new Space() {
                    Id = id,
                    PlotId = plotId,
                    Name = name,
                    Description = description,
                    IsVacant = isVacant
                });
            });
            start = ++read;
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing tenant"; });
        Thread.Sleep(250);
        #region Tenant
        start = read = 0;
        while (read < tenantSpan.Length) {
            int id = BitConverter.ToInt32(tenantSpan.Slice(start, 4));
            read += 4;
            start = read;
            int index = 0;
            var segments = new string[7];
            while (read < tenantSpan.Length) {
                if (tenantSpan[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(tenantSpan.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            var hasLeft = BitConverter.ToBoolean(tenantSpan.Slice(read, 1));
            start = ++read;
            App.Current.Dispatcher.Invoke(() => {
                tenants.Add(new Tenant() {
                    Id = id,
                    Name = segments[0],
                    Father = segments[1],
                    Mother = segments[2],
                    Husband = segments[3],
                    Address = segments[4],
                    NID = segments[5],
                    ContactNo = segments[6],
                    HasLeft = hasLeft
                });
            });
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing lease"; });
        Thread.Sleep(250);
        #region Lease
        start = read = 0;
        while (read < leaseSpan.Length) {
            int id = BitConverter.ToInt32(leaseSpan.Slice(start, 4));
            int plotId = BitConverter.ToInt32(leaseSpan.Slice(start + 4, 4));
            int spaceId = BitConverter.ToInt32(leaseSpan.Slice(start + 8, 4));
            int tenantId = BitConverter.ToInt32(leaseSpan.Slice(start + 12, 4));

            read += 16;
            start = read;
            while (leaseSpan[read] != 0) read++;
            var startDate = Encoding.ASCII.GetString(leaseSpan.Slice(start, read - start));
            var dateStart = DateTime.ParseExact(startDate, "yyyy-MM-dd", CultureInfo.InvariantCulture.DateTimeFormat);

            start = ++read;
            while (leaseSpan[read] != 0) read++;
            var endDate = Encoding.ASCII.GetString(leaseSpan.Slice(start, read - start));
            DateTime? dateEnd = string.IsNullOrWhiteSpace(endDate) ? null :
               DateTime.ParseExact(endDate, "yyyy-MM-dd", CultureInfo.InvariantCulture.DateTimeFormat);

            start = ++read;
            while (leaseSpan[read] != 0) read++;
            var business = Encoding.ASCII.GetString(leaseSpan.Slice(start, read - start));

            read++;
            var isExpired = BitConverter.ToBoolean(leaseSpan.Slice(read, 1));
            App.Current.Dispatcher.Invoke(() => {
                leases.Add(new Lease() {
                    Id = id,
                    PlotId = plotId,
                    SpaceId = spaceId,
                    TenantId = tenantId,
                    DateStart = dateStart,
                    DateEnd = dateEnd,
                    Business = business,
                    IsExpired = isExpired
                });
            });
            start = ++read;
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing receivable"; });
        Thread.Sleep(250);
        #region Receivables
        start = read = 0;
        while (read < receivableSpan.Length) {
            var leaseId = BitConverter.ToInt32(receivableSpan.Slice(read, 4));
            var headId = BitConverter.ToInt32(receivableSpan.Slice(read + 4, 4));
            var amount = BitConverter.ToInt32(receivableSpan.Slice(read + 8, 4));

            receivables.Add(new Receivable() {
                LeaseId = leaseId,
                HeadId = headId,
                Amount = amount
            });
            read += 12;
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing control control head"; });
        Thread.Sleep(250);
        #region ControlHead
        start = read = 0;
        while (read < controlHeadSpan.Length) {
            int id = BitConverter.ToInt32(controlHeadSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (controlHeadSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(controlHeadSpan.Slice(start, read - start));
            App.Current.Dispatcher.Invoke(() => {
                controlHeads.Add(new ControlHead() {
                    Id = id,
                    Name = name
                });
            });
            start = ++read;
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing head"; });
        Thread.Sleep(250);
        #region Head
        start = read = 0;
        while (read < headSpan.Length) {
            int id = BitConverter.ToInt32(headSpan.Slice(start, 4));
            int controlId = BitConverter.ToInt32(headSpan.Slice(start + 4, 4));
            read += 8;
            start = read;
            while (headSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(headSpan.Slice(start, read - start));

            start = ++read;
            while (headSpan[read] != 0) read++;
            var description = Encoding.ASCII.GetString(headSpan.Slice(start, read - start));
            App.Current.Dispatcher.Invoke(() => {
                heads.Add(new Head() {
                    Id = id,
                    ControlId = controlId,
                    Name = name,
                    Description = description
                });
            });
            start = ++read;
        }
        #endregion

        if (receivables.Count > 0) {
            foreach (var item in leases)
                item.FixedReceivables = new ObservableCollection<Receivable>(receivables.Where(x => x.LeaseId == item.Id));
        }
        for (int i = 0; i < leases.Count; i++) {
            leases[i].PlotName = plots.First(x => x.Id == leases[i].PlotId).Name;
            leases[i].SpaceName = spaces.First(x => x.Id == leases[i].SpaceId).Name;
            leases[i].TenantName = tenants.First(x => x.Id == leases[i].TenantId).Name;
        }
        for (int i = 0; i < spaces.Count; i++)
            spaces[i].PlotName = plots.First(x => x.Id == spaces[i].PlotId).Name;

        foreach (var control in controlHeads) {
            if (string.Equals(control.Name, "Receivable"))
                controlIdOfReceivable = control.Id;
            else if (string.Equals(control.Name, "Payment"))
                controlIdOfPayment = control.Id;
        }
    }
    override protected void processMessage() {
        while (isConnected) {
            var packet = new ReadOnlySpan<byte>(messages.Take());
            var message = (Function)BitConverter.ToInt32(packet.Slice(0, 4));
            var slice = packet.Slice(4);
            switch (message) {
                case Function.AddPlot: plotAdd(slice); break;
                case Function.EditPlot: plotEdit(slice); break;
                case Function.AddSpace: spaceAdd(slice); break;
                case Function.EditSpace: spaceEdit(slice); break;
                case Function.AddTenant: tenantAdd(slice); break;
                case Function.EditTenant: tenantEdit(slice); break;
                case Function.AddHead: headAdd(slice); break;
                case Function.EditHead: headEdit(slice); break;
                case Function.AddLease: leaseAdd(slice); break;
                case Function.EditLease: leaseEdit(slice); break;
                case Function.AddTransactionsRegular: regularAdd(slice); break;
                case Function.AddTransactionsIrregular: irregularAdd(slice); break;
                case Function.EditTransaction: transactionEdit(slice); break;
                case Function.DeleteTransaction: transactionDelete(slice); break;
            }
        }
    }

    void plotAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var plot = array.Slice(4).ToPlot();
        patch.Invoke(() => {
            plots.Add(plot);
            if (userId != App.service.UserId) {
                notifications.Add(new Notification() {
                    IsRead = false,
                    Category = "Plot",
                    Message = plot.Name + " added by " + userId
                });
                NotificationAdded?.Invoke();
                return;
            }
            PlotAdded?.Invoke(plot);
        });
    }
    void plotEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var edited = array.Slice(4).ToPlot();
        var original = plots.First(x => x.Id == edited.Id);

        if (userId != App.service.UserId) {
            notifications.Add(new Notification() {
                IsRead = false,
                Category = "Plot",
                Message = original.Name + " edited, see " + edited.Name
            });
            NotificationAdded?.Invoke();
        }
        patch.Invoke(() => {
            original.Description = edited.Description;
            if (!edited.Name.Equals(original.Name)) {
                original.Name = edited.Name;
                foreach (var lease in leases) {
                    if (lease.PlotId == original.Id)
                        lease.PlotName = original.Name;
                }
                foreach (var space in spaces) {
                    if (space.PlotId == original.Id)
                        space.PlotName = original.Name;
                }
                PlotEdited?.Invoke(original);
            }
        });

    }
    void spaceAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var space = array.Slice(4).ToSpace();
        space.PlotName = plots.First(x => x.Id == space.PlotId).Name;
        patch.Invoke(() => {
            spaces.Add(space);
            if (userId == App.service.UserId) SpaceAdded?.Invoke(space);
            else {
                notifications.Add(new Notification() {
                    IsRead = false,
                    Category = "Space",
                    Message = space.Name + " added in " + space.PlotName
                });
                NotificationAdded?.Invoke();
            }
        });
    }
    void spaceEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var leaseId = BitConverter.ToInt32(array.Slice(4, 4));
        int read = 8;
        string message = "";
        if (leaseId > 0) {
            int start = read;
            while (read < array.Length) {
                if (array[read] != 0) {
                    read++;
                    continue;
                }
                break;
            }
            var vaccatedOn = Encoding.ASCII.GetString(array.Slice(start, read - start));
            var lease = leases.First(x => x.Id == leaseId);
            lease.IsExpired = true;
            lease.DateEnd = DateTime.ParseExact(vaccatedOn, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);

            var tenantName = tenants.First(x => x.Id == lease.TenantId).Name;
            var spaceName = spaces.First(x => x.Id == lease.SpaceId).Name;
            message = $"{spaceName} was let out to {tenantName}\r\nNow is vacant and available to let out";
        }
        read++;
        var edited = array.Slice(read).ToSpace();
        var original = spaces.First(x => x.Id == edited.Id);
        var plotName = plots.First(x => x.Id == edited.PlotId).Name;

        if (userId == App.service.UserId) {
            if (!string.IsNullOrEmpty(message)) {
                patch.Invoke(() => { InfoDialog.Activate("Space", message); });
            }
        }
        else {
            notifications.Add(new Notification() {
                IsRead = false,
                Category = "Space",
                Message = original.Name + " in " + original.PlotName + " edited, see " + edited.Name + " in " + plotName
            });
            NotificationAdded?.Invoke();
        }
        patch.Invoke(() => {
            original.PlotId = edited.PlotId;
            original.Description = edited.Description;
            original.IsVacant = edited.IsVacant;
            original.PlotName = plotName;
            if (!edited.Name.Equals(original.Name)) {
                original.Name = edited.Name;
                foreach (var lease in leases) {
                    if (lease.SpaceId == original.Id)
                        lease.SpaceName = original.Name;
                }
            }
        });

    }
    void tenantAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var tenant = array.Slice(4).ToTenant();
        patch.Invoke(() => {
            tenants.Add(tenant);
            if (userId == App.service.UserId) {
                TenantAdded?.Invoke(tenant);
            }
            else {
                notifications.Add(new Notification() {
                    IsRead = false,
                    Category = "Tenant",
                    Message = tenant.Name + " added"
                });
                NotificationAdded?.Invoke();
            }
        });
    }
    void tenantEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        int read = 4;
        int start = read;
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            break;
        }
        var leftOn = Encoding.ASCII.GetString(array.Slice(start, read - start));
        read++;
        var edited = array.Slice(read).ToTenant();
        var original = tenants.First(x => x.Id == edited.Id);
        string message = "";

        if (!string.IsNullOrWhiteSpace(leftOn)) {
            var date = DateTime.ParseExact(leftOn, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);
            var leaseList = leases.Where(x => !x.IsExpired && x.TenantId == edited.Id).ToList();
            if (leaseList.Count > 0) {
                message = "Space(s) occupied:";
                foreach (var lease in leaseList) {
                    var space = spaces.FirstOrDefault(x => x.Id == lease.SpaceId);
                    space.IsVacant = true;
                    lease.IsExpired = true;
                    lease.DateEnd = date;
                    message += $"\r\n\t{space.Name} of {plots.First(x => x.Id == space.PlotId).Name}";
                }
                message += $"\r\n\r\nby {edited.Name} now available to let out";
            }
        }
        if (userId == App.service.UserId) {
            if (!string.IsNullOrEmpty(message)) {
                patch.Invoke(() => { InfoDialog.Activate("Tenant", message); });
            }
        }
        else {
            notifications.Add(new Notification() {
                IsRead = false,
                Category = "Tenant",
                Message = original.Name + " edited, see " + edited.Name
            });
            NotificationAdded?.Invoke();
        }

        patch.Invoke(() => {
            original.Father = edited.Father;
            original.Mother = edited.Mother;
            original.Husband = edited.Husband;
            original.Address = edited.Address;
            original.ContactNo = edited.ContactNo;
            original.NID = edited.NID;
            original.HasLeft = edited.HasLeft;

            if (!original.Name.Equals(edited.Name)) {
                original.Name = edited.Name;
                foreach (var lease in leases) {
                    if (lease.TenantId == original.Id)
                        lease.TenantName = original.Name;
                }
                TenantEdited?.Invoke(original);
            }
        });
    }
    void headAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var head = array.Slice(4).ToHead();
        patch.Invoke(() => {
            heads.Add(head);
            if (userId == App.service.UserId) {
                HeadAdded?.Invoke(head);
            }
            else {
                notifications.Add(new Notification() {
                    IsRead = false,
                    Category = "Head",
                    Message = head.Name + " added in " + controlHeads.First(x => x.Id == head.ControlId).Name
                });
                NotificationAdded?.Invoke();
            }
        });
    }
    void headEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var edited = array.Slice(4).ToHead();
        var original = heads.First(x => x.Id == edited.Id);
        if (userId != App.service.UserId) {
            notifications.Add(new Notification() {
                IsRead = false,
                Category = "Head",
                Message = original.Name + " edited, see " + edited.Name + " in " + controlHeads.First(x => x.Id == edited.ControlId).Name
            });
            NotificationAdded?.Invoke();
        }
        patch.Invoke(() => {
            original.ControlId = edited.ControlId;
            original.Name = edited.Name;
            original.Description = edited.Description;
        });
    }
    void leaseAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var lease = array.Slice(4).ToLease();
        lease.PlotName = plots.First(x => x.Id == lease.PlotId).Name;
        lease.SpaceName = spaces.First(x => x.Id == lease.SpaceId).Name;
        lease.TenantName = tenants.First(x => x.Id == lease.TenantId).Name;
        spaces.First(x => x.Id == lease.SpaceId).IsVacant = false;
        patch.Invoke(() => { leases.Add(lease); });

        if(userId != App.service.UserId) {
            notifications.Add(new Notification() {
                IsRead = false,
                Category = "Lease",
                Message = lease.SpaceName + " of " + lease.PlotName + " is let out to " + lease.TenantName
            });
            NotificationAdded?.Invoke();
        }
    }
    void leaseEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var edited = array.Slice(4).ToLease();
        var original = leases.First(x => x.Id == edited.Id);
        if (edited.IsExpired && !original.IsExpired) {
            var vacated = spaces.First(x => x.Id == original.SpaceId);
            vacated.IsVacant = true;
            if (App.service.UserId == userId) {
                patch.Invoke(() => LeaseExpired?.Invoke(vacated.Name));
            }
        }
        if (edited.SpaceId != original.SpaceId) {
            spaces.FirstOrDefault(x => x.Id == original.SpaceId).IsVacant = true;
            spaces.FirstOrDefault(x => x.Id == edited.SpaceId).IsVacant = false;
        }
        var originalPlot = plots.First(x => x.Id == original.PlotId).Name;
        var originalSpace = spaces.First(x => x.Id == original.SpaceId).Name;
        var originalTenant = tenants.First(x => x.Id == original.TenantId).Name;

        var editedPlot = plots.First(x => x.Id == edited.PlotId).Name;
        var editedSpace = spaces.First(x => x.Id == edited.SpaceId).Name;
        var editedTenant = tenants.First(x => x.Id == edited.TenantId).Name;

        if (userId != App.service.UserId) {
            notifications.Add(new Notification() {
                IsRead = false,
                Category = "Lease",
                Message = originalTenant + "'s lease " + originalSpace + " of " + originalPlot + " edited, see " + editedSpace + " in " + editedPlot 
            });
            NotificationAdded?.Invoke();
        }
        patch.Invoke(() => {
            original.Id = edited.Id;
            original.PlotId = edited.PlotId;
            original.SpaceId = edited.SpaceId;
            original.TenantId = edited.TenantId;
            original.DateStart = edited.DateStart;
            original.DateEnd = edited.DateEnd;
            original.Business = edited.Business;
            original.IsExpired = edited.IsExpired;
            original.FixedReceivables = edited.FixedReceivables;
            original.PlotName = editedPlot;
            original.SpaceName = editedSpace;
            original.TenantName = editedTenant;
        });
    }

    //no notification for the followings, broadcast more on server side and add more in client side if you want 
    void regularAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        if (userId == App.service.UserId) {
            patch.Invoke(() => RegularTransactionAdded?.Invoke());
        }
    }
    void irregularAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        if (userId == App.service.UserId) {
            patch.Invoke(() => IrregularTransactionAdded?.Invoke());
        }
    }
    void transactionEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nTransaction = array.Slice(4).ToTransaction();
        TransactionEdited?.Invoke(nTransaction);
    }
    void transactionDelete(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nTransaction = array.Slice(4).ToTransaction();
        patch.Invoke(() => TransactionDeleted?.Invoke(nTransaction));
    }
}

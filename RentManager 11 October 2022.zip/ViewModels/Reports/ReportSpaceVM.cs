﻿class ReportSpaceVM : ReportBase
{
    public override ICollectionView selectionView => spaces.View;
    protected override string Where => where;
    string where;
    CollectionViewSource spaces;
    public ReportSpaceVM() {
        where = "SpaceId";
        spaces = new CollectionViewSource() {
            Source = AppData.spaces,
            IsLiveGroupingRequested = true,
            LiveGroupingProperties = { nameof(Space.PlotName) }
        };
        spaces.View.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Space.PlotName)));
        selectionView.Filter = filterSpaces;
    }
    protected override void setTitleAndSubTitle() {
        var space = AppData.spaces.First(x => x.Id == Id);
        Title = space.Name;
        SubTitle = space.Description;
    }
    bool filterSpaces(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        var space = (Space)o;
        return
            space.PlotName.ToLower().Contains(Query) ||
            space.Name.ToLower().Contains(Query);
    }
}

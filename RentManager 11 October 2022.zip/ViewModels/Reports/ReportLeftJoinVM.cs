﻿class ReportLeftJoinVM : Notifiable
{
    DateTime? from;
    public DateTime? From {
        get { return from; }
        set {
            if (from != value) {
                from = value;
                validate();
            }
        }
    }
    DateTime? to;
    public DateTime? To {
        get { return to; }
        set {
            if (to != value) {
                to = value;
                validate();
            }
        }
    }
    string status;
	public string Status {
		get { return status; }
		set { status = value; OnPropertyChanged(nameof(Status)); }
	}
    public string ErrorFrom { get; set; }
    public string ErrorTo { get; set; }
    public bool IsRefreshValid { get; set; }
    public ICollectionView Data { get; set; }
    public Action Refresh { get; set; }

	public ReportLeftJoinVM() {
		To = DateTime.Today;
		From = To.Value.AddMonths(-1);
		Refresh = refresh;
	}

    void validate() {
        ErrorFrom = ErrorTo = string.Empty;
        if (From == null) ErrorFrom = " required";
        if (To == null) ErrorTo = " required";
        IsRefreshValid = ErrorFrom == string.Empty && ErrorTo == string.Empty;
        OnPropertyChanged(nameof(ErrorFrom));
        OnPropertyChanged(nameof(ErrorTo));
        OnPropertyChanged(nameof(IsRefreshValid));
    }

    async void refresh() {
        Status = "requesting data";
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)Function.GetLeftOrJoined,
            Bytes = new List<ArraySegment<byte>>() {
                Encoding.ASCII.GetBytes(From.Value.ToString("yyyy-MM-dd") + '\0'),
                Encoding.ASCII.GetBytes(To.Value.ToString("yyyy-MM-dd") + '\0')
            }
        };
        var response = await App.service.GetResponse(request);
        await Task.Delay(500);
        if (!response.IsSuccess) {
            Status = LocalConstants.DownMessage;
            return;
        }
        Status = $"received {response.Packet.Length.ToString("N0")} bytes";
        await Task.Delay(500);
        var list = await Task.Run(response.Packet.ToLeftOrJoined);
        Data = CollectionViewSource.GetDefaultView(list);
        Data.GroupDescriptions.Add(new PropertyGroupDescription(nameof(LeftOrJoined.Status)));
        Data.GroupDescriptions.Add(new PropertyGroupDescription(nameof(LeftOrJoined.Plot)));
        OnPropertyChanged(nameof(Data));
    }
}

﻿class NotificationVM : Notifiable
{
    public ICollectionView Entries { get; set; }
	public NotificationVM() {
		Entries = CollectionViewSource.GetDefaultView(AppData.notifications);
	}
}

﻿abstract class AddBase<T> : Notifiable where T : Notifiable, new()
{
    public T TObject { get; set; }
    public Action Add { get; set; }
    public AddBase() {
        TObject = new T();
        Add = addTObject;
    }
    protected abstract ObservableCollection<T> collection { get; }
    protected abstract Function function { get; }
    protected abstract List<ArraySegment<byte>> bytes { get; }
    protected abstract string errorTitle { get; }
    protected abstract void renewTObject();
    async void addTObject() {
        var request = new Request() {
            UserId = App.service.UserId,
            Method = (int)function,
            Bytes = bytes
        };
        var response = await App.service.GetResponse(request); // real response will be handled by Receiver
        handleResponse(response, errorTitle);
        renewTObject();
    }
    protected void handleResponse(Response response, string header) {
        if (response.IsSuccess) {
            var isSuccess = BitConverter.ToBoolean(response.Packet);
            if (!isSuccess) {
                var message = Encoding.ASCII.GetString(response.Packet.Skip(1).ToArray());
                InfoDialog.Activate(header, message);
            }
        }
        else {
            InfoDialog.Activate("Service", "Couldn't connect to service, try restrating the Application");
        }
    }
}

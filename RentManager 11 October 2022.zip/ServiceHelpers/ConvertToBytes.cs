﻿static class ConvertToBytes
{
    public static List<ArraySegment<byte>> ToBytes(this Plot plot) {
        int id = plot.Id.HasValue ? plot.Id.Value : 0;
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(id),
            Encoding.ASCII.GetBytes(plot.Name + '\0'),
            Encoding.ASCII.GetBytes(plot.Description + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this Space space) {
        int id = space.Id.HasValue ? space.Id.Value : 0;
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(id),
            BitConverter.GetBytes(space.PlotId.Value),
            Encoding.ASCII.GetBytes(space.Name + '\0'),
            Encoding.ASCII.GetBytes(space.Description + '\0'),
            BitConverter.GetBytes(space.IsVacant)
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this Space space, string vacatedOn) {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(vacatedOn + '\0'),
            BitConverter.GetBytes(space.Id.Value),
            BitConverter.GetBytes(space.PlotId.Value),
            Encoding.ASCII.GetBytes(space.Name + '\0'),
            Encoding.ASCII.GetBytes(space.Description + '\0'),
            BitConverter.GetBytes(space.IsVacant)
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this Tenant tenant) {
        int id = tenant.Id.HasValue ? tenant.Id.Value : 0;
        string mother = string.IsNullOrWhiteSpace(tenant.Mother) ? "" : tenant.Mother;
        string husband = string.IsNullOrWhiteSpace(tenant.Husband) ? "" : tenant.Husband;
        string nid = string.IsNullOrWhiteSpace(tenant.NID) ? "" : tenant.NID;

        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(id),
            Encoding.ASCII.GetBytes(tenant.Name + '\0'),
            Encoding.ASCII.GetBytes(tenant.Father + '\0'),
            Encoding.ASCII.GetBytes(mother + '\0'),
            Encoding.ASCII.GetBytes(husband + '\0'),
            Encoding.ASCII.GetBytes(tenant.Address + '\0'),
            Encoding.ASCII.GetBytes(nid + '\0'),
            Encoding.ASCII.GetBytes(tenant.ContactNo + '\0'),
            BitConverter.GetBytes(tenant.HasLeft)
         };
    }
    public static List<ArraySegment<byte>> ToBytes(this Tenant tenant, string leftOn) {
        string mother = string.IsNullOrWhiteSpace(tenant.Mother) ? "" : tenant.Mother;
        string husband = string.IsNullOrWhiteSpace(tenant.Husband) ? "" : tenant.Husband;
        string nid = string.IsNullOrWhiteSpace(tenant.NID) ? "" : tenant.NID;

        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(leftOn + '\0'),
            BitConverter.GetBytes(tenant.Id.Value),
            Encoding.ASCII.GetBytes(tenant.Name + '\0'),
            Encoding.ASCII.GetBytes(tenant.Father + '\0'),
            Encoding.ASCII.GetBytes(mother + '\0'),
            Encoding.ASCII.GetBytes(husband + '\0'),
            Encoding.ASCII.GetBytes(tenant.Address + '\0'),
            Encoding.ASCII.GetBytes(nid + '\0'),
            Encoding.ASCII.GetBytes(tenant.ContactNo + '\0'),
            BitConverter.GetBytes(tenant.HasLeft)
         };
    }
    public static List<ArraySegment<byte>> ToBytes(this Head head) {
        int id = head.Id.HasValue ? head.Id.Value : 0;
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(id),
            BitConverter.GetBytes(head.ControlId.Value),
            Encoding.ASCII.GetBytes(head.Name + '\0'),
            Encoding.ASCII.GetBytes(head.Description + '\0')
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this Receivable receivable) {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(receivable.LeaseId),
            BitConverter.GetBytes(receivable.HeadId.Value),
            BitConverter.GetBytes(receivable.Amount)
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this Lease lease) {
        var endDate = lease.DateEnd.HasValue ? lease.DateEnd.Value.ToString("yyyy-MM-dd") : "";
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(lease.Id),
            BitConverter.GetBytes(lease.PlotId.Value),
            BitConverter.GetBytes(lease.SpaceId.Value),
            BitConverter.GetBytes(lease.TenantId.Value),
            Encoding.ASCII.GetBytes(lease.DateStart.Value.ToString("yyyy-MM-dd") + '\0'),
            Encoding.ASCII.GetBytes(endDate + '\0'),
            Encoding.ASCII.GetBytes(lease.Business + '\0'),
            BitConverter.GetBytes(lease.IsExpired)
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this Lease lease, IEnumerable<Receivable> receivables) {
        var bytes = new List<ArraySegment<byte>>();
        bytes.AddRange(lease.ToBytes());
        foreach (var receivable in receivables) {
            bytes.AddRange(receivable.ToBytes());
        }
        return bytes;
    }
    public static List<ArraySegment<byte>> ToBytes(this Transaction transaction) {
        var date = Encoding.ASCII.GetBytes(transaction.Date.Value.ToString("yyyy-MM-dd") + '\0');
        var narration = Encoding.ASCII.GetBytes(transaction.Narration + '\0');
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(transaction.Id),
            BitConverter.GetBytes(transaction.PlotId.Value),
            BitConverter.GetBytes(transaction.SpaceId.Value),
            BitConverter.GetBytes(transaction.TenantId.Value),
            BitConverter.GetBytes(transaction.ControlId.Value),
            BitConverter.GetBytes(transaction.HeadId.Value),
            BitConverter.GetBytes(transaction.Amount),
            new byte[1]{ transaction.IsCash },
            date, narration
        };
    }
    public static List<ArraySegment<byte>> ToBytes(this IEnumerable<Transaction> transactions) {
        var bytes = new List<ArraySegment<byte>>();
        foreach (var t in transactions) bytes.AddRange(t.ToBytes());
        return bytes;
    }
}
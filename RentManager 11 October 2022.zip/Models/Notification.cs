﻿class Notification : Notifiable
{
    public bool IsRead { get; set; }
    public string Category { get; set; }
    public string Message { get; set; }
}

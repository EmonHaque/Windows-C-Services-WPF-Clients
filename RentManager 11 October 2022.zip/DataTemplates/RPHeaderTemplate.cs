﻿class RPHeaderTemplate : DataTemplate
{
    public RPHeaderTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid"};
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var header = new FrameworkElementFactory(typeof(HiBlock));
        var totals = new FrameworkElementFactory(typeof(ContentControl));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(4 * 70));
        totals.SetValue(Grid.ColumnProperty, 1);
        totals.SetValue(ContentControl.ContentTemplateProperty, new RPSummaryTemplate());

        var queryBinding = new Binding("DataContext." + nameof(ReportRPsVM.Query)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ListBox), 1),
            IsAsync = true
        };

        var source = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1);
        header.SetBinding(HiBlock.QueryProperty, queryBinding);
        header.SetBinding(HiBlock.TextProperty, new Binding("DataContext." + nameof(GroupItem.Name)) {
            Mode = BindingMode.OneWay,
            RelativeSource = source
        });
        totals.SetBinding(ContentControl.ContentProperty, new Binding("DataContext") {
            RelativeSource = source,
            Converter = Converters.rpGroup2Summary,
            Mode = BindingMode.OneWay
        });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(header);
        grid.AppendChild(totals);

        VisualTree = grid;

        Triggers.Add(new Trigger() {
            Property = Grid.IsMouseOverProperty,
            Value = true,
            Setters = {
                new Setter(Grid.BackgroundProperty, Constants.BackgroundDark, "grid")
            }
        });
    }
}

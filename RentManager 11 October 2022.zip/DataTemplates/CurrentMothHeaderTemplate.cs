﻿class CurrentMothHeaderTemplate : DataTemplate
{
    public CurrentMothHeaderTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var header = new FrameworkElementFactory(typeof(TextBlock));
        var plot = new FrameworkElementFactory(typeof(Run));
        var openParen = new FrameworkElementFactory(typeof(Run));
        var count = new FrameworkElementFactory(typeof(Run));
        var closeParen = new FrameworkElementFactory(typeof(Run));
        var totals = new FrameworkElementFactory(typeof(ContentControl));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(4 * 70));
        openParen.SetValue(Run.TextProperty, " (");
        closeParen.SetValue(Run.TextProperty, ")");
        totals.SetValue(Grid.ColumnProperty, 1);
        totals.SetValue(ContentControl.ContentTemplateProperty, new CurrentMonthSummaryTemplate());
        plot.SetValue(Run.FontWeightProperty, FontWeights.Bold);
        totals.SetValue(TextElement.FontWeightProperty, FontWeights.Bold);

        var source = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1);
        plot.SetBinding(Run.TextProperty, new Binding("DataContext." + nameof(GroupItem.Name)) {
            Mode = BindingMode.OneWay,
            RelativeSource = source
        });
        //observe summaries on UI when you bind both ItemCount and Items 
        count.SetBinding(Run.TextProperty, new Binding("DataContext." + nameof(CollectionViewGroup.ItemCount)) {          
            Mode = BindingMode.OneWay,
            RelativeSource = source,
            StringFormat = "N0"
        });
        totals.SetBinding(ContentControl.ContentProperty, new Binding("DataContext." + nameof(CollectionViewGroup.Items)) {
            // without async you might get different results on different run, if this doesn't work: 
            // try multibinding (ItemCount and Items), see LoadGroupTemplate on Bills and if it does modify that template of Bills (remove multibinding)
            IsAsync = true, 
            RelativeSource = source,
            Converter = Converters.currentMonth2Summary,
            Mode = BindingMode.OneWay
        });

        header.AppendChild(plot);
        header.AppendChild(openParen);
        header.AppendChild(count);
        header.AppendChild(closeParen);

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(header);
        grid.AppendChild(totals);

        VisualTree = grid;
    }
}

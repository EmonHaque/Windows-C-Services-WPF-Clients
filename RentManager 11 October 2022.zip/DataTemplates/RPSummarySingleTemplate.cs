﻿class RPSummarySingleTemplate : DataTemplate
{
    public RPSummarySingleTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "totals"};
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var header = new FrameworkElementFactory(typeof(HiBlock));
        var cash = new FrameworkElementFactory(typeof(TextBlock));
        var mobile = new FrameworkElementFactory(typeof(TextBlock));
        var kind = new FrameworkElementFactory(typeof(TextBlock));
        var total = new FrameworkElementFactory(typeof(TextBlock));
        Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                    new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right),
                    new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center),
                    new Setter(Grid.RowProperty, 1)
                }
        });
        grid.SetValue(Grid.BackgroundProperty, Brushes.Transparent);
        header.SetValue(HiBlock.MarginProperty, new Thickness(0, 1.5, 0, 1.5));
        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));

        header.SetValue(HiBlock.HorizontalAlignmentProperty, HorizontalAlignment.Left);
        cash.SetValue(Grid.ColumnProperty, 1);
        mobile.SetValue(Grid.ColumnProperty, 2);
        kind.SetValue(Grid.ColumnProperty, 3);
        total.SetValue(Grid.ColumnProperty, 4);

        var queryBinding = new Binding("DataContext." + nameof(ReportRPsVM.Query)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ListBox), 1),
            IsAsync = true
        };
        header.SetBinding(HiBlock.QueryProperty, queryBinding);
        header.SetBinding(HiBlock.TextProperty, new Binding("Item1"));
        cash.SetBinding(TextBlock.TextProperty, new Binding("Item2") { StringFormat = Constants.NumberFormat });
        mobile.SetBinding(TextBlock.TextProperty, new Binding("Item3") { StringFormat = Constants.NumberFormat });
        kind.SetBinding(TextBlock.TextProperty, new Binding("Item4") { StringFormat = Constants.NumberFormat });
        total.SetBinding(TextBlock.TextProperty, new Binding("Item5") { StringFormat = Constants.NumberFormat });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);
        grid.AppendChild(header);
        grid.AppendChild(cash);
        grid.AppendChild(mobile);
        grid.AppendChild(kind);
        grid.AppendChild(total);

        VisualTree = grid;

        Triggers.Add(new Trigger() {
            Property = Grid.IsMouseOverProperty,
            Value = true,
            Setters = {
                new Setter(Grid.BackgroundProperty, Constants.BackgroundDark, "totals")
            }
        });
    }
}
﻿class Counts : CardView
{
    public override string Header => "Space, Lease & Tenants";
    PieChart pie;
    MultiState state, selectionState;
    ActionButton refresh;
    CountsVM viewModel;

    public override void OnFirstSight() {
        base.OnFirstSight();
        viewModel = new CountsVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }
    void refreshCommand() {
        if (BusyWindow.IsOpened) return;
        var position = PointToScreen(new Point(0, 0));
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin;
        position.Y += Constants.CardMargin;
        var width = ActualWidth - 2 * Constants.CardMargin;
        var height = ActualHeight - 2 * Constants.CardMargin;
        BusyDialog.Activate(position.X, position.Y, width, height, "Reloading ...");
        viewModel.Refresh();
        BusyDialog.Terminate();
    }
    void initializeUI() {
        refresh = new ActionButton() {
            Command = refreshCommand,
            Icon = Icons.Refresh,
            ToolTip = "Reload"
        };
        addActions(refresh);

        state = new MultiState() {
            Icons = new string[] { Icons.Existing, Icons.LeftOrExpired, Icons.All }
        };
        selectionState = new MultiState() {
            Icons = new string[] { Icons.Space, Icons.Lease, Icons.Tenant },
            Texts = new string[] { "Space", "Lease", "Tenant" },
            IsIconInfront = true
        };
        pie = new PieChart() { SelectedValuePath = nameof(PlotSummary.Id) };

        Grid.SetColumn(state, 1);
        Grid.SetRow(pie, 1);
        Grid.SetColumnSpan(pie, 2);
        var grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                },
            Children = { selectionState, state, pie }
        };
        setContent(grid);
    }
    void bind() {
        pie.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(viewModel.Summary)));
        pie.SetBinding(PieChart.SelectedValueProperty, new Binding(nameof(viewModel.Selected)));
        selectionState.SetBinding(MultiState.StateProperty, new Binding(nameof(viewModel.SelectionState)));
        state.SetBinding(MultiState.StateProperty, new Binding(nameof(viewModel.State)));
        state.SetBinding(MultiState.TextsProperty, new Binding(nameof(viewModel.StateTexts)));
    }
}

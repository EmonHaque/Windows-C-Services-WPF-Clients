﻿class LaunchWindow : Window
{
    Socket socket;
    LaunchArgs args;
    TextBlock appNameBlock, infoBlock;

    public LaunchWindow() {
        var cmdArgs = Environment.GetCommandLineArgs().Skip(1).First().Replace("\"", "").Split(",");
        args = new LaunchArgs() {
            App = cmdArgs[0],
            Version = cmdArgs[1],
            Path = cmdArgs[2]
        };
        Width = 300;
        Height = 100;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;

        appNameBlock = new TextBlock() {
            Text = args.App,
            HorizontalAlignment = HorizontalAlignment.Center,
            FontSize = 24,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.LightGray
        };
        infoBlock = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.LightGray
        };
        Content = new Grid() {
            Background = new SolidColorBrush(Color.FromRgb(50, 50, 50)),
            Children = {
                new Border() {
                    CornerRadius = new CornerRadius(5),
                    BorderThickness = new Thickness(1),
                    BorderBrush = Brushes.LightGray,
                    Child = new StackPanel() {
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center,
                        Children = {appNameBlock, infoBlock }
                    }
                }
            }
        };
    }

    protected override void OnActivated(EventArgs e) {
        new Thread(update) { IsBackground = true }.Start();
    }

    void update() {
        Dispatcher.Invoke(() => {
            infoBlock.Text = "checking for update";
        });
        Thread.Sleep(2000);

        socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        try { socket.Connect(new IPEndPoint(IPAddress.Parse(Addresses.LaunchAddress), Addresses.LaunchPort)); }
        catch {
            Dispatcher.Invoke(() => {
                infoBlock.Text = "coudn't connect to launch server!";
            });
            Thread.Sleep(3000);
            Dispatcher.Invoke(() => {
                infoBlock.Text = "quitting ...";
            });
            Thread.Sleep(2000);
            
            socket.Close();
            socket.Dispose();
            Dispatcher.Invoke(App.Current.Shutdown);
            return;
        }
        socket.Send(args.GetBytes());
        var resultByte = new byte[1];
        socket.Receive(resultByte);
        var hasUpdate = BitConverter.ToBoolean(resultByte);

        if (hasUpdate) {
            Dispatcher.Invoke(() => {
                infoBlock.Text = "update available";
            });
            Thread.Sleep(1000);
            var files = Directory.GetFiles(args.Path);
            foreach (var file in files) {
                File.Delete(file);
            }
            var header = new byte[4];
            int read = socket.Receive(header);
            while (read < header.Length) {
                read += socket.Receive(header, read, header.Length - read, SocketFlags.None);
            }
            var totalsize = BitConverter.ToInt32(header);
            var kb = (totalsize / 1024).ToString("N0") + " KB";

            Dispatcher.Invoke(() => {
                infoBlock.Text = "received 0 /" + kb;
            });
            Thread.Sleep(1000);

            var packet = new byte[totalsize];
            read = socket.Receive(packet);
            while (read < packet.Length) {
                read += socket.Receive(packet, read, packet.Length - read, SocketFlags.None);
                Dispatcher.Invoke(() => {
                    infoBlock.Text = "received " + (read / 1024).ToString("N0") + " / " + kb;
                });
                Thread.Sleep(1000);
            }
            read = 0;
            var span = new ReadOnlySpan<byte>(packet);

            Dispatcher.Invoke(() => {
                infoBlock.Text = "writing files ...";
            });
            Thread.Sleep(1000);
            while (read < packet.Length) {
                var length = BitConverter.ToInt32(span.Slice(read, 4));
                read += 4;
                var file = AppFile.FromBytes(span.Slice(read, length).ToArray()); // use span?
                read += length;
                using (var stream = new FileStream(args.Path + "\\" + file.Name, FileMode.Create, FileAccess.Write))
                    stream.Write(file.Content, 0, file.Content.Length);
            }

        }
        else {
            Dispatcher.Invoke(() => {
                infoBlock.Text = "no update available" ;
            });
            Thread.Sleep(1000);
        }
        socket.Shutdown(SocketShutdown.Both);
        socket.Close();
        socket.Dispose();
        Dispatcher.Invoke(() => {
            infoBlock.Text = "launching " + args.App;
        });
        Thread.Sleep(1000);

        Dispatcher.Invoke(() => {
            Process.Start(args.Path + "\\" + args.App + ".exe", "U");
            App.Current.Shutdown();
        });
    }
}

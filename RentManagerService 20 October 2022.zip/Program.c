//#pragma comment (linker, "/STACK:100000000")
#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "sqlite3.lib")

#include <ws2tcpip.h>
#include "Structures.h"
#include "List.h"
#include "BlockingQueue.h"
#include "Service.h"

#pragma region variables
CRITICAL_SECTION criticalReceiver;
byte isRunning;
List receivers;
BlockingQueue requests, newClients;
HANDLE newClientProcessThread;

static SOCKET server;
static CRITICAL_SECTION criticalSender;
static List senders;
#pragma endregion

#pragma region protos
extern void InitializeDatabase();
extern void InitializeDispatcher();
extern void InitializeBroadcaster();

static void initialize();
static void acceptClient();
static void cleanup();
static ulong processNewClient(void*);
#pragma endregion

int main() {
	SetActions(initialize, acceptClient, cleanup);
#ifdef _DEBUG 
	RunServiceDebug();
#else 
	RunServiceRelease();
#endif 
	return 0;
}

static void initialize() {
	const wchar_t* IP = L"127.0.0.1";
	const int PORT = 5557;

	WSADATA w;
	WSAStartup(MAKEWORD(2, 2), &w);

	SOCKADDR_IN address = { AF_INET, htons(PORT) };
	InetPton(AF_INET, IP, &address.sin_addr.s_addr);
	server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	bind(server, &address, sizeof(address));
	listen(server, SOMAXCONN);
	isRunning = 1;

	newClientProcessThread = CreateThread(NULL, 0, processNewClient, NULL, 0, NULL);

	receivers.capacity = senders.capacity = 5;
	receivers.count = senders.count = 0;
	receivers.data = malloc(receivers.capacity * SENDER_SIZE);
	senders.data = malloc(senders.capacity * SENDER_SIZE);

	requests.count = 0;
	requests.capacity = 5;
	requests.data = malloc(requests.capacity * POINTER_SIZE);
	requests.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	newClients.count = 0;
	newClients.capacity = 10;
	newClients.data = malloc(newClients.capacity * sizeof(NewClient));
	newClients.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	InitializeCriticalSection(&requests.section);
	InitializeCriticalSection(&newClients.section);

	InitializeCriticalSection(&criticalSender);
	InitializeCriticalSection(&criticalReceiver);

	InitializeDatabase();
	InitializeDispatcher();
	InitializeBroadcaster();
}
static ulong enqueueRequest(void* p) {
	SOCKET client = p;
	char header[4];
	int packetSize, accumulated, read;
	while (1) {
		accumulated = read = 0;
		do {
			read = recv(client, &header[accumulated], 4 - accumulated, 0);
			if (read <= 0) goto onDisconnected;
			accumulated += read;
		} while (accumulated < 4);

		memcpy_s(&packetSize, 4, header, 4);
		Request* r = malloc(REQUEST_SIZE);
		r->packet = malloc(packetSize);

		accumulated = read = 0;
		do {
			read = recv(client, &r->packet[accumulated], packetSize - accumulated, 0);
			if (read <= 0) {
				free(r->packet);
				free(r);
				goto onDisconnected;
			}
			accumulated += read;
		} while (accumulated < packetSize);

		r->sender = client;
		r->length = packetSize;
		memcpy_s(&r->userId, 4, &r->packet[0], 4);
		memcpy_s(&r->function, 4, &r->packet[4], 4);
		putInto(&requests, r);
	}

onDisconnected:
	closesocket(client);
	EnterCriticalSection(&criticalSender);
	Sender** list = senders.data;
	Sender* s = 0;
	for (size_t i = 0; i < senders.count; i++) {
		if (list[i]->socket == client) {
			s = list[i];
			break;
		}
	}
	removeFromList(&senders, s);
	LeaveCriticalSection(&criticalSender);

	CloseHandle(s->thread);
	free(s);
	return 0;
}
static ulong processNewClient(void* p) {
	while (isRunning) {
		NewClient* client = takeOutFrom(&newClients);
		//char ipv4[INET_ADDRSTRLEN];
		//inet_ntop(AF_INET, &(client->from.sin_addr), ipv4, INET_ADDRSTRLEN);
		BOOL b = TRUE;
		setsockopt(client->socket, IPPROTO_TCP, TCP_NODELAY, &b, sizeof(BOOL));

		byte isReceiver;
		int read = recv(client->socket, &isReceiver, 1, 0);
		if (isReceiver) {
			EnterCriticalSection(&criticalReceiver);
			addToList(&receivers, client->socket);
			LeaveCriticalSection(&criticalReceiver);
		}
		else {
			EnterCriticalSection(&criticalSender);
			/*
				Do these dwStackSizeand STACK_SIZE_PARAM_IS_A_RESERVATION have any effect?
				size_t stackSize = 1000;
				HANDLE requestThread = CreateThread(NULL, stackSize, enqueueRequest, client->socket, STACK_SIZE_PARAM_IS_A_RESERVATION, NULL);
			*/
			HANDLE requestThread = CreateThread(NULL, 0, enqueueRequest, client->socket, 0, NULL);
			Sender* s = malloc(SENDER_SIZE);
			s->socket = client->socket;
			s->thread = requestThread;
			addToList(&senders, s);
			LeaveCriticalSection(&criticalSender);
		}
		free(client);
	}
}
static void acceptClient() {
	SOCKADDR_IN s;
	int length = sizeof(s);
	while (isRunning) {
		NewClient* client = malloc(sizeof(NewClient));
		client->socket = accept(server, &client->from, &length);
		putInto(&newClients, client);
	}
}
static void cleanup() {
	isRunning = 0;
	closesocket(server);
	WSACleanup();
}
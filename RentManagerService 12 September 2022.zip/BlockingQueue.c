#include "BlockingQueue.h"

void putInto(BlockingQueue* queue, void* item) {
	EnterCriticalSection(&queue->section);
	((void**)queue->data)[queue->count++] = item;
	if (queue->capacity == queue->count) {
		queue->capacity *= 2;
		queue->data = realloc(queue->data, queue->capacity * POINTER_SIZE);
	}
	LeaveCriticalSection(&queue->section);
	if (queue->isWaiting) SetEvent(queue->manualResetEvent);
}
void* takeOutFrom(BlockingQueue* queue) {
	EnterCriticalSection(&queue->section);
	void* item;
	void** que = queue->data;
	if (queue->count > 0) {
		item = que[0];
		queue->count--;
		if (queue->count > 0) {
			for (int i = 0; i < queue->count; i++) {
				que[i] = que[i + 1];
			}
		}
		if ((queue->capacity - queue->count) > 1000) {
			queue->capacity = queue->count + 100;
			queue->data = realloc(queue->data, queue->capacity * POINTER_SIZE);
		}
		LeaveCriticalSection(&queue->section);
	}
	else {
		queue->isWaiting = 1;
		LeaveCriticalSection(&queue->section);
		WaitForSingleObject(queue->manualResetEvent, INFINITE);

		item = takeOutFrom(queue);
		queue->isWaiting = 0;
		ResetEvent(queue->manualResetEvent);
	}
	return item;
}

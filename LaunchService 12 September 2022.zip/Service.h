#pragma once

void SetActions(Action initializer, Action mainRoutine, Action cleaner);
void RunServiceDebug();
void RunServiceRelease();